<?php
/**
 * Konfigurasi koneksi database.
 * Sesuaikan dengan pengaturan XAMPP Anda (default XAMPP: user root, password kosong).
 * Folder config/ dilindungi .htaccess sehingga tidak bisa dibuka dari browser.
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'smk_infokom');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Ubah menjadi true HANYA saat belajar/debug di localhost. Wajib false saat online.
define('APP_DEBUG', false);

// Kosongkan agar alamat dasar dideteksi otomatis. Contoh manual: '/smk-infokom'
define('BASE_PATH_OVERRIDE', '');
