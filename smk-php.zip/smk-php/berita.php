<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/components.php';

$cats = q_all('SELECT c.*, (SELECT COUNT(*) FROM news n WHERE n.category_id = c.id AND ' . str_replace('n.', 'n.', published_news_sql()) . ') AS total FROM news_categories c ORDER BY c.name');
$q   = trim(get_str('q',''));
$cat = trim(get_str('kategori',''));
$where = [published_news_sql()]; $par = [];
if ($q !== '') { $where[] = '(n.title LIKE ? OR n.summary LIKE ? OR n.content LIKE ?)'; $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $q) . '%'; array_push($par, $like, $like, $like); }
$catName = '';
if ($cat !== '') { $where[] = 'c.slug = ?'; $par[] = $cat; foreach ($cats as $c) if ($c['slug'] === $cat) $catName = $c['name']; }
$w = implode(' AND ', $where);
$total = (int)q_val("SELECT COUNT(*) FROM news n LEFT JOIN news_categories c ON c.id = n.category_id WHERE $w", $par);
$pg = paginate($total, 9, (int)get_str('page','1'));
$rows = q_all("SELECT n.*, c.name AS category_name FROM news n LEFT JOIN news_categories c ON c.id = n.category_id WHERE $w ORDER BY n.published_at DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $par);

$pageTitle = 'Berita' . ($catName ? ' - ' . $catName : '');
$metaDesc  = 'Berita dan informasi terbaru dari ' . setting('school_name') . '.';
require __DIR__ . '/includes/header.php';
page_banner('Berita', [], 'Informasi dan kegiatan terkini sekolah');
?>
<div class="container py-5">
    <div class="row g-5">
        <div class="col-lg-8">
            <form class="search-bar" method="get" role="search">
                <?php if ($cat): ?><input type="hidden" name="kategori" value="<?= e($cat) ?>"><?php endif; ?>
                <div class="input-group"><input type="search" name="q" class="form-control" placeholder="Cari berita..." value="<?= e($q) ?>" aria-label="Cari berita"><button class="btn btn-blue" type="submit" aria-label="Cari"><i class="fa-solid fa-magnifying-glass"></i></button></div>
            </form>
            <?php if ($q !== '' || $catName): ?><p class="text-muted">Menampilkan <?= $total ?> berita<?= $q !== '' ? ' untuk "<strong>' . e($q) . '</strong>"' : '' ?><?= $catName ? ' pada kategori <strong>' . e($catName) . '</strong>' : '' ?>. <a href="berita.php">Reset</a></p><?php endif; ?>
            <?php if (!$rows): echo empty_state($q !== '' ? 'Berita yang dicari tidak ditemukan.' : 'Belum ada berita yang diterbitkan.'); else: ?>
            <div class="row g-4"><?php foreach ($rows as $n): ?><div class="col-md-6"><?= news_card($n) ?></div><?php endforeach; ?></div>
            <div class="mt-5"><?= pagination_html($pg, ['q' => $q, 'kategori' => $cat]) ?></div>
            <?php endif; ?>
        </div>
        <aside class="col-lg-4">
            <div class="side-box"><h3>Kategori</h3><ul class="side-list">
                <li><a href="berita.php"><i class="fa-solid fa-angle-right text-primary me-1"></i>Semua kategori</a></li>
                <?php foreach ($cats as $c): ?><li class="d-flex justify-content-between"><a href="?kategori=<?= e(urlencode($c['slug'])) ?>"><i class="fa-solid fa-angle-right text-primary me-1"></i><?= e($c['name']) ?></a><span class="badge bg-light text-dark"><?= (int)$c['total'] ?></span></li><?php endforeach; ?>
            </ul></div>
            <?php $recent = q_all('SELECT n.title, n.slug, n.published_at FROM news n WHERE ' . published_news_sql() . ' ORDER BY n.published_at DESC LIMIT 5'); ?>
            <div class="side-box"><h3>Berita Terbaru</h3><ul class="side-list"><?php foreach ($recent as $r): ?><li><a href="<?= e(url('detail-berita.php?slug=' . urlencode($r['slug']))) ?>"><?= e($r['title']) ?></a><div class="meta"><?= e(tgl_indo($r['published_at'])) ?></div></li><?php endforeach; ?></ul></div>
        </aside>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
