<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/components.php';
$a = q_one('SELECT a.*, c.name AS category_name FROM agendas a LEFT JOIN agenda_categories c ON c.id = a.category_id WHERE a.id = ? AND a.is_published = 1', [(int)get_str('id','0')]);
if (!$a) show_404();
$pageTitle = $a['title'];
$metaDesc  = excerpt($a['description'], 160);
require __DIR__ . '/includes/header.php';
page_banner('Detail Agenda', ['Agenda' => 'agenda.php']);
?>
<div class="container py-5"><div class="row justify-content-center"><div class="col-lg-9">
    <?php if ($a['category_name']): ?><span class="badge bg-warning text-dark mb-2"><?= e($a['category_name']) ?></span><?php endif; ?>
    <h2 class="mb-4"><?= e($a['title']) ?></h2>
    <?php if ($a['image']): ?><img class="img-fluid rounded-4 shadow mb-4" src="<?= e(img_url($a['image'])) ?>" alt="<?= e($a['title']) ?>"><?php endif; ?>
    <div class="ppdb-card mb-4"><ul class="info-list">
        <li><span class="ic"><i class="fa-regular fa-calendar"></i></span><div><span class="lb">Tanggal</span><span class="vl"><?= e(hari_id($a['event_date'])) ?>, <?= e(agenda_date_label($a)) ?></span></div></li>
        <li><span class="ic"><i class="fa-regular fa-clock"></i></span><div><span class="lb">Waktu</span><span class="vl"><?= e(agenda_time_label($a)) ?></span></div></li>
        <?php if ($a['location']): ?><li><span class="ic"><i class="fa-solid fa-location-dot"></i></span><div><span class="lb">Lokasi</span><span class="vl"><?= e($a['location']) ?></span></div></li><?php endif; ?>
    </ul></div>
    <div class="rich"><?= format_text($a['description']) ?></div>
    <a href="<?= url('agenda.php') ?>" class="btn btn-outline-blue mt-3"><i class="fa-solid fa-arrow-left me-2"></i>Kembali ke Agenda</a>
</div></div></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
