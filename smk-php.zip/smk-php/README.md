# Website Profil SMK INFOKOM BOGOR

Website profil sekolah berbasis **PHP Native + MySQL** (tanpa framework) dengan dashboard admin.
Frontend dan backend memakai **satu database yang sama**, sehingga setiap perubahan di dashboard langsung tampil di website.

Teknologi: PHP Native (PDO + prepared statements), MySQL/MariaDB (InnoDB, utf8mb4), HTML5, CSS3, JavaScript, Bootstrap 5, Font Awesome, Chart.js.
Semua library (Bootstrap, Font Awesome, Chart.js, font) sudah **disertakan lokal** di `assets/vendor`, jadi website tetap jalan tanpa internet.

---

## 1. Persyaratan sistem
- XAMPP (atau Laragon/WAMP) dengan **PHP 8.0 atau lebih baru** dan **MySQL/MariaDB**
- Ekstensi PHP: `pdo_mysql`, `mbstring`, `fileinfo` (semuanya aktif bawaan XAMPP)
- Browser modern (Chrome, Edge, Firefox, Safari)

## 2. Memasang XAMPP
1. Unduh XAMPP dari https://www.apachefriends.org lalu pasang seperti biasa.
2. Buka **XAMPP Control Panel**, klik **Start** pada **Apache** dan **MySQL**.

## 3. Menempatkan project di htdocs
Salin folder `smk-infokom` ke:
- Windows: `C:\xampp\htdocs\smk-infokom`
- Linux/macOS: `/opt/lampp/htdocs/smk-infokom`

Alamat dasar dideteksi otomatis, jadi folder boleh diberi nama lain.

## 4. Membuat database dan 5. Mengimpor file SQL
1. Buka http://localhost/phpmyadmin
2. Klik tab **Import** > **Choose File** > pilih `database/smk_infokom.sql` > klik **Import**.
3. Database `smk_infokom` beserta seluruh tabel dan data contoh dibuat otomatis.
   (Jika Anda memakai nama database lain, buat dulu database kosong, pilih database tersebut, baru impor, lalu sesuaikan langkah 6.)

## 6. Mengatur koneksi database
Buka `config/database.php`, sesuaikan jika perlu:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'smk_infokom');
define('DB_USER', 'root');   // bawaan XAMPP
define('DB_PASS', '');       // bawaan XAMPP kosong
```
Biarkan `APP_DEBUG` bernilai `false`. Ubah ke `true` hanya sementara saat mencari error di komputer sendiri.

## 7. Menjalankan setup admin pertama kali
Tidak ada akun admin bawaan (demi keamanan).
1. Buka http://localhost/smk-infokom/setup_admin.php
2. Isi nama, username (jangan `admin`), email, dan password sendiri (minimal 8 karakter, huruf + angka).
3. Setelah berhasil, setup **terkunci otomatis** (file `config/installed.lock` dibuat) dan tidak bisa dipakai lagi.
4. **Hapus file `setup_admin.php`** dari folder project.

## 8. Login ke dashboard admin
- Alamat: http://localhost/smk-infokom/admin/login.php (atau tautan "Login Admin" di footer website)
- Login gagal 5 kali dalam 15 menit akan dikunci sementara.
- Sesi berakhir otomatis setelah 2 jam tidak aktif. Logout lewat tombol di sidebar/menu profil.

## 9. Cara mengelola konten
Sidebar admin dikelompokkan sesuai menu website:

| Menu admin | Isi yang dikelola |
|---|---|
| Profil Sekolah | Identitas, sambutan kepala sekolah, sejarah, visi/misi/tujuan, struktur organisasi, fasilitas, statistik |
| Akademik | Program keahlian, kurikulum, kalender pendidikan, PKL, BKK, program kerja luar negeri & Jepang |
| Guru dan Staff | 5 kategori terpisah (pimpinan, wakil kepala sekolah, guru, staff usaha, staff kurikulum) |
| Kesiswaan | Beranda kesiswaan, OSIS, ekskul, prestasi, kegiatan, tata tertib |
| PPDB Online | Informasi & tahun ajaran, jadwal, persyaratan, alur/jalur/FAQ, brosur, data pendaftar, pengaturan formulir |
| Berita / Galeri / Agenda | Daftar, tambah, dan kategori masing-masing |
| Kontak | Informasi kontak, media sosial, pesan pengunjung |
| Pengaturan Website | Logo, favicon, nama sekolah, hero beranda, footer, SEO |
| Administrator | Profil, ganti password, kelola akun admin |

Setiap tabel data memiliki pencarian, pagination, jumlah data, tombol Tambah/Edit/Hapus, konfirmasi hapus, dan notifikasi berhasil/gagal.

Tips penting:
- **Berita**: status *Draft* tidak tampil ke pengunjung; ubah ke *Terbit* agar tayang. Tanggal publikasi di masa depan = tayang terjadwal.
- **Guru/Staff**: mengubah *Kategori* langsung memindahkan profil ke bagian yang sesuai. Kolom *Urutan* mengatur posisi tampil; matikan *Publikasikan* untuk menyembunyikan.
- **Teks**: pisahkan paragraf dengan baris kosong; awali baris dengan `- ` untuk membuat daftar.
- **Ganti logo**: Pengaturan Website > Logo, Favicon & Umum. (Logo yang tersedia di project hanyalah logo contoh bergaya; unggah logo resmi sekolah di sini.)

## 10. Cara mengunggah foto
Di form tambah/edit, pilih file pada kolom gambar. Aturan: JPG/PNG/WEBP/GIF, maksimal **3 MB**. Pratinjau muncul sebelum disimpan. Saat gambar diganti atau data dihapus, file lama otomatis dihapus dari server.
Ukuran disarankan: foto guru/kepala sekolah rasio 4:5 (potret), berita/fasilitas rasio 16:10 atau 4:3, brosur PPDB bebas (ditampilkan utuh tanpa terpotong).

## 11. Izin folder upload
Folder `assets/uploads/` harus bisa ditulis oleh server web.
- Windows/XAMPP: biasanya sudah bisa ditulis.
- Linux: `chmod -R 775 assets/uploads` dan `chown -R www-data:www-data assets/uploads` (atau user Apache Anda).
File `.htaccess` di folder ini memblokir eksekusi script PHP.

## 12. Menjalankan website di localhost
- Website: http://localhost/smk-infokom/
- Admin: http://localhost/smk-infokom/admin/

## 13. Mengatasi error umum
| Masalah | Solusi |
|---|---|
| "Koneksi database gagal" | Pastikan MySQL menyala di XAMPP; cek `config/database.php`; pastikan database sudah diimpor. |
| Halaman kosong/putih | Sementara ubah `APP_DEBUG` ke `true` di `config/database.php` untuk melihat pesan error. |
| Gambar gagal diunggah | Cek ukuran (maks 3 MB), format, dan izin folder `assets/uploads`. Cek juga `upload_max_filesize` dan `post_max_size` di `php.ini` (minimal 4M). |
| Gambar/CSS tidak muncul | Pastikan folder `assets` ikut tersalin lengkap. |
| Tidak bisa login | Jalankan setup admin dulu (langkah 7). Jika terkunci, tunggu 15 menit. |
| Lupa password admin | Buat hash baru: `php -r "echo password_hash('PasswordBaru123', PASSWORD_DEFAULT);"` lalu perbarui kolom `password_hash` tabel `admins` lewat phpMyAdmin. |
| Setup ingin diulang | Hapus baris di tabel `admins` dan file `config/installed.lock`. |

## 14. Backup database
- phpMyAdmin > pilih database `smk_infokom` > tab **Export** > Quick > **Export**.
- Atau lewat terminal: `mysqldump -u root -p smk_infokom > backup.sql`
- Backup juga folder `assets/uploads/` (berisi foto yang diunggah). Lakukan rutin dan simpan di tempat terpisah.

## 15. Mengamankan website sebelum dipublikasikan
- [ ] **Hapus `setup_admin.php`**.
- [ ] Gunakan password admin yang kuat dan unik; jangan bagikan akun.
- [ ] Pastikan `APP_DEBUG` = `false`.
- [ ] Jangan memakai user MySQL `root` tanpa password di server online; buat user khusus dengan hak akses hanya ke database `smk_infokom`, lalu isi di `config/database.php`.
- [ ] Pastikan server mendukung `.htaccess` (Apache `AllowOverride All`), karena file ini melindungi folder `config`, `includes`, `database`, dan `assets/uploads`. Pada Nginx, tambahkan aturan setara.
- [ ] Aktifkan HTTPS (SSL); cookie sesi otomatis ditandai *secure* saat HTTPS.
- [ ] Jangan upload folder `database/` yang berisi file SQL ke server publik jika tidak diperlukan (atau pastikan terblokir).
- [ ] Ganti seluruh **data contoh** (kepala sekolah, guru, visi misi, sejarah, jadwal PPDB, media sosial, dll.) dengan data resmi. Data bertanda "(contoh)" bukan data resmi.
- [ ] Atur backup rutin.

---

## Fitur keamanan yang diterapkan
PDO prepared statements di seluruh query; `password_hash()`/`password_verify()`; regenerasi session ID saat login; sesi dengan cookie HttpOnly + SameSite; pembatasan percobaan login; token CSRF pada semua form yang mengubah data (hapus, ubah status, logout) dengan metode POST; escape output `htmlspecialchars()`; validasi input di sisi PHP; validasi upload (ukuran, ekstensi, MIME, isi gambar, nama acak unik, eksekusi PHP diblokir); pesan error database tidak ditampilkan ke pengunjung; data pendaftar PPDB dan pesan pengunjung hanya terlihat admin; honeypot + pembatasan laju pada form publik; transaksi database pada pendaftaran dan penyimpanan data.

## Struktur folder
```
smk-infokom/
├── index.php, profil.php, akademik.php, program-detail.php, guru-staff.php, kesiswaan.php
├── ppdb.php, berita.php, detail-berita.php, galeri.php, agenda.php, agenda-detail.php, kontak.php
├── setup_admin.php            (hapus setelah instalasi)
├── config/database.php        (koneksi database, dilindungi .htaccess)
├── includes/                  (functions, auth, header, navbar, footer, components)
├── assets/{css,js,images,fonts,vendor,uploads}
├── admin/
│   ├── login.php, logout.php, index.php, dashboard.php
│   ├── crud.php               (mesin CRUD untuk 26 modul konten)
│   ├── settings.php           (pengaturan website, identitas, kontak, hero, PPDB, footer, SEO)
│   ├── ppdb_registrations.php (data pendaftar: cari, filter, detail, edit, status, hapus, CSV, cetak)
│   ├── messages.php, administrators.php
│   └── includes/{layout.php, modules.php}
├── database/smk_infokom.sql
└── README.md
```
Seluruh modul CRUD didefinisikan di `admin/includes/modules.php` (nama tabel, kolom, validasi, upload). Untuk menambah modul baru, cukup menambah satu entri di file tersebut.

## Catatan konten
- Logo, foto kepala sekolah, foto guru, dan brosur PPDB di project ini adalah **gambar contoh/placeholder**. Brosur contoh bertuliskan "CONTOH BROSUR PPDB". Ganti semuanya lewat dashboard.
- Program keahlian (RPL, TKJ, DKV), jumlah siswa/guru dan angka statistik hanyalah **contoh/perkiraan awal** dan perlu disesuaikan dengan data resmi sekolah.
- Tidak ada nama kepala sekolah, guru, atau nomor pribadi yang dikarang; semuanya berlabel "(contoh)".
- Tautan media sosial bawaan hanya mengarah ke beranda platform; ganti dengan akun resmi sekolah.
