<?php
/** Pesan pengunjung: lihat, baca, tandai (bintang / belum dibaca), hapus. */
require_once __DIR__ . '/includes/layout.php';
require_admin();

$self = admin_url('messages.php');
$q = get_str('q'); $filter = get_str('filter');
if (!in_array($filter, ['unread', 'read', 'starred'], true)) $filter = '';
$listUrl = $self . '?' . http_build_query(array_filter(['q' => $q, 'filter' => $filter]));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf($listUrl);
    $do = post_str('do'); $pid = (int)post_str('id');
    $row = q_one('SELECT * FROM contact_messages WHERE id = ?', [$pid]);
    if (!$row) { flash('warning', 'Pesan tidak ditemukan.'); redirect($listUrl); }
    $back = post_str('back') === 'detail' ? $self . '?id=' . $pid : $listUrl;
    switch ($do) {
        case 'delete': q_exec('DELETE FROM contact_messages WHERE id = ?', [$pid]); log_activity('Hapus Pesan', excerpt($row['subject'], 80)); flash('success', 'Pesan berhasil dihapus.'); redirect($listUrl);
        case 'star': q_exec('UPDATE contact_messages SET is_starred = 1 - is_starred WHERE id = ?', [$pid]); flash('success', $row['is_starred'] ? 'Tanda bintang dihapus.' : 'Pesan ditandai penting.'); redirect($back);
        case 'unread': q_exec('UPDATE contact_messages SET is_read = 0 WHERE id = ?', [$pid]); flash('success', 'Pesan ditandai belum dibaca.'); redirect($listUrl);
        case 'read': q_exec('UPDATE contact_messages SET is_read = 1 WHERE id = ?', [$pid]); flash('success', 'Pesan ditandai sudah dibaca.'); redirect($back);
    }
    redirect($listUrl);
}

$id = (int)get_str('id', '0');
if ($id) {
    $m = q_one('SELECT * FROM contact_messages WHERE id = ?', [$id]);
    if (!$m) { flash('warning', 'Pesan tidak ditemukan.'); redirect($self); }
    if (!$m['is_read']) { q_exec('UPDATE contact_messages SET is_read = 1 WHERE id = ?', [$id]); $m['is_read'] = 1; }
    admin_head('Baca Pesan', ['Pesan Pengunjung' => $self]);
    ?>
    <div class="adm-card">
        <div class="d-flex flex-wrap justify-content-between gap-2 mb-3"><div><h2 class="h4 mb-1"><?= e($m['subject']) ?></h2><div class="text-muted small">Dari <strong><?= e($m['name']) ?></strong> &lt;<a href="mailto:<?= e($m['email']) ?>"><?= e($m['email']) ?></a>&gt; &bull; <?= e(tgl_indo($m['created_at'], true)) ?></div></div><?= $m['is_starred'] ? '<span class="badge bg-warning text-dark align-self-start"><i class="fa-solid fa-star"></i> Penting</span>' : '' ?></div>
        <div class="p-3 bg-body-tertiary rounded-3 mb-4" style="white-space:pre-wrap"><?= e($m['message']) ?></div>
        <div class="d-flex flex-wrap gap-2">
            <a class="btn btn-primary" href="mailto:<?= e($m['email']) ?>?subject=<?= rawurlencode('Re: ' . $m['subject']) ?>"><i class="fa-solid fa-reply me-1"></i>Balas via Email</a>
            <form method="post" action="<?= e($self) ?>"><?= csrf_field() ?><input type="hidden" name="do" value="star"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="back" value="detail"><button class="btn btn-outline-warning"><i class="fa-solid fa-star me-1"></i><?= $m['is_starred'] ? 'Hapus Bintang' : 'Tandai Penting' ?></button></form>
            <form method="post" action="<?= e($self) ?>"><?= csrf_field() ?><input type="hidden" name="do" value="unread"><input type="hidden" name="id" value="<?= $id ?>"><button class="btn btn-outline-secondary"><i class="fa-solid fa-envelope me-1"></i>Tandai Belum Dibaca</button></form>
            <a class="btn btn-light" href="<?= e($self) ?>">Kembali</a>
            <button class="btn btn-outline-danger ms-auto" type="button" data-delete="<?= $id ?>" data-name="<?= e(excerpt($m['subject'], 50)) ?>" data-action="<?= e($self) ?>"><i class="fa-solid fa-trash me-1"></i>Hapus</button>
        </div>
    </div>
    <?php admin_foot(); exit;
}

$w = []; $p = [];
if ($filter === 'unread') $w[] = 'is_read = 0'; elseif ($filter === 'read') $w[] = 'is_read = 1'; elseif ($filter === 'starred') $w[] = 'is_starred = 1';
if ($q !== '') { $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $q) . '%'; $w[] = '(name LIKE ? OR email LIKE ? OR subject LIKE ? OR message LIKE ?)'; array_push($p, $like, $like, $like, $like); }
$ws = $w ? 'WHERE ' . implode(' AND ', $w) : '';
$total = (int)q_val("SELECT COUNT(*) FROM contact_messages $ws", $p);
$pg = paginate($total, 10, (int)get_str('page', '1'));
$rows = q_all("SELECT * FROM contact_messages $ws ORDER BY id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $p);
$cnt = ['all' => (int)q_val('SELECT COUNT(*) FROM contact_messages'), 'unread' => (int)q_val('SELECT COUNT(*) FROM contact_messages WHERE is_read = 0'), 'starred' => (int)q_val('SELECT COUNT(*) FROM contact_messages WHERE is_starred = 1')];
admin_head('Pesan Pengunjung');
?>
<div class="adm-card">
    <div class="alert alert-info small"><i class="fa-solid fa-shield-halved me-1"></i> Data pengirim hanya terlihat oleh admin dan tidak ditampilkan di website.</div>
    <div class="adm-pills mb-3"><a class="<?= $filter === '' ? 'active' : '' ?>" href="<?= e($self) ?>">Semua (<?= $cnt['all'] ?>)</a><a class="<?= $filter === 'unread' ? 'active' : '' ?>" href="<?= e($self . '?filter=unread') ?>">Belum dibaca (<?= $cnt['unread'] ?>)</a><a class="<?= $filter === 'read' ? 'active' : '' ?>" href="<?= e($self . '?filter=read') ?>">Sudah dibaca</a><a class="<?= $filter === 'starred' ? 'active' : '' ?>" href="<?= e($self . '?filter=starred') ?>">Penting (<?= $cnt['starred'] ?>)</a></div>
    <form class="d-flex gap-2 mb-3" method="get" role="search" style="max-width:460px"><?php if ($filter): ?><input type="hidden" name="filter" value="<?= e($filter) ?>"><?php endif; ?><input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="Cari pesan..." aria-label="Cari"><button class="btn btn-outline-primary" aria-label="Cari"><i class="fa-solid fa-magnifying-glass"></i></button><?php if ($q !== ''): ?><a class="btn btn-light" href="<?= e($self) ?>">Reset</a><?php endif; ?></form>
    <div class="table-responsive"><table class="table adm-table align-middle"><thead><tr><th style="width:40px"></th><th>Pengirim</th><th>Subjek</th><th>Tanggal</th><th class="text-end" style="width:210px">Aksi</th></tr></thead><tbody>
    <?php if (!$rows): ?><tr><td colspan="5" class="text-center text-muted py-5"><i class="fa-regular fa-envelope-open fa-2x d-block mb-2"></i>Tidak ada pesan.</td></tr><?php endif; ?>
    <?php foreach ($rows as $m): ?><tr class="<?= $m['is_read'] ? '' : 'row-unread' ?>"><td><?= $m['is_starred'] ? '<i class="fa-solid fa-star text-warning"></i>' : '' ?></td><td><strong><?= e($m['name']) ?></strong><small class="d-block text-muted"><?= e($m['email']) ?></small></td><td><a href="<?= e($self . '?id=' . $m['id']) ?>"><?= e(excerpt($m['subject'], 60)) ?></a><small class="d-block text-muted"><?= e(excerpt($m['message'], 70)) ?></small></td><td class="text-nowrap"><?= e(tgl_indo($m['created_at'])) ?></td>
        <td class="text-end text-nowrap"><a class="btn btn-sm btn-outline-secondary" href="<?= e($self . '?id=' . $m['id']) ?>" aria-label="Baca" title="Baca"><i class="fa-solid fa-envelope-open"></i></a>
        <form class="d-inline" method="post" action="<?= e($listUrl) ?>"><?= csrf_field() ?><input type="hidden" name="do" value="star"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>"><button class="btn btn-sm btn-outline-warning" aria-label="Tandai penting" title="Tandai penting"><i class="fa-solid fa-star"></i></button></form>
        <form class="d-inline" method="post" action="<?= e($listUrl) ?>"><?= csrf_field() ?><input type="hidden" name="do" value="<?= $m['is_read'] ? 'unread' : 'read' ?>"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>"><button class="btn btn-sm btn-outline-primary" aria-label="<?= $m['is_read'] ? 'Tandai belum dibaca' : 'Tandai sudah dibaca' ?>" title="<?= $m['is_read'] ? 'Tandai belum dibaca' : 'Tandai sudah dibaca' ?>"><i class="fa-solid <?= $m['is_read'] ? 'fa-envelope' : 'fa-check' ?>"></i></button></form>
        <button class="btn btn-sm btn-outline-danger" type="button" data-delete="<?= (int)$m['id'] ?>" data-name="<?= e(excerpt($m['subject'], 50)) ?>" data-action="<?= e($listUrl) ?>" aria-label="Hapus" title="Hapus"><i class="fa-solid fa-trash"></i></button></td></tr><?php endforeach; ?>
    </tbody></table></div>
    <?= admin_pagination($pg, ['q' => $q, 'filter' => $filter]) ?>
</div>
<?php admin_foot();
