<?php
/** Layout dashboard admin: sidebar kiri, header, breadcrumb, modal hapus, footer. */
require_once dirname(__DIR__, 2) . '/includes/functions.php';
require_once dirname(__DIR__, 2) . '/includes/auth.php';
require_once __DIR__ . '/modules.php';

function crud_link(string $m, string $f = '', string $a = ''): string
{
    $q = ['m' => $m];
    if ($f !== '') $q['f'] = $f;
    if ($a !== '') $q['a'] = $a;
    return admin_url('crud.php?' . http_build_query($q));
}
function admin_menu(): array
{
    $st = fn($g) => admin_url('settings.php?g=' . $g);
    return [
        'Dashboard' => ['fa-gauge-high', [
            ['Ringkasan Statistik', 'fa-chart-column', admin_url('dashboard.php'), 'dashboard.php'],
            ['Aktivitas Terbaru', 'fa-clock-rotate-left', admin_url('dashboard.php#aktivitas'), 'dashboard.php#'],
        ]],
        'Profil Sekolah' => ['fa-school', [
            ['Identitas Sekolah', 'fa-id-card', $st('identitas'), 'settings.php?g=identitas'],
            ['Sambutan Kepala Sekolah', 'fa-user-tie', crud_link('principal'), 'crud.php?m=principal'],
            ['Sejarah Sekolah', 'fa-landmark', crud_link('history'), 'crud.php?m=history'],
            ['Visi dan Misi', 'fa-bullseye', crud_link('vision'), 'crud.php?m=vision'],
            ['Tujuan Sekolah', 'fa-flag-checkered', crud_link('vision', 'tujuan'), 'crud.php?m=vision&f=tujuan'],
            ['Struktur Organisasi', 'fa-sitemap', crud_link('organization'), 'crud.php?m=organization'],
            ['Fasilitas Sekolah', 'fa-building', crud_link('facilities'), 'crud.php?m=facilities'],
            ['Data Statistik Sekolah', 'fa-chart-pie', $st('statistik'), 'settings.php?g=statistik'],
        ]],
        'Akademik' => ['fa-graduation-cap', [
            ['Program Keahlian', 'fa-laptop-code', crud_link('programs'), 'crud.php?m=programs'],
            ['Kurikulum', 'fa-book-open', crud_link('curriculum'), 'crud.php?m=curriculum'],
            ['Kalender Pendidikan', 'fa-calendar-days', crud_link('calendar'), 'crud.php?m=calendar'],
            ['PKL', 'fa-briefcase', crud_link('pkl'), 'crud.php?m=pkl'],
            ['BKK', 'fa-handshake', crud_link('bkk'), 'crud.php?m=bkk'],
            ['Program Kerja Luar Negeri', 'fa-earth-asia', crud_link('overseas', 'luar_negeri'), 'crud.php?m=overseas&f=luar_negeri'],
            ['Program Kerja ke Jepang', 'fa-torii-gate', crud_link('overseas', 'jepang'), 'crud.php?m=overseas&f=jepang'],
        ]],
        'Guru dan Staff' => ['fa-chalkboard-user', [
            ['Pimpinan Sekolah', 'fa-user-tie', crud_link('staff', 'pimpinan'), 'crud.php?m=staff&f=pimpinan'],
            ['Wakil Kepala Sekolah', 'fa-user-group', crud_link('staff', 'wakasek'), 'crud.php?m=staff&f=wakasek'],
            ['Guru', 'fa-chalkboard-user', crud_link('staff', 'guru'), 'crud.php?m=staff&f=guru'],
            ['Staff Usaha', 'fa-folder-open', crud_link('staff', 'staff_usaha'), 'crud.php?m=staff&f=staff_usaha'],
            ['Staff Kurikulum', 'fa-book-bookmark', crud_link('staff', 'staff_kurikulum'), 'crud.php?m=staff&f=staff_kurikulum'],
            ['Semua Profil', 'fa-users', crud_link('staff'), 'crud.php?m=staff'],
        ]],
        'Kesiswaan' => ['fa-users', [
            ['Beranda Kesiswaan', 'fa-house-user', crud_link('affairs'), 'crud.php?m=affairs'],
            ['OSIS', 'fa-people-group', crud_link('osis'), 'crud.php?m=osis'],
            ['Ekstrakurikuler', 'fa-futbol', crud_link('ekskul'), 'crud.php?m=ekskul'],
            ['Prestasi Siswa', 'fa-trophy', crud_link('achievements'), 'crud.php?m=achievements'],
            ['Kegiatan Siswa', 'fa-camera-retro', crud_link('activities'), 'crud.php?m=activities'],
            ['Tata Tertib', 'fa-scale-balanced', crud_link('rules'), 'crud.php?m=rules'],
        ]],
        'PPDB Online' => ['fa-user-plus', [
            ['Informasi & Tahun Ajaran', 'fa-bullhorn', $st('ppdb'), 'settings.php?g=ppdb'],
            ['Jadwal Pendaftaran', 'fa-calendar-days', crud_link('ppdb_info', 'jadwal'), 'crud.php?m=ppdb_info&f=jadwal'],
            ['Persyaratan', 'fa-clipboard-check', crud_link('ppdb_info', 'persyaratan'), 'crud.php?m=ppdb_info&f=persyaratan'],
            ['Alur, Jalur & FAQ', 'fa-route', crud_link('ppdb_info'), 'crud.php?m=ppdb_info'],
            ['Brosur PPDB', 'fa-file-image', $st('ppdb_brosur'), 'settings.php?g=ppdb_brosur'],
            ['Data Pendaftar', 'fa-users-rectangle', admin_url('ppdb_registrations.php'), 'ppdb_registrations.php'],
            ['Pengaturan Formulir', 'fa-sliders', $st('ppdb_form'), 'settings.php?g=ppdb_form'],
        ]],
        'Berita' => ['fa-newspaper', [
            ['Daftar Berita', 'fa-list', crud_link('news'), 'crud.php?m=news'],
            ['Tambah Berita', 'fa-plus', crud_link('news', '', 'add'), 'crud.php?m=news&a=add'],
            ['Kategori Berita', 'fa-tags', crud_link('news_cat'), 'crud.php?m=news_cat'],
        ]],
        'Galeri' => ['fa-images', [
            ['Daftar Foto', 'fa-list', crud_link('gallery'), 'crud.php?m=gallery'],
            ['Tambah Foto', 'fa-plus', crud_link('gallery', '', 'add'), 'crud.php?m=gallery&a=add'],
            ['Kategori Galeri', 'fa-folder', crud_link('gallery_cat'), 'crud.php?m=gallery_cat'],
        ]],
        'Agenda' => ['fa-calendar-check', [
            ['Daftar Agenda', 'fa-list', crud_link('agendas'), 'crud.php?m=agendas'],
            ['Tambah Agenda', 'fa-plus', crud_link('agendas', '', 'add'), 'crud.php?m=agendas&a=add'],
            ['Kategori Agenda', 'fa-folder', crud_link('agenda_cat'), 'crud.php?m=agenda_cat'],
        ]],
        'Kontak' => ['fa-envelope', [
            ['Informasi Kontak Sekolah', 'fa-address-book', $st('kontak'), 'settings.php?g=kontak'],
            ['Media Sosial', 'fa-share-nodes', crud_link('social'), 'crud.php?m=social'],
            ['Pesan Pengunjung', 'fa-inbox', admin_url('messages.php'), 'messages.php'],
        ]],
        'Pengaturan Website' => ['fa-gear', [
            ['Logo, Favicon & Umum', 'fa-image', $st('umum'), 'settings.php?g=umum'],
            ['Tampilan Beranda (Hero)', 'fa-panorama', $st('hero'), 'settings.php?g=hero'],
            ['Footer', 'fa-shoe-prints', $st('footer'), 'settings.php?g=footer'],
            ['SEO Dasar', 'fa-magnifying-glass-chart', $st('seo'), 'settings.php?g=seo'],
        ]],
        'Administrator' => ['fa-user-shield', [
            ['Profil Admin', 'fa-id-badge', admin_url('administrators.php?a=profile'), 'administrators.php?a=profile'],
            ['Ganti Password', 'fa-key', admin_url('administrators.php?a=password'), 'administrators.php?a=password'],
            ['Kelola Akun Admin', 'fa-users-gear', admin_url('administrators.php?a=list'), 'administrators.php?a=list'],
        ]],
    ];
}
function menu_is_active(string $spec): bool
{
    $cur = current_script();
    $parts = explode('?', $spec, 2);
    if ($parts[0] === 'dashboard.php#') return false;
    if ($parts[0] !== $cur) return false;
    if (!isset($parts[1])) return true;
    parse_str($parts[1], $want);
    foreach ($want as $k => $v) if (get_str($k) !== $v) return false;
    // tautan tanpa filter hanya aktif bila filter kosong
    if ($cur === 'crud.php' && !isset($want['f']) && get_str('f') !== '' && !isset($want['a'])) return false;
    if ($cur === 'crud.php' && !isset($want['a']) && get_str('a') === 'add') return false;
    return true;
}

function admin_head(string $title, array $crumbs = []): void
{
    require_admin();
    $adm = $GLOBALS['CURRENT_ADMIN'];
    $unread = (int)q_val('SELECT COUNT(*) FROM contact_messages WHERE is_read = 0');
    $newReg = (int)q_val("SELECT COUNT(*) FROM ppdb_registrations WHERE status = 'menunggu'");
    $menu = admin_menu();
    ?>
<!DOCTYPE html>
<html lang="id" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?= e($title) ?> | Admin <?= e(setting('school_name')) ?></title>
    <link rel="icon" href="<?= e(favicon_url()) ?>">
    <script>try{var t=localStorage.getItem('adm-theme');if(t)document.documentElement.setAttribute('data-theme',t)}catch(e){}</script>
    <link rel="stylesheet" href="<?= asset('vendor/bootstrap/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="<?= asset('vendor/fontawesome/css/all.min.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/admin.css') ?>?v=4">
</head>
<body class="admin-body">
<div class="adm-overlay" id="admOverlay"></div>
<aside class="adm-sidebar" id="admSidebar" aria-label="Menu admin">
    <a class="adm-brand" href="<?= admin_url('dashboard.php') ?>"><img src="<?= e(logo_url()) ?>" alt="Logo" width="44" height="44"><span><strong><?= e(setting('school_name')) ?></strong><small>Dashboard Admin</small></span></a>
    <nav class="adm-nav">
        <?php $gi = 0; foreach ($menu as $group => [$gicon, $items]): $gi++;
            $open = false; foreach ($items as $it) if (menu_is_active($it[3])) $open = true; ?>
        <div class="adm-group">
            <button class="adm-group-btn <?= $open ? '' : 'collapsed' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#g<?= $gi ?>" aria-expanded="<?= $open ? 'true' : 'false' ?>">
                <i class="fa-solid <?= $gicon ?>"></i><span><?= e($group) ?></span><i class="fa-solid fa-chevron-down caret"></i>
            </button>
            <div class="collapse <?= $open ? 'show' : '' ?>" id="g<?= $gi ?>"><ul>
                <?php foreach ($items as $it): ?>
                    <li><a class="<?= menu_is_active($it[3]) ? 'active' : '' ?>" href="<?= e($it[2]) ?>"><i class="fa-solid <?= $it[1] ?>"></i><?= e($it[0]) ?>
                        <?php if ($it[0] === 'Pesan Pengunjung' && $unread): ?><span class="badge bg-warning text-dark ms-auto"><?= $unread ?></span><?php endif; ?>
                        <?php if ($it[0] === 'Data Pendaftar' && $newReg): ?><span class="badge bg-warning text-dark ms-auto"><?= $newReg ?></span><?php endif; ?></a></li>
                <?php endforeach; ?>
                <?php if ($group === 'Administrator'): ?>
                    <li><form method="post" action="<?= admin_url('logout.php') ?>"><?= csrf_field() ?><button type="submit" class="adm-logout"><i class="fa-solid fa-right-from-bracket"></i>Logout</button></form></li>
                <?php endif; ?>
            </ul></div>
        </div>
        <?php endforeach; ?>
    </nav>
</aside>
<div class="adm-main">
    <header class="adm-topbar">
        <button class="btn adm-toggle" id="admToggle" type="button" aria-label="Buka menu"><i class="fa-solid fa-bars"></i></button>
        <div class="adm-title d-none d-md-block"><?= e($title) ?></div>
        <div class="ms-auto d-flex align-items-center gap-2">
            <a class="btn btn-sm btn-outline-primary" href="<?= url('index.php') ?>" target="_blank" rel="noopener"><i class="fa-solid fa-up-right-from-square me-1"></i><span class="d-none d-sm-inline">Lihat Website</span></a>
            <button class="btn btn-sm btn-outline-secondary" id="themeToggle" type="button" aria-label="Ganti mode gelap/terang" title="Mode gelap/terang"><i class="fa-solid fa-moon"></i></button>
            <div class="dropdown">
                <button class="adm-user dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><span class="avatar"><?= e(mb_strtoupper(mb_substr($adm['full_name'], 0, 1))) ?></span><span class="d-none d-sm-inline"><?= e($adm['full_name']) ?></span></button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><span class="dropdown-item-text small text-muted">Masuk sebagai<br><strong><?= e($adm['username']) ?></strong></span></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="<?= admin_url('administrators.php?a=profile') ?>"><i class="fa-solid fa-id-badge me-2"></i>Profil</a></li>
                    <li><a class="dropdown-item" href="<?= admin_url('administrators.php?a=password') ?>"><i class="fa-solid fa-key me-2"></i>Ganti Password</a></li>
                    <li><form method="post" action="<?= admin_url('logout.php') ?>"><?= csrf_field() ?><button class="dropdown-item text-danger" type="submit"><i class="fa-solid fa-right-from-bracket me-2"></i>Logout</button></form></li>
                </ul>
            </div>
        </div>
    </header>
    <div class="adm-content">
        <div class="adm-pagehead">
            <h1><?= e($title) ?></h1>
            <nav aria-label="breadcrumb"><ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?= admin_url('dashboard.php') ?>"><i class="fa-solid fa-house"></i> Dashboard</a></li>
                <?php foreach ($crumbs as $label => $href): ?><li class="breadcrumb-item"><?= $href ? '<a href="' . e($href) . '">' . e($label) . '</a>' : e($label) ?></li><?php endforeach; ?>
                <li class="breadcrumb-item active" aria-current="page"><?= e($title) ?></li>
            </ol></nav>
        </div>
        <?= flash_render() ?>
<?php }

function admin_foot(string $extraScripts = ''): void
{ ?>
    </div>
    <footer class="adm-footer">&copy; <?= date('Y') ?> <?= e(setting('school_name')) ?> &bull; Dashboard Admin</footer>
</div>

<!-- Modal konfirmasi hapus (POST + CSRF) -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered"><div class="modal-content">
        <form method="post" id="deleteForm">
            <?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" id="deleteId">
            <div class="modal-header"><h2 class="modal-title h5" id="deleteTitle"><i class="fa-solid fa-triangle-exclamation text-danger me-2"></i>Konfirmasi Hapus</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button></div>
            <div class="modal-body">Anda yakin ingin menghapus <strong id="deleteName">data ini</strong>? Tindakan ini tidak dapat dibatalkan.</div>
            <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button><button type="submit" class="btn btn-danger"><i class="fa-solid fa-trash me-1"></i>Ya, Hapus</button></div>
        </form>
    </div></div>
</div>
<script src="<?= asset('vendor/bootstrap/bootstrap.bundle.min.js') ?>"></script>
<script src="<?= asset('js/admin.js') ?>?v=3"></script>
<?= $extraScripts ?>
</body>
</html>
<?php }

/** Tabel pagination admin + info jumlah data */
function admin_pagination(array $pg, array $keep): string
{
    $info = $pg['total'] === 0 ? 'Tidak ada data' : 'Menampilkan ' . ($pg['offset'] + 1) . '–' . min($pg['offset'] + $pg['per'], $pg['total']) . ' dari ' . $pg['total'] . ' data';
    return '<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3"><small class="text-muted">' . e($info) . '</small>' . pagination_html($pg, $keep) . '</div>';
}
