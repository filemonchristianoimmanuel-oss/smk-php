<?php
/**
 * Konfigurasi seluruh modul CRUD admin.
 * Satu mesin (admin/crud.php) membaca konfigurasi ini sehingga setiap modul
 * memiliki: daftar + pencarian + pagination, tambah, edit, hapus (POST + CSRF), upload gambar, dan validasi.
 */
function F(string $name, string $label, string $type = 'text', array $o = []): array
{
    return array_merge(['name' => $name, 'label' => $label, 'type' => $type], $o);
}
function yn_field(string $name = 'is_published', string $label = 'Tampilkan di website'): array
{
    return F($name, $label, 'bool', ['default' => 1]);
}
function program_icons(): array
{
    return [
        'fa-solid fa-laptop-code' => 'Laptop Kode (RPL)', 'fa-solid fa-code' => 'Kode', 'fa-solid fa-network-wired' => 'Jaringan (TKJ)',
        'fa-solid fa-palette' => 'Palet (Desain)', 'fa-solid fa-camera' => 'Kamera', 'fa-solid fa-film' => 'Film / Video',
        'fa-solid fa-calculator' => 'Kalkulator (Akuntansi)', 'fa-solid fa-briefcase' => 'Tas (Perkantoran)', 'fa-solid fa-microchip' => 'Chip (Elektronika)',
        'fa-solid fa-gears' => 'Mesin', 'fa-solid fa-server' => 'Server', 'fa-solid fa-shield-halved' => 'Keamanan', 'fa-solid fa-mobile-screen' => 'Mobile',
        'fa-solid fa-chart-line' => 'Grafik (Bisnis)', 'fa-solid fa-robot' => 'Robot', 'fa-solid fa-graduation-cap' => 'Topi Wisuda',
    ];
}
function social_icons(): array
{
    return ['fa-brands fa-instagram' => 'Instagram', 'fa-brands fa-facebook-f' => 'Facebook', 'fa-brands fa-youtube' => 'YouTube', 'fa-brands fa-tiktok' => 'TikTok',
        'fa-brands fa-x-twitter' => 'X (Twitter)', 'fa-brands fa-whatsapp' => 'WhatsApp', 'fa-brands fa-telegram' => 'Telegram', 'fa-brands fa-linkedin-in' => 'LinkedIn', 'fa-solid fa-globe' => 'Website lain'];
}

function crud_modules(): array
{
    static $m = null;
    if ($m !== null) return $m;
    $sortField = F('sort_order', 'Urutan tampil', 'number', ['default' => 0, 'help' => 'Angka kecil tampil lebih dulu.']);

    $m = [
    // ---------------------------------------------------------------- PROFIL SEKOLAH
    'principal' => ['title' => 'Sambutan Kepala Sekolah', 'icon' => 'fa-user-tie', 'table' => 'principal_greetings', 'dir' => 'principal',
        'list' => [['photo', 'Foto', 'image'], ['name', 'Nama'], ['title', 'Judul'], ['period', 'Periode'], ['is_active', 'Aktif', 'bool']],
        'search' => ['name', 'title', 'content'], 'order' => 'id DESC', 'exclusive' => 'is_active',
        'note' => 'Hanya satu sambutan yang aktif. Sambutan aktif tampil di Beranda dan Profil Sekolah.',
        'fields' => [
            F('name', 'Nama Kepala Sekolah', 'text', ['required' => 1, 'max' => 150]),
            F('position', 'Jabatan', 'text', ['required' => 1, 'max' => 150, 'default' => 'Kepala Sekolah']),
            F('title', 'Judul Sambutan', 'text', ['required' => 1, 'max' => 200, 'default' => 'Sambutan Kepala Sekolah']),
            F('content', 'Isi Sambutan', 'textarea', ['required' => 1, 'rows' => 10, 'help' => 'Pisahkan paragraf dengan baris kosong.']),
            F('photo', 'Foto Kepala Sekolah', 'image', ['help' => 'JPG/PNG/WEBP maks. 3 MB. Disarankan rasio 4:5 (potret).']),
            F('period', 'Tanggal / Periode Sambutan', 'text', ['max' => 60, 'placeholder' => 'Contoh: Tahun Ajaran 2026/2027']),
            F('is_active', 'Jadikan sambutan aktif', 'bool', ['default' => 1]),
        ]],
    'history' => ['title' => 'Sejarah Sekolah', 'icon' => 'fa-landmark', 'table' => 'school_history', 'dir' => 'general',
        'list' => [['image', 'Gambar', 'image'], ['year_label', 'Tahun'], ['title', 'Judul'], ['sort_order', 'Urutan'], ['is_published', 'Tampil', 'bool']],
        'search' => ['title', 'content', 'year_label'], 'order' => 'sort_order, id',
        'fields' => [F('year_label', 'Tahun / Periode', 'text', ['max' => 30, 'placeholder' => 'Contoh: 2005']), F('title', 'Judul', 'text', ['required' => 1, 'max' => 200]),
            F('content', 'Isi Sejarah', 'textarea', ['required' => 1, 'rows' => 8]), F('image', 'Gambar (opsional)', 'image'), $sortField, yn_field()]],
    'vision' => ['title' => 'Visi, Misi, dan Tujuan', 'icon' => 'fa-bullseye', 'table' => 'school_vision_mission', 'dir' => 'general',
        'list' => [['type', 'Jenis', 'select'], ['content', 'Isi'], ['sort_order', 'Urutan'], ['is_published', 'Tampil', 'bool']],
        'search' => ['content'], 'order' => "FIELD(type,'visi','misi','tujuan'), sort_order, id", 'filter_field' => 'type',
        'fields' => [F('type', 'Jenis', 'select', ['required' => 1, 'options' => ['visi' => 'Visi', 'misi' => 'Misi', 'tujuan' => 'Tujuan']]),
            F('content', 'Isi', 'textarea', ['required' => 1, 'rows' => 4, 'help' => 'Satu butir per data. Misi dan tujuan tampil bernomor sesuai urutan.']), $sortField, yn_field()]],
    'organization' => ['title' => 'Struktur Organisasi', 'icon' => 'fa-sitemap', 'table' => 'school_organization', 'dir' => 'general',
        'list' => [['level', 'Tingkat'], ['position', 'Jabatan'], ['name', 'Nama'], ['sort_order', 'Urutan'], ['is_published', 'Tampil', 'bool']],
        'search' => ['position', 'name'], 'order' => 'level, sort_order, id',
        'note' => 'Bagan ditampilkan berjenjang menurut Tingkat (1 = paling atas). Anda juga dapat mengunggah gambar bagan di Profil Sekolah > Identitas.',
        'fields' => [F('level', 'Tingkat (1 = teratas)', 'number', ['required' => 1, 'default' => 1, 'min' => 1, 'max' => 6]), F('position', 'Jabatan', 'text', ['required' => 1, 'max' => 150]),
            F('name', 'Nama', 'text', ['max' => 150]), F('description', 'Keterangan', 'text', ['max' => 255]), $sortField, yn_field()]],
    'facilities' => ['title' => 'Fasilitas Sekolah', 'icon' => 'fa-building', 'table' => 'school_facilities', 'dir' => 'facilities',
        'list' => [['image', 'Foto', 'image'], ['name', 'Nama'], ['description', 'Deskripsi'], ['sort_order', 'Urutan'], ['is_published', 'Tampil', 'bool']],
        'search' => ['name', 'description'], 'order' => 'sort_order, id',
        'fields' => [F('name', 'Nama Fasilitas', 'text', ['required' => 1, 'max' => 150]), F('description', 'Deskripsi', 'textarea', ['rows' => 4]),
            F('image', 'Foto Fasilitas', 'image', ['help' => 'Disarankan rasio 4:3.']), $sortField, yn_field()]],

    // ---------------------------------------------------------------- AKADEMIK
    'programs' => ['title' => 'Program Keahlian', 'icon' => 'fa-laptop-code', 'table' => 'study_programs', 'dir' => 'programs',
        'list' => [['image', 'Gambar', 'image'], ['short_name', 'Singkatan'], ['name', 'Nama Program'], ['sort_order', 'Urutan'], ['is_published', 'Tampil', 'bool']],
        'search' => ['name', 'short_name', 'description'], 'order' => 'sort_order, id',
        'fields' => [F('name', 'Nama Program Keahlian', 'text', ['required' => 1, 'max' => 150]), F('slug', 'Slug URL (otomatis)', 'slug', ['from' => 'name', 'help' => 'Dikosongkan = dibuat otomatis dari nama.']),
            F('short_name', 'Singkatan', 'text', ['max' => 30, 'placeholder' => 'RPL']), F('icon', 'Ikon', 'select', ['options' => program_icons(), 'default' => 'fa-solid fa-laptop-code']),
            F('image', 'Gambar / Logo Program', 'image'), F('description', 'Deskripsi', 'textarea', ['required' => 1, 'rows' => 4]),
            F('competencies', 'Kompetensi yang Dipelajari', 'textarea', ['rows' => 5, 'help' => 'Satu butir per baris, awali dengan tanda "- ".']),
            F('career_prospects', 'Prospek Karier', 'textarea', ['rows' => 4, 'help' => 'Satu butir per baris, awali dengan tanda "- ".']),
            F('supporting_facilities', 'Fasilitas Pendukung', 'textarea', ['rows' => 4, 'help' => 'Satu butir per baris, awali dengan tanda "- ".']), $sortField, yn_field()]],
    'curriculum' => ['title' => 'Kurikulum', 'icon' => 'fa-book-open', 'table' => 'curriculum', 'dir' => 'general',
        'list' => [['category', 'Kategori', 'select'], ['title', 'Judul'], ['sort_order', 'Urutan'], ['is_published', 'Tampil', 'bool']],
        'search' => ['title', 'content'], 'order' => "FIELD(category,'informasi','program','kegiatan','pendukung'), sort_order, id", 'filter_field' => 'category',
        'fields' => [F('category', 'Kategori', 'select', ['required' => 1, 'options' => ['informasi' => 'Kurikulum yang diterapkan', 'program' => 'Program pembelajaran', 'kegiatan' => 'Kegiatan pembelajaran', 'pendukung' => 'Informasi pendukung akademik']]),
            F('title', 'Judul', 'text', ['required' => 1, 'max' => 200]), F('content', 'Isi', 'textarea', ['required' => 1, 'rows' => 7]), $sortField, yn_field()]],
    'calendar' => ['title' => 'Kalender Pendidikan', 'icon' => 'fa-calendar-days', 'table' => 'academic_calendar', 'dir' => 'general',
        'list' => [['academic_year', 'Tahun Ajaran'], ['title', 'Kegiatan'], ['category', 'Kategori', 'select'], ['start_date', 'Mulai', 'date'], ['end_date', 'Selesai', 'date'], ['is_published', 'Tampil', 'bool']],
        'search' => ['title', 'academic_year', 'description'], 'order' => 'start_date DESC, id DESC', 'filter_field' => 'category',
        'fields' => [F('academic_year', 'Tahun Ajaran', 'text', ['required' => 1, 'max' => 20, 'default' => '2026/2027', 'placeholder' => '2026/2027']),
            F('title', 'Nama Kegiatan', 'text', ['required' => 1, 'max' => 200]),
            F('category', 'Kategori', 'select', ['required' => 1, 'options' => ['hari_efektif' => 'Hari Efektif', 'libur' => 'Libur Sekolah', 'ujian' => 'Ujian', 'akademik' => 'Kegiatan Akademik', 'ppdb' => 'Penerimaan Siswa Baru']]),
            F('start_date', 'Tanggal Mulai', 'date', ['required' => 1]), F('end_date', 'Tanggal Selesai', 'date', ['help' => 'Kosongkan jika satu hari.', 'after' => 'start_date']),
            F('description', 'Keterangan', 'text', ['max' => 255]), yn_field()]],
    'pkl' => ['title' => 'Praktik Kerja Lapangan (PKL)', 'icon' => 'fa-briefcase', 'table' => 'internship_information', 'dir' => 'general',
        'list' => [['image', 'Gambar', 'image'], ['section', 'Bagian', 'select'], ['title', 'Judul'], ['sort_order', 'Urutan'], ['is_published', 'Tampil', 'bool']],
        'search' => ['title', 'content'], 'order' => "FIELD(section,'pengertian','tujuan','tahapan','mitra','dokumentasi','pengumuman'), sort_order, id", 'filter_field' => 'section',
        'fields' => [F('section', 'Bagian', 'select', ['required' => 1, 'options' => ['pengertian' => 'Pengertian PKL', 'tujuan' => 'Tujuan PKL', 'tahapan' => 'Tahapan PKL', 'mitra' => 'Mitra Industri', 'dokumentasi' => 'Dokumentasi Kegiatan', 'pengumuman' => 'Pengumuman PKL']]),
            F('title', 'Judul / Nama', 'text', ['required' => 1, 'max' => 200]), F('content', 'Isi / Keterangan', 'textarea', ['rows' => 6]), F('image', 'Gambar / Logo mitra', 'image'),
            F('info_date', 'Tanggal informasi', 'date'), $sortField, yn_field()]],
    'bkk' => ['title' => 'Bursa Kerja Khusus (BKK)', 'icon' => 'fa-handshake', 'table' => 'job_center', 'dir' => 'general',
        'list' => [['image', 'Gambar', 'image'], ['section', 'Bagian', 'select'], ['title', 'Judul'], ['company', 'Perusahaan'], ['deadline', 'Batas', 'date'], ['is_published', 'Tampil', 'bool']],
        'search' => ['title', 'company', 'content'], 'order' => "FIELD(section,'informasi','layanan','lowongan','mitra','persyaratan','kontak'), sort_order, id", 'filter_field' => 'section',
        'fields' => [F('section', 'Bagian', 'select', ['required' => 1, 'options' => ['informasi' => 'Informasi BKK', 'layanan' => 'Layanan Penempatan Kerja', 'lowongan' => 'Lowongan Kerja', 'mitra' => 'Perusahaan Mitra', 'persyaratan' => 'Persyaratan Pendaftaran', 'kontak' => 'Kontak BKK']]),
            F('title', 'Judul / Posisi', 'text', ['required' => 1, 'max' => 200]), F('company', 'Nama Perusahaan', 'text', ['max' => 150]), F('content', 'Isi / Deskripsi', 'textarea', ['rows' => 6]),
            F('image', 'Logo / Gambar', 'image'), F('deadline', 'Batas Pendaftaran (lowongan)', 'date'), $sortField, yn_field()]],
    'overseas' => ['title' => 'Program Kerja Luar Negeri / Jepang', 'icon' => 'fa-earth-asia', 'table' => 'overseas_programs', 'dir' => 'general',
        'list' => [['image', 'Gambar', 'image'], ['program', 'Program', 'select'], ['section', 'Bagian', 'select'], ['title', 'Judul'], ['is_published', 'Tampil', 'bool']],
        'search' => ['title', 'content'], 'order' => "program, FIELD(section,'penjelasan','tujuan','persyaratan','seleksi','pelatihan','pembekalan','dokumentasi','kontak'), sort_order, id", 'filter_field' => 'program',
        'note' => 'Hanya tulis informasi yang sudah terverifikasi (mitra, kuota, jadwal). Jangan mempublikasikan kerja sama yang belum resmi.',
        'fields' => [F('program', 'Program', 'select', ['required' => 1, 'options' => ['luar_negeri' => 'Program Kerja ke Luar Negeri', 'jepang' => 'Program Kerja ke Jepang']]),
            F('section', 'Bagian', 'select', ['required' => 1, 'options' => ['penjelasan' => 'Penjelasan program', 'tujuan' => 'Tujuan program', 'persyaratan' => 'Persyaratan', 'seleksi' => 'Tahapan seleksi', 'pelatihan' => 'Pelatihan bahasa', 'pembekalan' => 'Informasi pembekalan', 'dokumentasi' => 'Dokumentasi', 'kontak' => 'Kontak']]),
            F('title', 'Judul', 'text', ['required' => 1, 'max' => 200]), F('content', 'Isi', 'textarea', ['rows' => 6]), F('image', 'Gambar (dokumentasi)', 'image'), $sortField, yn_field()]],

    // ---------------------------------------------------------------- GURU & STAFF
    'staff' => ['title' => 'Guru dan Staff', 'icon' => 'fa-chalkboard-user', 'table' => 'staff_profiles', 'dir' => 'staff',
        'list' => [['photo', 'Foto', 'image'], ['name', 'Nama'], ['category', 'Kategori', 'select'], ['position', 'Jabatan'], ['subject', 'Mapel / Bidang'], ['sort_order', 'Urutan'], ['is_published', 'Tampil', 'bool']],
        'search' => ['name', 'position', 'subject'], 'order' => "FIELD(category,'pimpinan','wakasek','guru','staff_usaha','staff_kurikulum'), sort_order, name", 'filter_field' => 'category',
        'note' => 'Mengubah Kategori akan langsung memindahkan profil ke bagian yang sesuai di halaman Guru dan Staff. Jangan mengisi data pribadi tanpa izin.',
        'fields' => [F('category', 'Kategori', 'select', ['required' => 1, 'options' => staff_categories()]), F('name', 'Nama Lengkap', 'text', ['required' => 1, 'max' => 150]),
            F('position', 'Jabatan', 'text', ['max' => 150]), F('subject', 'Mata Pelajaran / Bidang Keahlian', 'text', ['max' => 150]),
            F('description', 'Deskripsi Singkat', 'textarea', ['rows' => 3, 'max' => 500]), F('photo', 'Foto', 'image', ['help' => 'Disarankan foto potret rasio 4:5. Foto tidak akan terdistorsi.']),
            $sortField, F('is_published', 'Publikasikan di website', 'bool', ['default' => 1])]],

    // ---------------------------------------------------------------- KESISWAAN
    'affairs' => ['title' => 'Beranda Kesiswaan', 'icon' => 'fa-house-user', 'table' => 'student_affairs', 'dir' => 'general',
        'list' => [['image', 'Gambar', 'image'], ['section', 'Bagian', 'select'], ['title', 'Judul'], ['sort_order', 'Urutan'], ['is_published', 'Tampil', 'bool']],
        'search' => ['title', 'content'], 'order' => "FIELD(section,'informasi','pembinaan','dokumentasi'), sort_order, id", 'filter_field' => 'section',
        'fields' => [F('section', 'Bagian', 'select', ['required' => 1, 'options' => ['informasi' => 'Informasi umum', 'pembinaan' => 'Program pembinaan siswa', 'dokumentasi' => 'Dokumentasi kegiatan']]),
            F('title', 'Judul', 'text', ['required' => 1, 'max' => 200]), F('content', 'Isi', 'textarea', ['rows' => 6]), F('image', 'Gambar', 'image'), $sortField, yn_field()]],
    'osis' => ['title' => 'OSIS', 'icon' => 'fa-people-group', 'table' => 'student_organizations', 'dir' => 'general',
        'list' => [['image', 'Gambar', 'image'], ['section', 'Bagian', 'select'], ['title', 'Judul / Jabatan'], ['subtitle', 'Nama'], ['sort_order', 'Urutan'], ['is_published', 'Tampil', 'bool']],
        'search' => ['title', 'subtitle', 'content'], 'order' => "FIELD(section,'informasi','struktur','program','dokumentasi'), sort_order, id", 'filter_field' => 'section',
        'note' => 'Bagian "Struktur": isi Judul = jabatan (mis. Ketua OSIS) dan Nama = nama pengurus.',
        'fields' => [F('section', 'Bagian', 'select', ['required' => 1, 'options' => ['informasi' => 'Informasi OSIS', 'struktur' => 'Struktur organisasi OSIS', 'program' => 'Program kerja', 'dokumentasi' => 'Dokumentasi kegiatan']]),
            F('title', 'Judul / Jabatan', 'text', ['required' => 1, 'max' => 200]), F('subtitle', 'Nama (untuk struktur)', 'text', ['max' => 150]), F('content', 'Isi / Keterangan', 'textarea', ['rows' => 6]),
            F('image', 'Gambar', 'image'), $sortField, yn_field()]],
    'ekskul' => ['title' => 'Ekstrakurikuler', 'icon' => 'fa-futbol', 'table' => 'extracurriculars', 'dir' => 'activities',
        'list' => [['image', 'Foto', 'image'], ['name', 'Nama'], ['schedule', 'Jadwal'], ['mentor', 'Pembina'], ['sort_order', 'Urutan'], ['is_published', 'Tampil', 'bool']],
        'search' => ['name', 'description', 'mentor'], 'order' => 'sort_order, id',
        'fields' => [F('name', 'Nama Ekstrakurikuler', 'text', ['required' => 1, 'max' => 150]), F('description', 'Deskripsi', 'textarea', ['rows' => 4]), F('schedule', 'Jadwal Kegiatan', 'text', ['max' => 150]),
            F('mentor', 'Pembina', 'text', ['max' => 150]), F('image', 'Foto', 'image'), $sortField, yn_field()]],
    'achievements' => ['title' => 'Prestasi Siswa', 'icon' => 'fa-trophy', 'table' => 'student_achievements', 'dir' => 'activities',
        'list' => [['image', 'Foto', 'image'], ['student_name', 'Siswa / Tim'], ['title', 'Prestasi'], ['level', 'Tingkat', 'select'], ['achievement_date', 'Tanggal', 'date'], ['is_published', 'Tampil', 'bool']],
        'search' => ['student_name', 'title', 'description'], 'order' => 'achievement_date DESC, id DESC', 'filter_field' => 'level',
        'fields' => [F('student_name', 'Nama Siswa / Tim', 'text', ['required' => 1, 'max' => 200]), F('title', 'Nama Prestasi', 'text', ['required' => 1, 'max' => 200]),
            F('level', 'Tingkat', 'select', ['required' => 1, 'options' => ['sekolah' => 'Sekolah', 'kecamatan' => 'Kecamatan', 'kota' => 'Kota', 'provinsi' => 'Provinsi', 'nasional' => 'Nasional', 'internasional' => 'Internasional']]),
            F('achievement_date', 'Tanggal', 'date', ['required' => 1]), F('description', 'Deskripsi', 'textarea', ['rows' => 4]), F('image', 'Foto / Dokumentasi', 'image'), yn_field()]],
    'activities' => ['title' => 'Kegiatan Siswa', 'icon' => 'fa-camera-retro', 'table' => 'student_activities', 'dir' => 'activities',
        'list' => [['image', 'Foto', 'image'], ['title', 'Kegiatan'], ['activity_date', 'Tanggal', 'date'], ['is_published', 'Tampil', 'bool']],
        'search' => ['title', 'description'], 'order' => 'activity_date DESC, id DESC',
        'fields' => [F('title', 'Nama Kegiatan', 'text', ['required' => 1, 'max' => 200]), F('activity_date', 'Tanggal', 'date', ['required' => 1]), F('description', 'Deskripsi', 'textarea', ['rows' => 4]),
            F('image', 'Foto Dokumentasi', 'image'), yn_field()]],
    'rules' => ['title' => 'Tata Tertib', 'icon' => 'fa-scale-balanced', 'table' => 'school_rules', 'dir' => 'general',
        'list' => [['category', 'Kategori'], ['title', 'Judul'], ['sort_order', 'Urutan'], ['is_published', 'Tampil', 'bool']],
        'search' => ['category', 'title', 'content'], 'order' => 'category, sort_order, id',
        'fields' => [F('category', 'Kategori', 'text', ['required' => 1, 'max' => 100, 'default' => 'Peraturan Sekolah', 'list' => ['Peraturan Sekolah', 'Ketentuan Kedisiplinan', 'Informasi Tata Tertib Siswa'], 'help' => 'Pilih dari saran atau ketik kategori baru.']),
            F('title', 'Judul', 'text', ['required' => 1, 'max' => 200]), F('content', 'Isi', 'textarea', ['required' => 1, 'rows' => 6]), $sortField, yn_field()]],

    // ---------------------------------------------------------------- PPDB
    'ppdb_info' => ['title' => 'Informasi PPDB', 'icon' => 'fa-clipboard-list', 'table' => 'ppdb_info', 'dir' => 'general',
        'list' => [['type', 'Jenis', 'select'], ['title', 'Judul'], ['date_label', 'Tanggal / Waktu'], ['sort_order', 'Urutan'], ['is_published', 'Tampil', 'bool']],
        'search' => ['title', 'content', 'date_label'], 'order' => "FIELD(type,'persyaratan','jadwal','alur','jalur','faq'), sort_order, id", 'filter_field' => 'type',
        'fields' => [F('type', 'Jenis', 'select', ['required' => 1, 'options' => ['persyaratan' => 'Persyaratan', 'jadwal' => 'Jadwal pendaftaran', 'alur' => 'Alur pendaftaran', 'jalur' => 'Jalur pendaftaran', 'faq' => 'FAQ']]),
            F('title', 'Judul / Pertanyaan', 'text', ['required' => 1, 'max' => 200]), F('content', 'Isi / Jawaban', 'textarea', ['rows' => 4]),
            F('date_label', 'Tanggal / Waktu (untuk jadwal)', 'text', ['max' => 120, 'placeholder' => 'Contoh: 4 Januari - 31 Maret 2027']), $sortField, yn_field()]],

    // ---------------------------------------------------------------- BERITA
    'news_cat' => ['title' => 'Kategori Berita', 'icon' => 'fa-tags', 'table' => 'news_categories', 'dir' => 'general',
        'list' => [['name', 'Nama'], ['slug', 'Slug']], 'search' => ['name'], 'order' => 'name',
        'fields' => [F('name', 'Nama Kategori', 'text', ['required' => 1, 'max' => 100]), F('slug', 'Slug URL (otomatis)', 'slug', ['from' => 'name'])]],
    'news' => ['title' => 'Berita', 'icon' => 'fa-newspaper', 'table' => 'news', 'dir' => 'news',
        'list' => [['image', 'Gambar', 'image'], ['title', 'Judul'], ['category_id', 'Kategori', 'fk'], ['status', 'Status', 'select'], ['published_at', 'Terbit', 'datetime']],
        'search' => ['title', 'summary', 'content'], 'order' => 'COALESCE(published_at, created_at) DESC, id DESC', 'filter_field' => 'status',
        'fields' => [F('title', 'Judul Berita', 'text', ['required' => 1, 'max' => 220]), F('slug', 'Slug URL (otomatis)', 'slug', ['from' => 'title']),
            F('category_id', 'Kategori', 'fk', ['fk' => ['news_categories', 'name']]), F('summary', 'Ringkasan', 'textarea', ['rows' => 2, 'max' => 400, 'help' => 'Tampil di kartu berita. Jika kosong, diambil dari isi.']),
            F('content', 'Isi Berita', 'textarea', ['required' => 1, 'rows' => 12, 'help' => 'Pisahkan paragraf dengan baris kosong. Awali baris dengan "- " untuk daftar.']),
            F('image', 'Gambar Utama', 'image', ['help' => 'Disarankan rasio 16:10.']),
            F('status', 'Status', 'select', ['required' => 1, 'default' => 'draft', 'options' => ['draft' => 'Draft (tidak tampil)', 'published' => 'Terbit']]),
            F('published_at', 'Tanggal Publikasi', 'datetime', ['help' => 'Kosong + status Terbit = sekarang. Tanggal di masa depan = tayang terjadwal.']),
            F('author', 'Penulis', 'text', ['max' => 100, 'default_admin' => 1])],
        'before_save' => function (array $d, ?array $old): array {
            if ($d['status'] === 'published' && empty($d['published_at'])) $d['published_at'] = date('Y-m-d H:i:00');
            return $d;
        }],

    // ---------------------------------------------------------------- GALERI
    'gallery_cat' => ['title' => 'Kategori Galeri', 'icon' => 'fa-folder', 'table' => 'gallery_categories', 'dir' => 'general',
        'list' => [['name', 'Nama'], ['slug', 'Slug']], 'search' => ['name'], 'order' => 'id',
        'fields' => [F('name', 'Nama Kategori', 'text', ['required' => 1, 'max' => 100]), F('slug', 'Slug URL (otomatis)', 'slug', ['from' => 'name'])]],
    'gallery' => ['title' => 'Foto Galeri', 'icon' => 'fa-images', 'table' => 'gallery', 'dir' => 'gallery',
        'list' => [['image', 'Foto', 'image'], ['title', 'Judul'], ['category_id', 'Kategori', 'fk'], ['created_at', 'Diunggah', 'datetime'], ['is_published', 'Tampil', 'bool']],
        'search' => ['title', 'caption'], 'order' => 'created_at DESC, id DESC', 'filter_field' => 'category_id',
        'fields' => [F('title', 'Judul Foto', 'text', ['required' => 1, 'max' => 200]), F('category_id', 'Kategori', 'fk', ['fk' => ['gallery_categories', 'name']]),
            F('caption', 'Keterangan', 'textarea', ['rows' => 2, 'max' => 500]), F('image', 'Foto', 'image', ['required_new' => 1]), yn_field()]],

    // ---------------------------------------------------------------- AGENDA
    'agenda_cat' => ['title' => 'Kategori Agenda', 'icon' => 'fa-folder', 'table' => 'agenda_categories', 'dir' => 'general',
        'list' => [['name', 'Nama'], ['slug', 'Slug']], 'search' => ['name'], 'order' => 'name',
        'fields' => [F('name', 'Nama Kategori', 'text', ['required' => 1, 'max' => 100]), F('slug', 'Slug URL (otomatis)', 'slug', ['from' => 'name'])]],
    'agendas' => ['title' => 'Agenda Sekolah', 'icon' => 'fa-calendar-check', 'table' => 'agendas', 'dir' => 'general',
        'list' => [['image', 'Gambar', 'image'], ['title', 'Kegiatan'], ['category_id', 'Kategori', 'fk'], ['event_date', 'Tanggal', 'date'], ['location', 'Lokasi'], ['is_published', 'Tampil', 'bool']],
        'search' => ['title', 'description', 'location'], 'order' => 'event_date DESC, id DESC', 'filter_field' => 'category_id',
        'fields' => [F('title', 'Nama Kegiatan', 'text', ['required' => 1, 'max' => 200]), F('category_id', 'Kategori', 'fk', ['fk' => ['agenda_categories', 'name']]),
            F('event_date', 'Tanggal Mulai', 'date', ['required' => 1]), F('end_date', 'Tanggal Selesai', 'date', ['help' => 'Kosongkan jika satu hari.', 'after' => 'event_date']),
            F('start_time', 'Jam Mulai', 'time'), F('end_time', 'Jam Selesai', 'time'), F('location', 'Lokasi', 'text', ['max' => 200]),
            F('description', 'Deskripsi', 'textarea', ['rows' => 5]), F('image', 'Gambar (opsional)', 'image'), yn_field()]],

    // ---------------------------------------------------------------- KONTAK / SOSIAL
    'social' => ['title' => 'Media Sosial', 'icon' => 'fa-share-nodes', 'table' => 'social_links', 'dir' => 'general',
        'list' => [['platform', 'Platform'], ['url', 'Tautan'], ['sort_order', 'Urutan'], ['is_active', 'Aktif', 'bool']], 'search' => ['platform', 'url'], 'order' => 'sort_order, id',
        'note' => 'Isi dengan akun resmi sekolah. Tautan bawaan hanya mengarah ke beranda platform sebagai contoh.',
        'fields' => [F('platform', 'Nama Platform', 'text', ['required' => 1, 'max' => 50]), F('url', 'Tautan (URL)', 'url', ['required' => 1, 'max' => 255, 'placeholder' => 'https://www.instagram.com/akun_sekolah']),
            F('icon', 'Ikon', 'select', ['options' => social_icons(), 'default' => 'fa-brands fa-instagram']), $sortField, F('is_active', 'Tampilkan di website', 'bool', ['default' => 1])]],
    ];
    return $m;
}

/** Kelompok pengaturan (tabel website_settings). Kunci yang sama boleh muncul di beberapa kelompok (satu sumber data). */
function settings_groups(): array
{
    $addr = [['address', 'Alamat Sekolah', 'textarea'], ['phone', 'Nomor Telepon', 'text'], ['email', 'Email', 'email'], ['website', 'Website', 'text']];
    return [
    'identitas' => ['title' => 'Identitas Sekolah', 'icon' => 'fa-id-card', 'desc' => 'Identitas yang tampil di beranda, profil, dan footer.', 'fields' => [
        ['school_fullname', 'Nama Lengkap Sekolah', 'text'], ['npsn', 'NPSN', 'text'], ['school_status', 'Status Sekolah', 'text'], ['accreditation', 'Akreditasi', 'text'],
        ['profile_summary', 'Profil Singkat Sekolah (beranda)', 'textarea'], ['org_chart_image', 'Gambar Bagan Struktur Organisasi (opsional)', 'image']]],
    'kontak' => ['title' => 'Informasi Kontak Sekolah', 'icon' => 'fa-address-book', 'desc' => 'Satu sumber data: perubahan di sini otomatis tampil di footer, beranda, profil, dan halaman kontak.', 'fields' => array_merge($addr, [
        ['service_hours', 'Jam Layanan', 'text'], ['map_url', 'URL Peta (embed Google Maps)', 'url']])],
    'statistik' => ['title' => 'Data Statistik Sekolah', 'icon' => 'fa-chart-pie', 'desc' => 'Angka pada kartu statistik beranda dan halaman Data Sekolah.', 'fields' => [
        ['stat_students', 'Jumlah Siswa', 'number'], ['stat_teachers', 'Jumlah Guru', 'number'], ['stat_classgroups', 'Jumlah Rombongan Belajar', 'number'],
        ['stat_classrooms', 'Jumlah Ruang Kelas', 'number'], ['stat_labs', 'Jumlah Laboratorium (0 = disembunyikan)', 'number'],
        ['stat_note', 'Catatan di bawah statistik (kosongkan jika data sudah resmi)', 'text']]],
    'hero' => ['title' => 'Tampilan Beranda (Hero)', 'icon' => 'fa-panorama', 'desc' => 'Judul, deskripsi, dan foto latar bagian utama beranda.', 'fields' => [
        ['hero_title', 'Judul Hero', 'text'], ['hero_subtitle', 'Deskripsi Singkat', 'textarea'], ['hero_image', 'Foto Latar Hero (opsional, disarankan 1600x900)', 'image']]],
    'ppdb' => ['title' => 'Pengaturan Informasi PPDB & Tahun Ajaran', 'icon' => 'fa-bullhorn', 'desc' => 'Judul, tahun ajaran, informasi umum, kontak panitia, dan teks ajakan.', 'fields' => [
        ['ppdb_title', 'Judul Halaman PPDB', 'text'], ['ppdb_year', 'Tahun Ajaran', 'text'], ['ppdb_info', 'Informasi Pendaftaran', 'textarea'],
        ['ppdb_contact_name', 'Nama Kontak Panitia', 'text'], ['ppdb_contact_phone', 'Telepon Panitia', 'text'], ['ppdb_contact_email', 'Email Panitia', 'email'],
        ['ppdb_cta_text', 'Teks Ajakan PPDB (beranda)', 'textarea']]],
    'ppdb_brosur' => ['title' => 'Brosur PPDB', 'icon' => 'fa-file-image', 'desc' => 'Brosur tampil di bagian atas halaman PPDB. Brosur lama otomatis dihapus saat diganti.', 'fields' => [
        ['ppdb_brochure', 'Gambar Brosur PPDB (JPG/PNG/WEBP, maks. 3 MB)', 'image']]],
    'ppdb_form' => ['title' => 'Pengaturan Formulir PPDB', 'icon' => 'fa-sliders', 'desc' => 'Buka/tutup pendaftaran dan atur kolom wajib.', 'fields' => [
        ['ppdb_open', 'Status Pendaftaran', 'select', ['1' => 'Dibuka', '0' => 'Ditutup']], ['ppdb_close_date', 'Tutup otomatis setelah tanggal (opsional)', 'date'],
        ['ppdb_require_nisn', 'NISN', 'select', ['0' => 'Opsional', '1' => 'Wajib diisi']], ['ppdb_require_email', 'Email', 'select', ['0' => 'Opsional', '1' => 'Wajib diisi']],
        ['ppdb_success_message', 'Pesan setelah pendaftaran berhasil', 'textarea']]],
    'umum' => ['title' => 'Pengaturan Umum Website', 'icon' => 'fa-gear', 'desc' => 'Logo, favicon, nama sekolah, dan kontak utama.', 'fields' => array_merge([
        ['logo', 'Logo Sekolah (PNG/JPG/WEBP, disarankan persegi)', 'image'], ['favicon', 'Favicon (PNG/ICO, disarankan 64x64)', 'favicon'],
        ['school_name', 'Nama Sekolah', 'text'], ['school_tagline', 'Slogan', 'text']], $addr)],
    'footer' => ['title' => 'Pengaturan Footer', 'icon' => 'fa-shoe-prints', 'desc' => 'Teks yang tampil di footer.', 'fields' => [
        ['footer_about', 'Teks Tentang Sekolah (footer)', 'textarea'], ['footer_copyright', 'Teks Hak Cipta (setelah tahun)', 'text']]],
    'seo' => ['title' => 'Pengaturan SEO Dasar', 'icon' => 'fa-magnifying-glass-chart', 'desc' => 'Meta deskripsi dan kata kunci bawaan website.', 'fields' => [
        ['meta_description', 'Meta Description (maks. 160 karakter)', 'textarea'], ['meta_keywords', 'Meta Keywords', 'text']]],
    ];
}
