<?php
/** Profil admin, ganti password, dan pengelolaan akun admin (multi-admin). */
require_once __DIR__ . '/includes/layout.php';
require_admin();

$me = $GLOBALS['CURRENT_ADMIN'];
$a = get_str('a', 'profile');
if (!in_array($a, ['profile', 'password', 'list', 'add'], true)) $a = 'profile';
$self = admin_url('administrators.php');
$errors = [];
$old = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf($self . '?a=' . $a);
    $do = post_str('do');

    if ($do === 'profile') {
        $old = ['full_name' => post_str('full_name'), 'email' => post_str('email')];
        if (mb_strlen($old['full_name']) < 3 || mb_strlen($old['full_name']) > 120) $errors['full_name'] = 'Nama wajib diisi (3-120 karakter).';
        if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($old['email']) > 120) $errors['email'] = 'Email tidak valid.';
        elseif (q_val('SELECT COUNT(*) FROM admins WHERE email = ? AND id <> ?', [$old['email'], $me['id']])) $errors['email'] = 'Email sudah dipakai admin lain.';
        if (!$errors) { q_exec('UPDATE admins SET full_name = ?, email = ? WHERE id = ?', [$old['full_name'], $old['email'], $me['id']]); log_activity('Ubah Profil Admin', $me['username']); flash('success', 'Profil berhasil diperbarui.'); redirect($self . '?a=profile'); }
        $a = 'profile';
    }
    if ($do === 'password') {
        $cur = (string)($_POST['current'] ?? ''); $new = (string)($_POST['new'] ?? ''); $new2 = (string)($_POST['new2'] ?? '');
        $hash = q_val('SELECT password_hash FROM admins WHERE id = ?', [$me['id']]);
        if (!password_verify($cur, (string)$hash)) $errors['current'] = 'Password saat ini salah.';
        if ($e = password_strength_error($new)) $errors['new'] = $e;
        elseif ($new === $cur) $errors['new'] = 'Password baru harus berbeda dari password lama.';
        if ($new !== $new2) $errors['new2'] = 'Konfirmasi password tidak sama.';
        if (!$errors) {
            q_exec('UPDATE admins SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $me['id']]);
            session_regenerate_id(true);
            log_activity('Ganti Password', $me['username']);
            flash('success', 'Password berhasil diganti.'); redirect($self . '?a=password');
        }
        $a = 'password';
    }
    if ($do === 'add') {
        $old = ['full_name' => post_str('full_name'), 'username' => post_str('username'), 'email' => post_str('email')];
        $pw = (string)($_POST['password'] ?? '');
        if (mb_strlen($old['full_name']) < 3 || mb_strlen($old['full_name']) > 120) $errors['full_name'] = 'Nama wajib diisi (3-120 karakter).';
        if (!preg_match('/^[a-zA-Z0-9_.]{4,50}$/', $old['username'])) $errors['username'] = 'Username 4-50 karakter (huruf, angka, titik, garis bawah).';
        elseif (q_val('SELECT COUNT(*) FROM admins WHERE username = ?', [$old['username']])) $errors['username'] = 'Username sudah dipakai.';
        if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Email tidak valid.';
        elseif (q_val('SELECT COUNT(*) FROM admins WHERE email = ?', [$old['email']])) $errors['email'] = 'Email sudah dipakai.';
        if ($e = password_strength_error($pw)) $errors['password'] = $e;
        if (!$errors) {
            q_exec('INSERT INTO admins (username, email, full_name, password_hash) VALUES (?,?,?,?)', [$old['username'], $old['email'], $old['full_name'], password_hash($pw, PASSWORD_DEFAULT)]);
            log_activity('Tambah Akun Admin', $old['username']); flash('success', 'Akun admin baru berhasil dibuat.'); redirect($self . '?a=list');
        }
        $a = 'add';
    }
    if ($do === 'toggle' || $do === 'delete') {
        $tid = (int)post_str('id'); $t = q_one('SELECT * FROM admins WHERE id = ?', [$tid]);
        if (!$t) { flash('warning', 'Akun tidak ditemukan.'); redirect($self . '?a=list'); }
        if ($tid === (int)$me['id']) { flash('danger', 'Anda tidak dapat ' . ($do === 'delete' ? 'menghapus' : 'menonaktifkan') . ' akun Anda sendiri.'); redirect($self . '?a=list'); }
        if ($do === 'delete') {
            if ((int)q_val('SELECT COUNT(*) FROM admins') <= 1) { flash('danger', 'Admin terakhir tidak boleh dihapus.'); redirect($self . '?a=list'); }
            q_exec('DELETE FROM admins WHERE id = ?', [$tid]); log_activity('Hapus Akun Admin', $t['username']); flash('success', 'Akun admin dihapus.');
        } else {
            q_exec('UPDATE admins SET is_active = 1 - is_active WHERE id = ?', [$tid]); log_activity('Ubah Status Akun Admin', $t['username']); flash('success', 'Status akun diperbarui.');
        }
        redirect($self . '?a=list');
    }
}

$titles = ['profile' => 'Profil Admin', 'password' => 'Ganti Password', 'list' => 'Kelola Akun Admin', 'add' => 'Tambah Akun Admin'];
admin_head($titles[$a], $a === 'add' ? ['Kelola Akun Admin' => $self . '?a=list'] : []);
$inv = fn($k) => isset($errors[$k]) ? ' is-invalid' : '';
$msg = fn($k) => isset($errors[$k]) ? '<div class="invalid-feedback d-block">' . e($errors[$k]) . '</div>' : '';
?>
<ul class="nav nav-pills mb-3 gap-1"><?php foreach (['profile' => 'Profil', 'password' => 'Ganti Password', 'list' => 'Akun Admin'] as $k => $l): ?><li class="nav-item"><a class="nav-link <?= ($a === $k || ($a === 'add' && $k === 'list')) ? 'active' : '' ?>" href="<?= e($self . '?a=' . $k) ?>"><?= e($l) ?></a></li><?php endforeach; ?></ul>
<?php if ($a === 'profile'): $o = $old ?: ['full_name' => $me['full_name'], 'email' => $me['email']]; ?>
<div class="adm-card" style="max-width:640px"><form method="post" action="<?= e($self . '?a=profile') ?>" novalidate data-once><?= csrf_field() ?><input type="hidden" name="do" value="profile">
    <div class="mb-3"><label class="form-label fw-semibold">Username</label><input class="form-control" value="<?= e($me['username']) ?>" disabled></div>
    <div class="mb-3"><label class="form-label fw-semibold" for="fn">Nama Lengkap</label><input class="form-control<?= $inv('full_name') ?>" id="fn" name="full_name" value="<?= e($o['full_name']) ?>" maxlength="120"><?= $msg('full_name') ?></div>
    <div class="mb-3"><label class="form-label fw-semibold" for="em">Email</label><input type="email" class="form-control<?= $inv('email') ?>" id="em" name="email" value="<?= e($o['email']) ?>" maxlength="120"><?= $msg('email') ?></div>
    <button class="btn btn-primary"><i class="fa-solid fa-floppy-disk me-2"></i>Simpan Profil</button></form></div>
<?php elseif ($a === 'password'): ?>
<div class="adm-card" style="max-width:640px"><form method="post" action="<?= e($self . '?a=password') ?>" novalidate autocomplete="off" data-once><?= csrf_field() ?><input type="hidden" name="do" value="password">
    <div class="mb-3"><label class="form-label fw-semibold" for="cur">Password Saat Ini</label><input type="password" class="form-control<?= $inv('current') ?>" id="cur" name="current" autocomplete="current-password"><?= $msg('current') ?></div>
    <div class="mb-3"><label class="form-label fw-semibold" for="nw">Password Baru</label><input type="password" class="form-control<?= $inv('new') ?>" id="nw" name="new" autocomplete="new-password"><div class="form-text">Minimal 8 karakter, mengandung huruf dan angka.</div><?= $msg('new') ?></div>
    <div class="mb-3"><label class="form-label fw-semibold" for="nw2">Ulangi Password Baru</label><input type="password" class="form-control<?= $inv('new2') ?>" id="nw2" name="new2" autocomplete="new-password"><?= $msg('new2') ?></div>
    <button class="btn btn-primary"><i class="fa-solid fa-key me-2"></i>Ganti Password</button></form></div>
<?php elseif ($a === 'add'): $o = $old + ['full_name' => '', 'username' => '', 'email' => '']; ?>
<div class="adm-card" style="max-width:640px"><form method="post" action="<?= e($self . '?a=add') ?>" novalidate autocomplete="off" data-once><?= csrf_field() ?><input type="hidden" name="do" value="add">
    <div class="mb-3"><label class="form-label fw-semibold">Nama Lengkap</label><input class="form-control<?= $inv('full_name') ?>" name="full_name" value="<?= e($o['full_name']) ?>" maxlength="120"><?= $msg('full_name') ?></div>
    <div class="mb-3"><label class="form-label fw-semibold">Username</label><input class="form-control<?= $inv('username') ?>" name="username" value="<?= e($o['username']) ?>" maxlength="50"><?= $msg('username') ?></div>
    <div class="mb-3"><label class="form-label fw-semibold">Email</label><input type="email" class="form-control<?= $inv('email') ?>" name="email" value="<?= e($o['email']) ?>" maxlength="120"><?= $msg('email') ?></div>
    <div class="mb-3"><label class="form-label fw-semibold">Password</label><input type="password" class="form-control<?= $inv('password') ?>" name="password" autocomplete="new-password"><div class="form-text">Minimal 8 karakter, huruf + angka.</div><?= $msg('password') ?></div>
    <div class="d-flex gap-2"><button class="btn btn-primary"><i class="fa-solid fa-user-plus me-2"></i>Buat Akun</button><a class="btn btn-light" href="<?= e($self . '?a=list') ?>">Batal</a></div></form></div>
<?php else: $admins = q_all('SELECT * FROM admins ORDER BY id'); ?>
<div class="adm-card"><div class="d-flex justify-content-between mb-3"><span class="text-muted"><?= count($admins) ?> akun admin</span><a class="btn btn-primary" href="<?= e($self . '?a=add') ?>"><i class="fa-solid fa-plus me-1"></i>Tambah Admin</a></div>
<div class="table-responsive"><table class="table adm-table align-middle"><thead><tr><th>Nama</th><th>Username</th><th>Email</th><th>Login Terakhir</th><th>Status</th><th class="text-end">Aksi</th></tr></thead><tbody>
<?php foreach ($admins as $ad): $self_ = (int)$ad['id'] === (int)$me['id']; ?><tr><td><?= e($ad['full_name']) ?><?= $self_ ? ' <span class="badge bg-primary">Anda</span>' : '' ?></td><td><?= e($ad['username']) ?></td><td><?= e($ad['email']) ?></td><td><?= $ad['last_login'] ? e(tgl_indo($ad['last_login'], true)) : '-' ?></td><td><span class="badge bg-<?= $ad['is_active'] ? 'success' : 'secondary' ?>"><?= $ad['is_active'] ? 'Aktif' : 'Nonaktif' ?></span></td>
<td class="text-end text-nowrap"><?php if (!$self_): ?><form class="d-inline" method="post" action="<?= e($self . '?a=list') ?>"><?= csrf_field() ?><input type="hidden" name="do" value="toggle"><input type="hidden" name="id" value="<?= (int)$ad['id'] ?>"><button class="btn btn-sm btn-outline-secondary"><?= $ad['is_active'] ? 'Nonaktifkan' : 'Aktifkan' ?></button></form> <button class="btn btn-sm btn-outline-danger" type="button" data-delete="<?= (int)$ad['id'] ?>" data-name="<?= e($ad['username']) ?>" data-action="<?= e($self . '?a=list') ?>" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button><?php else: ?><span class="text-muted small">-</span><?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
<?php endif; admin_foot();
