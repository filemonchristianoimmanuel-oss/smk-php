<?php
require_once __DIR__ . '/includes/layout.php';
require_admin();

$cards = [
    ['Berita', (int)q_val('SELECT COUNT(*) FROM news'), 'fa-newspaper', crud_link('news'), 'blue'],
    ['Guru & Staff', (int)q_val('SELECT COUNT(*) FROM staff_profiles'), 'fa-chalkboard-user', crud_link('staff'), 'gold'],
    ['Program Keahlian', (int)q_val('SELECT COUNT(*) FROM study_programs'), 'fa-laptop-code', crud_link('programs'), 'blue'],
    ['Siswa Mendaftar', (int)q_val('SELECT COUNT(*) FROM ppdb_registrations'), 'fa-user-plus', admin_url('ppdb_registrations.php'), 'gold'],
    ['Foto Galeri', (int)q_val('SELECT COUNT(*) FROM gallery'), 'fa-images', crud_link('gallery'), 'blue'],
    ['Agenda', (int)q_val('SELECT COUNT(*) FROM agendas'), 'fa-calendar-check', crud_link('agendas'), 'gold'],
    ['Pesan Masuk', (int)q_val('SELECT COUNT(*) FROM contact_messages'), 'fa-envelope', admin_url('messages.php'), 'blue'],
];
$unread = (int)q_val('SELECT COUNT(*) FROM contact_messages WHERE is_read = 0');
$latestNews = q_all('SELECT id, title, status, COALESCE(published_at, created_at) AS dt FROM news ORDER BY COALESCE(published_at, created_at) DESC LIMIT 5');
$latestReg  = q_all('SELECT id, registration_no, full_name, program_name, status, created_at FROM ppdb_registrations ORDER BY id DESC LIMIT 5');
$upAgenda   = q_all('SELECT id, title, event_date, location FROM agendas WHERE COALESCE(end_date, event_date) >= CURDATE() ORDER BY event_date LIMIT 5');
$latestMsg  = q_all('SELECT id, name, subject, is_read, created_at FROM contact_messages ORDER BY id DESC LIMIT 5');
$logs       = q_all('SELECT * FROM admin_activity_logs ORDER BY id DESC LIMIT 10');

$byStatus = array_fill_keys(array_keys(ppdb_statuses()), 0);
foreach (q_all('SELECT status, COUNT(*) c FROM ppdb_registrations GROUP BY status') as $r) $byStatus[$r['status']] = (int)$r['c'];
$byProg = q_all("SELECT COALESCE(program_name,'(Program dihapus)') AS n, COUNT(*) c FROM ppdb_registrations GROUP BY n ORDER BY c DESC LIMIT 8");

admin_head('Dashboard');
?>
<div class="row g-3 mb-4">
    <?php foreach ($cards as $c): ?>
    <div class="col-6 col-md-4 col-xl"><a class="stat-tile tile-<?= $c[4] ?>" href="<?= e($c[3]) ?>"><span class="ic"><i class="fa-solid <?= $c[2] ?>"></i></span><span><span class="n"><?= number_format($c[1], 0, ',', '.') ?></span><span class="l"><?= e($c[0]) ?></span></span></a></div>
    <?php endforeach; ?>
</div>
<?php if ($unread): ?><div class="alert alert-warning"><i class="fa-solid fa-envelope me-1"></i> Anda memiliki <strong><?= $unread ?></strong> pesan belum dibaca. <a href="<?= admin_url('messages.php?filter=unread') ?>">Lihat pesan</a></div><?php endif; ?>

<div class="row g-4 mb-4">
    <div class="col-lg-5"><div class="adm-card h-100"><h2 class="adm-h"><i class="fa-solid fa-chart-pie"></i> Status Pendaftar PPDB</h2>
        <?php if (array_sum($byStatus) === 0): ?><p class="text-muted text-center my-5">Belum ada pendaftar.</p><?php else: ?><div style="height:260px"><canvas id="chStatus" aria-label="Grafik status pendaftar" role="img"></canvas></div><?php endif; ?></div></div>
    <div class="col-lg-7"><div class="adm-card h-100"><h2 class="adm-h"><i class="fa-solid fa-chart-column"></i> Pendaftar per Program Keahlian</h2>
        <?php if (!$byProg): ?><p class="text-muted text-center my-5">Belum ada pendaftar.</p><?php else: ?><div style="height:260px"><canvas id="chProg" aria-label="Grafik pendaftar per program" role="img"></canvas></div><?php endif; ?></div></div>
</div>

<div class="row g-4 mb-4">
    <div class="col-lg-6"><div class="adm-card h-100"><div class="d-flex justify-content-between"><h2 class="adm-h"><i class="fa-solid fa-newspaper"></i> Berita Terbaru</h2><a href="<?= e(crud_link('news')) ?>" class="small">Semua</a></div>
        <ul class="adm-list"><?php foreach ($latestNews as $n): ?><li><div><a href="<?= e(crud_link('news', '', 'edit') . '&id=' . $n['id']) ?>"><?= e(excerpt($n['title'], 60)) ?></a><small class="d-block text-muted"><?= e(tgl_indo($n['dt'])) ?></small></div><span class="badge bg-<?= $n['status'] === 'published' ? 'success' : 'warning text-dark' ?>"><?= $n['status'] === 'published' ? 'Terbit' : 'Draft' ?></span></li><?php endforeach; if (!$latestNews) echo '<li class="text-muted">Belum ada berita.</li>'; ?></ul></div></div>
    <div class="col-lg-6"><div class="adm-card h-100"><div class="d-flex justify-content-between"><h2 class="adm-h"><i class="fa-solid fa-user-plus"></i> Pendaftar Terbaru</h2><a href="<?= admin_url('ppdb_registrations.php') ?>" class="small">Semua</a></div>
        <ul class="adm-list"><?php foreach ($latestReg as $r): ?><li><div><a href="<?= admin_url('ppdb_registrations.php?id=' . $r['id']) ?>"><?= e($r['full_name']) ?></a><small class="d-block text-muted"><?= e($r['program_name'] ?: '-') ?> &bull; <?= e(tgl_indo($r['created_at'])) ?></small></div><?= status_badge($r['status']) ?></li><?php endforeach; if (!$latestReg) echo '<li class="text-muted">Belum ada pendaftar.</li>'; ?></ul></div></div>
    <div class="col-lg-6"><div class="adm-card h-100"><div class="d-flex justify-content-between"><h2 class="adm-h"><i class="fa-solid fa-calendar-check"></i> Agenda Mendatang</h2><a href="<?= e(crud_link('agendas')) ?>" class="small">Semua</a></div>
        <ul class="adm-list"><?php foreach ($upAgenda as $a): ?><li><div><a href="<?= e(crud_link('agendas', '', 'edit') . '&id=' . $a['id']) ?>"><?= e(excerpt($a['title'], 60)) ?></a><small class="d-block text-muted"><?= e($a['location'] ?: '-') ?></small></div><span class="badge bg-light text-dark border"><?= e(tgl_indo($a['event_date'])) ?></span></li><?php endforeach; if (!$upAgenda) echo '<li class="text-muted">Tidak ada agenda mendatang.</li>'; ?></ul></div></div>
    <div class="col-lg-6"><div class="adm-card h-100"><div class="d-flex justify-content-between"><h2 class="adm-h"><i class="fa-solid fa-envelope"></i> Pesan Terbaru</h2><a href="<?= admin_url('messages.php') ?>" class="small">Semua</a></div>
        <ul class="adm-list"><?php foreach ($latestMsg as $m): ?><li><div><a href="<?= admin_url('messages.php?id=' . $m['id']) ?>" class="<?= $m['is_read'] ? '' : 'fw-bold' ?>"><?= e(excerpt($m['subject'], 50)) ?></a><small class="d-block text-muted">dari <?= e($m['name']) ?> &bull; <?= e(tgl_indo($m['created_at'])) ?></small></div><?= $m['is_read'] ? '' : '<span class="badge bg-warning text-dark">Baru</span>' ?></li><?php endforeach; if (!$latestMsg) echo '<li class="text-muted">Belum ada pesan.</li>'; ?></ul></div></div>
</div>

<div class="adm-card" id="aktivitas"><h2 class="adm-h"><i class="fa-solid fa-clock-rotate-left"></i> Aktivitas Admin Terbaru</h2>
    <div class="table-responsive"><table class="table adm-table mb-0"><thead><tr><th>Waktu</th><th>Admin</th><th>Aktivitas</th><th>Detail</th></tr></thead><tbody>
    <?php foreach ($logs as $l): ?><tr><td class="text-nowrap"><?= e(tgl_indo($l['created_at'], true)) ?></td><td><?= e($l['admin_name']) ?></td><td><?= e($l['action']) ?></td><td class="text-muted"><?= e($l['detail']) ?></td></tr><?php endforeach; ?>
    <?php if (!$logs): ?><tr><td colspan="4" class="text-center text-muted py-4">Belum ada aktivitas.</td></tr><?php endif; ?></tbody></table></div></div>
<?php
$js = '<script src="' . asset('vendor/chartjs/chart.umd.js') . '"></script><script>'
    . 'var st=' . json_encode(array_values($byStatus)) . ',stl=' . json_encode(array_values(ppdb_statuses()), JSON_UNESCAPED_UNICODE) . ',pn=' . json_encode(array_column($byProg, 'n'), JSON_UNESCAPED_UNICODE) . ',pc=' . json_encode(array_map('intval', array_column($byProg, 'c'))) . ';'
    . 'var a=document.getElementById("chStatus");if(a)new Chart(a,{type:"doughnut",data:{labels:stl,datasets:[{data:st,backgroundColor:["#FFD700","#17a2e8","#1fa34a","#d63a3a"],borderWidth:2}]},options:{maintainAspectRatio:false,plugins:{legend:{position:"bottom"}}}});'
    . 'var b=document.getElementById("chProg");if(b)new Chart(b,{type:"bar",data:{labels:pn,datasets:[{label:"Pendaftar",data:pc,backgroundColor:"#1717E8",borderRadius:8}]},options:{maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}}});</script>';
admin_foot($js);
