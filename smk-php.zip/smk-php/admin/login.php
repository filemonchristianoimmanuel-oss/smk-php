<?php
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';

if (admin_logged_in()) redirect(admin_url('dashboard.php'));
$error = '';
$identity = '';
$needSetup = false;
try { $needSetup = ((int)q_val('SELECT COUNT(*) FROM admins') === 0); } catch (Throwable $e) { $needSetup = false; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $error = 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.';
    } else {
        $identity = post_str('identity');
        $err = admin_attempt_login($identity, (string)($_POST['password'] ?? ''));
        if ($err === null) redirect(admin_url('dashboard.php'));
        $error = $err;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title>Login Admin | <?= e(setting('school_name', 'SMK INFOKOM BOGOR')) ?></title>
    <link rel="icon" href="<?= e(favicon_url()) ?>">
    <link rel="stylesheet" href="<?= asset('vendor/bootstrap/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="<?= asset('vendor/fontawesome/css/all.min.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/admin.css') ?>?v=4">
</head>
<body class="login-body">
<div class="login-bg"></div>
<main class="login-wrap">
    <div class="login-card">
        <div class="text-center mb-4">
            <img src="<?= e(logo_url()) ?>" alt="Logo <?= e(setting('school_name')) ?>" width="96" height="96" class="login-logo">
            <h1 class="h4 mt-3 mb-1"><?= e(setting('school_name', 'SMK INFOKOM BOGOR')) ?></h1>
            <p class="text-muted small mb-0">Masuk ke Dashboard Admin</p>
        </div>
        <?php if ($needSetup): ?>
            <div class="alert alert-warning small"><i class="fa-solid fa-triangle-exclamation me-1"></i> Belum ada akun admin. Buat akun pertama melalui <a href="<?= url('setup_admin.php') ?>" class="fw-bold">setup_admin.php</a>.</div>
        <?php endif; ?>
        <?= flash_render() ?>
        <?php if ($error): ?><div class="alert alert-danger small" role="alert"><i class="fa-solid fa-circle-exclamation me-1"></i> <?= e($error) ?></div><?php endif; ?>
        <form method="post" autocomplete="off" novalidate data-once>
            <?= csrf_field() ?>
            <div class="mb-3">
                <label class="form-label fw-semibold" for="identity">Username atau Email</label>
                <div class="input-group"><span class="input-group-text"><i class="fa-solid fa-user"></i></span><input class="form-control" id="identity" name="identity" value="<?= e($identity) ?>" required autofocus autocomplete="username" maxlength="120"></div>
            </div>
            <div class="mb-4">
                <label class="form-label fw-semibold" for="password">Password</label>
                <div class="input-group"><span class="input-group-text"><i class="fa-solid fa-lock"></i></span><input class="form-control" type="password" id="password" name="password" required autocomplete="current-password" maxlength="200"><button class="btn btn-outline-secondary" type="button" id="togglePw" aria-label="Tampilkan atau sembunyikan password"><i class="fa-solid fa-eye"></i></button></div>
            </div>
            <button class="btn btn-login w-100" type="submit"><i class="fa-solid fa-right-to-bracket me-2"></i>Login</button>
        </form>
        <div class="text-center mt-4"><a class="small" href="<?= url('index.php') ?>"><i class="fa-solid fa-arrow-left me-1"></i>Kembali ke website</a></div>
    </div>
</main>
<script src="<?= asset('vendor/bootstrap/bootstrap.bundle.min.js') ?>"></script>
<script>
document.getElementById('togglePw').addEventListener('click', function () {
    var i = document.getElementById('password'), ic = this.querySelector('i');
    var show = i.type === 'password'; i.type = show ? 'text' : 'password';
    ic.className = show ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
});
document.querySelectorAll('form[data-once]').forEach(function (f) { f.addEventListener('submit', function () { var b = f.querySelector('button[type=submit]'); if (b) { b.disabled = true; b.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Memproses...'; } }); });
</script>
</body>
</html>
