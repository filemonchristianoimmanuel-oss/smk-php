<?php
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';
redirect(admin_logged_in() ? admin_url('dashboard.php') : admin_url('login.php'));
