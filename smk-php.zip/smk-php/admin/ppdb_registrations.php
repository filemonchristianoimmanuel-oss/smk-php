<?php
/** Pengelolaan data pendaftar PPDB: daftar, cari, filter status, detail, edit, ubah status, hapus, unduh CSV, cetak. */
require_once __DIR__ . '/includes/layout.php';
require_admin();

$self = admin_url('ppdb_registrations.php');
$statuses = ppdb_statuses();
$q = get_str('q'); $st = get_str('status'); if (!isset($statuses[$st])) $st = '';
$programs = q_all('SELECT id, name FROM study_programs ORDER BY sort_order, id');
$listUrl = $self . '?' . http_build_query(array_filter(['q' => $q, 'status' => $st]));

function reg_filter(string $q, string $st): array
{
    $w = []; $p = [];
    if ($st !== '') { $w[] = 'status = ?'; $p[] = $st; }
    if ($q !== '') {
        $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $q) . '%';
        $w[] = '(full_name LIKE ? OR registration_no LIKE ? OR nisn LIKE ? OR previous_school LIKE ? OR phone LIKE ? OR parent_name LIKE ?)';
        array_push($p, $like, $like, $like, $like, $like, $like);
    }
    return [$w ? 'WHERE ' . implode(' AND ', $w) : '', $p];
}
function csv_safe($v): string
{
    $v = (string)$v;
    return ($v !== '' && strpbrk($v[0], "=+-@\t\r") !== false) ? "'" . $v : $v;
}

/* ---------- POST ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf($listUrl);
    $do = post_str('do'); $pid = (int)post_str('id');
    $row = q_one('SELECT * FROM ppdb_registrations WHERE id = ?', [$pid]);
    if (!$row) { flash('warning', 'Data pendaftar tidak ditemukan.'); redirect($listUrl); }

    if ($do === 'delete') {
        try { q_exec('DELETE FROM ppdb_registrations WHERE id = ?', [$pid]); log_activity('Hapus Pendaftar PPDB', $row['registration_no'] . ' - ' . $row['full_name']); flash('success', 'Data pendaftar berhasil dihapus.'); }
        catch (Throwable $e) { error_log($e->getMessage()); flash('danger', 'Data gagal dihapus.'); }
        redirect($listUrl);
    }
    if ($do === 'status') {
        $new = post_str('status');
        if (!isset($statuses[$new])) { flash('danger', 'Status tidak valid.'); redirect($listUrl); }
        q_exec('UPDATE ppdb_registrations SET status = ? WHERE id = ?', [$new, $pid]);
        log_activity('Ubah Status Pendaftar', $row['registration_no'] . ' → ' . $statuses[$new]);
        flash('success', 'Status ' . $row['full_name'] . ' diubah menjadi "' . $statuses[$new] . '".');
        redirect(post_str('back') === 'detail' ? $self . '?id=' . $pid : $listUrl);
    }
    if ($do === 'save') {
        $d = ['full_name' => post_str('full_name'), 'nisn' => post_str('nisn'), 'birth_place' => post_str('birth_place'), 'birth_date' => post_str('birth_date'), 'gender' => post_str('gender'),
            'address' => post_str('address'), 'previous_school' => post_str('previous_school'), 'phone' => post_str('phone'), 'email' => post_str('email'), 'program_id' => post_str('program_id'),
            'parent_name' => post_str('parent_name'), 'status' => post_str('status'), 'admin_notes' => post_str('admin_notes')];
        $err = [];
        if (mb_strlen($d['full_name']) < 3 || mb_strlen($d['full_name']) > 150) $err['full_name'] = 'Nama wajib diisi (3-150 karakter).';
        if ($d['nisn'] !== '' && !preg_match('/^\d{10}$/', $d['nisn'])) $err['nisn'] = 'NISN harus 10 digit.';
        if ($d['birth_place'] === '' || mb_strlen($d['birth_place']) > 100) $err['birth_place'] = 'Tempat lahir wajib diisi.';
        $bd = DateTime::createFromFormat('Y-m-d', $d['birth_date']); if (!$bd || $bd->format('Y-m-d') !== $d['birth_date']) $err['birth_date'] = 'Tanggal lahir tidak valid.';
        if (!in_array($d['gender'], ['L', 'P'], true)) $err['gender'] = 'Pilih jenis kelamin.';
        if ($d['address'] === '' || mb_strlen($d['address']) > 500) $err['address'] = 'Alamat wajib diisi (maks. 500).';
        if ($d['previous_school'] === '' || mb_strlen($d['previous_school']) > 150) $err['previous_school'] = 'Asal sekolah wajib diisi.';
        if (!preg_match('/^[0-9+\-\s]{8,20}$/', $d['phone'])) $err['phone'] = 'Nomor telepon tidak valid.';
        if ($d['email'] !== '' && (!filter_var($d['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($d['email']) > 120)) $err['email'] = 'Email tidak valid.';
        $prog = null; foreach ($programs as $p) if ((string)$p['id'] === $d['program_id']) $prog = $p;
        if (!$prog) $err['program_id'] = 'Pilih program keahlian.';
        if ($d['parent_name'] === '' || mb_strlen($d['parent_name']) > 150) $err['parent_name'] = 'Nama orang tua/wali wajib diisi.';
        if (!isset($statuses[$d['status']])) $err['status'] = 'Status tidak valid.';
        if (mb_strlen($d['admin_notes']) > 500) $err['admin_notes'] = 'Catatan maksimal 500 karakter.';
        if (!$err) {
            try {
                q_exec('UPDATE ppdb_registrations SET full_name=?, nisn=?, birth_place=?, birth_date=?, gender=?, address=?, previous_school=?, phone=?, email=?, program_id=?, program_name=?, parent_name=?, status=?, admin_notes=? WHERE id=?',
                    [$d['full_name'], $d['nisn'] ?: null, $d['birth_place'], $d['birth_date'], $d['gender'], $d['address'], $d['previous_school'], $d['phone'], $d['email'] ?: null, $prog['id'], $prog['name'], $d['parent_name'], $d['status'], $d['admin_notes'] ?: null, $pid]);
                log_activity('Ubah Data Pendaftar', $row['registration_no'] . ' - ' . $d['full_name']);
                flash('success', 'Data pendaftar berhasil diperbarui.');
                redirect($self . '?id=' . $pid);
            } catch (Throwable $e) { error_log($e->getMessage()); flash('danger', 'Data gagal disimpan (NISN mungkin duplikat).'); }
        } else flash('danger', 'Data belum dapat disimpan. Periksa kolom yang ditandai.');
        $_GET['id'] = (string)$pid; $_GET['edit'] = '1'; $formErr = $err; $formOld = $d;
    }
}

/* ---------- EXPORT CSV ---------- */
if (get_str('export') === 'csv') {
    [$w, $p] = reg_filter($q, $st);
    $rows = q_all("SELECT * FROM ppdb_registrations $w ORDER BY id", $p);
    log_activity('Unduh Data Pendaftar', count($rows) . ' baris (CSV)');
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="pendaftar-ppdb-' . date('Ymd-His') . '.csv"');
    $out = fopen('php://output', 'w'); fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['No. Pendaftaran', 'Tahun Ajaran', 'Nama Lengkap', 'NISN', 'Tempat Lahir', 'Tanggal Lahir', 'Jenis Kelamin', 'Alamat', 'Asal Sekolah', 'Telepon', 'Email', 'Program Keahlian', 'Orang Tua/Wali', 'Status', 'Catatan Admin', 'Waktu Daftar']);
    foreach ($rows as $r) fputcsv($out, array_map('csv_safe', [$r['registration_no'], $r['academic_year'], $r['full_name'], $r['nisn'], $r['birth_place'], $r['birth_date'], $r['gender'] === 'L' ? 'Laki-laki' : 'Perempuan', $r['address'], $r['previous_school'], $r['phone'], $r['email'], $r['program_name'], $r['parent_name'], $statuses[$r['status']], $r['admin_notes'], $r['created_at']]));
    fclose($out); exit;
}

/* ---------- CETAK ---------- */
if (get_str('print') === '1') {
    [$w, $p] = reg_filter($q, $st);
    $rows = q_all("SELECT * FROM ppdb_registrations $w ORDER BY id", $p);
    log_activity('Cetak Data Pendaftar', count($rows) . ' baris');
    ?><!DOCTYPE html><html lang="id"><head><meta charset="utf-8"><title>Daftar Pendaftar PPDB</title><meta name="robots" content="noindex">
    <style>body{font-family:Arial,sans-serif;font-size:12px;margin:20px}h1{font-size:18px;margin:0}table{width:100%;border-collapse:collapse;margin-top:14px}th,td{border:1px solid #444;padding:5px 7px;text-align:left;vertical-align:top}th{background:#eee}.h{display:flex;align-items:center;gap:12px;border-bottom:3px solid #1717E8;padding-bottom:10px}@media print{.np{display:none}}</style></head><body>
    <div class="h"><img src="<?= e(logo_url()) ?>" width="56" height="56" alt=""><div><h1>Daftar Pendaftar PPDB <?= e(setting('ppdb_year')) ?></h1><div><?= e(setting('school_name')) ?><?= $st ? ' - Status: ' . e($statuses[$st]) : '' ?><?= $q ? ' - Pencarian: ' . e($q) : '' ?></div></div></div>
    <p class="np"><button onclick="window.print()">Cetak</button></p>
    <table><thead><tr><th>No</th><th>No. Daftar</th><th>Nama</th><th>NISN</th><th>TTL</th><th>L/P</th><th>Asal Sekolah</th><th>Program</th><th>Telepon</th><th>Orang Tua/Wali</th><th>Status</th></tr></thead><tbody>
    <?php foreach ($rows as $i => $r): ?><tr><td><?= $i + 1 ?></td><td><?= e($r['registration_no']) ?></td><td><?= e($r['full_name']) ?></td><td><?= e($r['nisn']) ?></td><td><?= e($r['birth_place'] . ', ' . tgl_indo($r['birth_date'])) ?></td><td><?= e($r['gender']) ?></td><td><?= e($r['previous_school']) ?></td><td><?= e($r['program_name']) ?></td><td><?= e($r['phone']) ?></td><td><?= e($r['parent_name']) ?></td><td><?= e($statuses[$r['status']]) ?></td></tr><?php endforeach; ?>
    </tbody></table><p>Dicetak: <?= e(tgl_indo(date('Y-m-d H:i:s'), true)) ?> &bull; Total <?= count($rows) ?> pendaftar. Dokumen rahasia - hanya untuk panitia PPDB.</p></body></html><?php
    exit;
}

/* ---------- DETAIL / EDIT ---------- */
$id = (int)get_str('id', '0');
if ($id) {
    $r = q_one('SELECT * FROM ppdb_registrations WHERE id = ?', [$id]);
    if (!$r) { flash('warning', 'Data pendaftar tidak ditemukan.'); redirect($self); }
    $edit = get_str('edit') === '1';
    admin_head($edit ? 'Edit Pendaftar' : 'Detail Pendaftar', ['Data Pendaftar' => $self]);
    if ($edit):
        $o = $formOld ?? ['full_name' => $r['full_name'], 'nisn' => $r['nisn'], 'birth_place' => $r['birth_place'], 'birth_date' => $r['birth_date'], 'gender' => $r['gender'], 'address' => $r['address'], 'previous_school' => $r['previous_school'], 'phone' => $r['phone'], 'email' => $r['email'], 'program_id' => (string)$r['program_id'], 'parent_name' => $r['parent_name'], 'status' => $r['status'], 'admin_notes' => $r['admin_notes']];
        $er = $formErr ?? [];
        $i_ = fn($k) => isset($er[$k]) ? ' is-invalid' : ''; $m_ = fn($k) => isset($er[$k]) ? '<div class="invalid-feedback d-block">' . e($er[$k]) . '</div>' : '';
        ?>
        <div class="adm-card"><form method="post" action="<?= e($self . '?id=' . $id . '&edit=1') ?>" novalidate data-once><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" value="<?= $id ?>">
        <p class="text-muted">No. Pendaftaran: <strong><?= e($r['registration_no']) ?></strong></p><div class="row g-3">
            <div class="col-md-8"><label class="form-label fw-semibold">Nama Lengkap</label><input class="form-control<?= $i_('full_name') ?>" name="full_name" value="<?= e($o['full_name']) ?>" maxlength="150"><?= $m_('full_name') ?></div>
            <div class="col-md-4"><label class="form-label fw-semibold">NISN</label><input class="form-control<?= $i_('nisn') ?>" name="nisn" value="<?= e($o['nisn']) ?>" maxlength="10"><?= $m_('nisn') ?></div>
            <div class="col-md-4"><label class="form-label fw-semibold">Tempat Lahir</label><input class="form-control<?= $i_('birth_place') ?>" name="birth_place" value="<?= e($o['birth_place']) ?>" maxlength="100"><?= $m_('birth_place') ?></div>
            <div class="col-md-4"><label class="form-label fw-semibold">Tanggal Lahir</label><input type="date" class="form-control<?= $i_('birth_date') ?>" name="birth_date" value="<?= e($o['birth_date']) ?>"><?= $m_('birth_date') ?></div>
            <div class="col-md-4"><label class="form-label fw-semibold">Jenis Kelamin</label><select class="form-select<?= $i_('gender') ?>" name="gender"><option value="L" <?= $o['gender'] === 'L' ? 'selected' : '' ?>>Laki-laki</option><option value="P" <?= $o['gender'] === 'P' ? 'selected' : '' ?>>Perempuan</option></select><?= $m_('gender') ?></div>
            <div class="col-12"><label class="form-label fw-semibold">Alamat</label><textarea class="form-control<?= $i_('address') ?>" name="address" rows="3" maxlength="500"><?= e($o['address']) ?></textarea><?= $m_('address') ?></div>
            <div class="col-md-6"><label class="form-label fw-semibold">Asal Sekolah</label><input class="form-control<?= $i_('previous_school') ?>" name="previous_school" value="<?= e($o['previous_school']) ?>" maxlength="150"><?= $m_('previous_school') ?></div>
            <div class="col-md-6"><label class="form-label fw-semibold">Program Keahlian</label><select class="form-select<?= $i_('program_id') ?>" name="program_id"><?php foreach ($programs as $p): ?><option value="<?= (int)$p['id'] ?>" <?= (string)$o['program_id'] === (string)$p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?></option><?php endforeach; ?></select><?= $m_('program_id') ?></div>
            <div class="col-md-6"><label class="form-label fw-semibold">Telepon</label><input class="form-control<?= $i_('phone') ?>" name="phone" value="<?= e($o['phone']) ?>" maxlength="20"><?= $m_('phone') ?></div>
            <div class="col-md-6"><label class="form-label fw-semibold">Email</label><input class="form-control<?= $i_('email') ?>" name="email" value="<?= e($o['email']) ?>" maxlength="120"><?= $m_('email') ?></div>
            <div class="col-md-6"><label class="form-label fw-semibold">Orang Tua / Wali</label><input class="form-control<?= $i_('parent_name') ?>" name="parent_name" value="<?= e($o['parent_name']) ?>" maxlength="150"><?= $m_('parent_name') ?></div>
            <div class="col-md-6"><label class="form-label fw-semibold">Status Pendaftaran</label><select class="form-select<?= $i_('status') ?>" name="status"><?php foreach ($statuses as $k => $l): ?><option value="<?= $k ?>" <?= $o['status'] === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select><?= $m_('status') ?></div>
            <div class="col-12"><label class="form-label fw-semibold">Catatan Admin (internal)</label><textarea class="form-control<?= $i_('admin_notes') ?>" name="admin_notes" rows="2" maxlength="500"><?= e($o['admin_notes']) ?></textarea><?= $m_('admin_notes') ?></div>
        </div><hr class="my-4"><div class="d-flex gap-2"><button class="btn btn-primary px-4"><i class="fa-solid fa-floppy-disk me-2"></i>Simpan</button><a class="btn btn-light" href="<?= e($self . '?id=' . $id) ?>">Batal</a></div></form></div>
    <?php else: ?>
        <div class="adm-card"><div class="d-flex flex-wrap justify-content-between gap-2 mb-3"><div><h2 class="h4 mb-1"><?= e($r['full_name']) ?></h2><div class="text-muted">No. <strong><?= e($r['registration_no']) ?></strong> &bull; Didaftarkan <?= e(tgl_indo($r['created_at'], true)) ?></div></div><div><?= status_badge($r['status']) ?></div></div>
        <div class="row g-4"><div class="col-lg-8"><table class="table table-sm detail-table"><tbody>
            <?php foreach ([['NISN', $r['nisn'] ?: '-'], ['Tempat, Tanggal Lahir', $r['birth_place'] . ', ' . tgl_indo($r['birth_date'])], ['Jenis Kelamin', $r['gender'] === 'L' ? 'Laki-laki' : 'Perempuan'], ['Alamat', $r['address']], ['Asal Sekolah', $r['previous_school']], ['Program Keahlian', $r['program_name'] ?: '-'], ['Telepon', $r['phone']], ['Email', $r['email'] ?: '-'], ['Orang Tua / Wali', $r['parent_name']], ['Tahun Ajaran', $r['academic_year']], ['Catatan Admin', $r['admin_notes'] ?: '-']] as $row): ?><tr><th style="width:36%"><?= e($row[0]) ?></th><td><?= nl2br(e($row[1])) ?></td></tr><?php endforeach; ?></tbody></table></div>
        <div class="col-lg-4"><div class="p-3 border rounded-3"><h3 class="h6 fw-bold">Ubah Status</h3><form method="post" action="<?= e($self) ?>"><?= csrf_field() ?><input type="hidden" name="do" value="status"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="back" value="detail"><select class="form-select mb-2" name="status"><?php foreach ($statuses as $k => $l): ?><option value="<?= $k ?>" <?= $r['status'] === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select><button class="btn btn-primary w-100">Simpan Status</button></form></div></div></div>
        <hr class="my-4"><div class="d-flex flex-wrap gap-2"><a class="btn btn-outline-primary" href="<?= e($self . '?id=' . $id . '&edit=1') ?>"><i class="fa-solid fa-pen me-1"></i>Edit Data</a><a class="btn btn-light" href="<?= e($self) ?>">Kembali</a>
        <button class="btn btn-outline-danger ms-auto" type="button" data-delete="<?= $id ?>" data-name="<?= e($r['full_name']) ?>" data-action="<?= e($self) ?>"><i class="fa-solid fa-trash me-1"></i>Hapus</button></div></div>
    <?php endif;
    admin_foot(); exit;
}

/* ---------- DAFTAR ---------- */
[$w, $p] = reg_filter($q, $st);
$total = (int)q_val("SELECT COUNT(*) FROM ppdb_registrations $w", $p);
$pg = paginate($total, 10, (int)get_str('page', '1'));
$rows = q_all("SELECT * FROM ppdb_registrations $w ORDER BY id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $p);
$counts = array_fill_keys(array_keys($statuses), 0); foreach (q_all('SELECT status, COUNT(*) c FROM ppdb_registrations GROUP BY status') as $c) $counts[$c['status']] = (int)$c['c'];
admin_head('Data Pendaftar PPDB');
?>
<div class="adm-card">
    <div class="alert alert-info small"><i class="fa-solid fa-shield-halved me-1"></i> Data pendaftar bersifat rahasia dan hanya tampil di dashboard ini, tidak pernah ditampilkan di website publik.</div>
    <div class="adm-pills mb-3"><a class="<?= $st === '' ? 'active' : '' ?>" href="<?= e($self) ?>">Semua (<?= array_sum($counts) ?>)</a><?php foreach ($statuses as $k => $l): ?><a class="<?= $st === $k ? 'active' : '' ?>" href="<?= e($self . '?status=' . $k) ?>"><?= e($l) ?> (<?= $counts[$k] ?>)</a><?php endforeach; ?></div>
    <div class="d-flex flex-wrap gap-2 justify-content-between mb-3">
        <form class="d-flex gap-2 flex-grow-1" method="get" role="search" style="max-width:460px"><?php if ($st): ?><input type="hidden" name="status" value="<?= e($st) ?>"><?php endif; ?><input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="Cari nama, no. daftar, NISN, sekolah..." aria-label="Cari"><button class="btn btn-outline-primary" aria-label="Cari"><i class="fa-solid fa-magnifying-glass"></i></button><?php if ($q !== ''): ?><a class="btn btn-light" href="<?= e($self . ($st ? '?status=' . $st : '')) ?>">Reset</a><?php endif; ?></form>
        <div class="d-flex gap-2"><a class="btn btn-outline-success" href="<?= e($self . '?' . http_build_query(array_filter(['q' => $q, 'status' => $st, 'export' => 'csv']))) ?>"><i class="fa-solid fa-file-csv me-1"></i>Unduh CSV</a><a class="btn btn-outline-secondary" target="_blank" rel="noopener" href="<?= e($self . '?' . http_build_query(array_filter(['q' => $q, 'status' => $st, 'print' => '1']))) ?>"><i class="fa-solid fa-print me-1"></i>Cetak</a></div>
    </div>
    <div class="table-responsive"><table class="table adm-table align-middle"><thead><tr><th>No. Daftar</th><th>Nama</th><th>Program</th><th>Asal Sekolah</th><th>Tanggal</th><th>Status</th><th class="text-end" style="width:160px">Aksi</th></tr></thead><tbody>
    <?php if (!$rows): ?><tr><td colspan="7" class="text-center text-muted py-5"><i class="fa-regular fa-folder-open fa-2x d-block mb-2"></i>Belum ada data pendaftar<?= ($q || $st) ? ' yang cocok dengan filter' : '' ?>.</td></tr><?php endif; ?>
    <?php foreach ($rows as $r): ?><tr><td class="text-nowrap"><small><?= e($r['registration_no']) ?></small></td><td><a href="<?= e($self . '?id=' . $r['id']) ?>" class="fw-semibold"><?= e($r['full_name']) ?></a><small class="d-block text-muted"><?= e($r['phone']) ?></small></td><td><?= e($r['program_name'] ?: '-') ?></td><td><?= e($r['previous_school']) ?></td><td class="text-nowrap"><?= e(tgl_indo($r['created_at'])) ?></td>
        <td><form method="post" action="<?= e($self) ?>" class="status-form"><?= csrf_field() ?><input type="hidden" name="do" value="status"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><select class="form-select form-select-sm" name="status" aria-label="Status" onchange="this.form.submit()"><?php foreach ($statuses as $k => $l): ?><option value="<?= $k ?>" <?= $r['status'] === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select></form></td>
        <td class="text-end text-nowrap"><a class="btn btn-sm btn-outline-secondary" href="<?= e($self . '?id=' . $r['id']) ?>" aria-label="Detail" title="Detail"><i class="fa-solid fa-eye"></i></a> <a class="btn btn-sm btn-outline-primary" href="<?= e($self . '?id=' . $r['id'] . '&edit=1') ?>" aria-label="Edit" title="Edit"><i class="fa-solid fa-pen"></i></a> <button class="btn btn-sm btn-outline-danger" type="button" data-delete="<?= (int)$r['id'] ?>" data-name="<?= e($r['full_name']) ?>" data-action="<?= e($listUrl) ?>" aria-label="Hapus" title="Hapus"><i class="fa-solid fa-trash"></i></button></td></tr><?php endforeach; ?>
    </tbody></table></div>
    <?= admin_pagination($pg, ['q' => $q, 'status' => $st]) ?>
</div>
<?php admin_foot();
