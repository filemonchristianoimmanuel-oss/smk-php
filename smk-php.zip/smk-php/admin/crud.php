<?php
/**
 * Mesin CRUD generik untuk seluruh modul konten (lihat admin/includes/modules.php).
 * Aksi: daftar (a=list), tambah (a=add), ubah (a=edit&id=..), hapus (POST do=delete).
 */
require_once __DIR__ . '/includes/layout.php';
require_admin();

$mods = crud_modules();
$mk = get_str('m');
if (!isset($mods[$mk])) show_404();
$mod = $mods[$mk];
$table = $mod['table'];
$fields = $mod['fields'];

// Muat pilihan untuk kolom relasi (fk)
foreach ($fields as $i => $fd) {
    if ($fd['type'] === 'fk') {
        [$ft, $fl] = $fd['fk'];
        $opts = [];
        foreach (q_all("SELECT id, `$fl` AS label FROM `$ft` ORDER BY `$fl`") as $r) $opts[(string)$r['id']] = $r['label'];
        $fields[$i]['options'] = $opts;
    }
}
$fmap = [];
foreach ($fields as $fd) $fmap[$fd['name']] = $fd;

// Filter (mis. kategori staff) lewat parameter f
$filterField = $mod['filter_field'] ?? null;
$f = get_str('f');
if ($filterField && !isset($fmap[$filterField]['options'][$f])) $f = '';
if (!$filterField) $f = '';
$listUrl = crud_link($mk, $f);
$adminName = $GLOBALS['CURRENT_ADMIN']['full_name'];

$publicView = [
    'news' => fn($r) => ($r['status'] === 'published' && $r['published_at'] && strtotime($r['published_at']) <= time()) ? url('detail-berita.php?slug=' . urlencode($r['slug'])) : null,
    'programs' => fn($r) => $r['is_published'] ? url('program-detail.php?slug=' . urlencode($r['slug'])) : null,
    'agendas' => fn($r) => $r['is_published'] ? url('agenda-detail.php?id=' . (int)$r['id']) : null,
];

/** Validasi + kumpulkan data dari $_POST/$_FILES. */
function crud_collect(array $mod, array $fields, ?array $existing, string $table): array
{
    $data = []; $errors = []; $newFiles = []; $removeFiles = [];
    foreach ($fields as $fd) {
        $n = $fd['name']; $t = $fd['type']; $label = $fd['label'];
        $val = post_str($n);
        $required = !empty($fd['required']);
        switch ($t) {
            case 'text': case 'url': case 'textarea':
                $max = $fd['max'] ?? ($t === 'textarea' ? 20000 : 255);
                if ($required && $val === '') { $errors[$n] = "$label wajib diisi."; break; }
                if (mb_strlen($val) > $max) { $errors[$n] = "$label maksimal $max karakter."; break; }
                if ($t === 'url' && $val !== '' && (!filter_var($val, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $val))) { $errors[$n] = "$label harus berupa URL lengkap (diawali http:// atau https://)."; break; }
                $data[$n] = $val;
                break;
            case 'number':
                if ($val === '') $val = (string)($fd['default'] ?? 0);
                if (!preg_match('/^-?\d{1,9}$/', $val)) { $errors[$n] = "$label harus berupa angka bulat."; break; }
                if (isset($fd['min']) && (int)$val < $fd['min']) { $errors[$n] = "$label minimal {$fd['min']}."; break; }
                if (isset($fd['max']) && (int)$val > $fd['max']) { $errors[$n] = "$label maksimal {$fd['max']}."; break; }
                $data[$n] = (int)$val;
                break;
            case 'date':
                if ($val === '') { if ($required) $errors[$n] = "$label wajib diisi."; else $data[$n] = null; break; }
                $d = DateTime::createFromFormat('Y-m-d', $val);
                if (!$d || $d->format('Y-m-d') !== $val) { $errors[$n] = "$label tidak valid."; break; }
                $data[$n] = $val;
                break;
            case 'time':
                if ($val === '') { $data[$n] = null; break; }
                if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/', $val)) { $errors[$n] = "$label tidak valid."; break; }
                $data[$n] = strlen($val) === 5 ? $val . ':00' : $val;
                break;
            case 'datetime':
                if ($val === '') { $data[$n] = null; break; }
                $d = DateTime::createFromFormat('Y-m-d\TH:i', $val) ?: DateTime::createFromFormat('Y-m-d H:i:s', $val);
                if (!$d) { $errors[$n] = "$label tidak valid."; break; }
                $data[$n] = $d->format('Y-m-d H:i:00');
                break;
            case 'select':
                if ($val === '' && isset($fd['default'])) $val = (string)$fd['default'];
                if ($val === '') { if ($required) $errors[$n] = "$label wajib dipilih."; else $data[$n] = ''; break; }
                if (!array_key_exists($val, $fd['options'])) { $errors[$n] = "Pilihan $label tidak valid."; break; }
                $data[$n] = $val;
                break;
            case 'fk':
                if ($val === '') { if ($required) $errors[$n] = "$label wajib dipilih."; else $data[$n] = null; break; }
                if (!isset($fd['options'][$val])) { $errors[$n] = "Pilihan $label tidak valid."; break; }
                $data[$n] = (int)$val;
                break;
            case 'bool':
                $data[$n] = isset($_POST[$n]) ? 1 : 0;
                break;
            case 'image':
                $old = $existing[$n] ?? null;
                if (isset($_FILES[$n]) && ($_FILES[$n]['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                    [$path, $err] = upload_image($_FILES[$n], $mod['dir'] ?? 'general');
                    if ($err) { $errors[$n] = "$label: $err"; break; }
                    $data[$n] = $path; $newFiles[] = $path;
                    if ($old) $removeFiles[] = $old;
                } elseif (isset($_POST['remove_' . $n]) && $old) {
                    $data[$n] = null; $removeFiles[] = $old;
                } elseif (!$existing) {
                    if (!empty($fd['required_new'])) $errors[$n] = "$label wajib diunggah.";
                    else $data[$n] = null;
                }
                break;
            case 'slug': break; // diproses setelah loop
        }
    }
    foreach ($fields as $fd) {
        if ($fd['type'] === 'slug') {
            $n = $fd['name']; $in = post_str($n);
            if ($in === '' && $existing && !empty($existing[$n])) { $data[$n] = $existing[$n]; continue; }
            $base = $in !== '' ? $in : (string)($data[$fd['from']] ?? '');
            $data[$n] = unique_slug($table, $base, $existing ? (int)$existing['id'] : null, $n);
        }
        if (!empty($fd['after']) && !empty($data[$fd['name']]) && !empty($data[$fd['after']]) && $data[$fd['name']] < $data[$fd['after']]) {
            $errors[$fd['name']] = $fd['label'] . ' tidak boleh lebih awal dari tanggal mulai.';
        }
    }
    return [$data, $errors, $newFiles, $removeFiles];
}

/* ===================== PROSES POST ===================== */
$errors = []; $formData = null; $editRow = null;
$id = (int)($_GET['id'] ?? 0);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf($listUrl);
    $do = post_str('do');
    $pid = (int)post_str('id');

    if ($do === 'delete') {
        $row = q_one("SELECT * FROM `$table` WHERE id = ?", [$pid]);
        if (!$row) { flash('warning', 'Data tidak ditemukan atau sudah dihapus.'); redirect($listUrl); }
        try {
            q_exec("DELETE FROM `$table` WHERE id = ?", [$pid]);
            foreach ($fields as $fd) if ($fd['type'] === 'image') delete_upload($row[$fd['name']] ?? null);
            $label = $row['title'] ?? $row['name'] ?? $row['position'] ?? $row['student_name'] ?? $row['platform'] ?? $row['content'] ?? ('#' . $pid);
            log_activity('Hapus ' . $mod['title'], excerpt((string)$label, 100));
            flash('success', 'Data berhasil dihapus.');
        } catch (Throwable $e) {
            error_log('crud delete: ' . $e->getMessage());
            flash('danger', 'Data tidak dapat dihapus karena masih digunakan oleh data lain.');
        }
        redirect($listUrl);
    }

    if ($do === 'save') {
        $existing = $pid ? q_one("SELECT * FROM `$table` WHERE id = ?", [$pid]) : null;
        if ($pid && !$existing) { flash('danger', 'Data tidak ditemukan.'); redirect($listUrl); }
        [$data, $errors, $newFiles, $removeFiles] = crud_collect($mod, $fields, $existing, $table);
        if (!$errors) {
            if (isset($mod['before_save'])) $data = ($mod['before_save'])($data, $existing);
            try {
                $pdo = db(); $pdo->beginTransaction();
                if ($existing) {
                    $set = implode(', ', array_map(fn($c) => "`$c` = ?", array_keys($data)));
                    q_exec("UPDATE `$table` SET $set WHERE id = ?", array_merge(array_values($data), [$pid]));
                    $savedId = $pid;
                } else {
                    $cols = implode(', ', array_map(fn($c) => "`$c`", array_keys($data)));
                    q_exec("INSERT INTO `$table` ($cols) VALUES (" . implode(',', array_fill(0, count($data), '?')) . ')', array_values($data));
                    $savedId = (int)$pdo->lastInsertId();
                }
                if (!empty($mod['exclusive']) && !empty($data[$mod['exclusive']])) {
                    q_exec("UPDATE `$table` SET `{$mod['exclusive']}` = 0 WHERE id <> ?", [$savedId]);
                }
                $pdo->commit();
                foreach ($removeFiles as $of) delete_upload($of);
                $label = $data['title'] ?? $data['name'] ?? $data['position'] ?? $data['student_name'] ?? $data['platform'] ?? $data['content'] ?? ('#' . $savedId);
                log_activity(($existing ? 'Ubah ' : 'Tambah ') . $mod['title'], excerpt((string)$label, 100));
                flash('success', 'Data berhasil ' . ($existing ? 'diperbarui.' : 'ditambahkan.'));
                $back = $listUrl;
                if ($filterField && isset($data[$filterField]) && $f !== '' && (string)$data[$filterField] !== $f) $back = crud_link($mk, (string)$data[$filterField]);
                redirect($back);
            } catch (Throwable $e) {
                if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
                foreach ($newFiles as $nf) delete_upload($nf);
                error_log('crud save: ' . $e->getMessage());
                $errors['_'] = 'Data gagal disimpan karena kendala sistem' . (APP_DEBUG ? ': ' . $e->getMessage() : '. Periksa kembali isian Anda.');
            }
        } else {
            foreach ($newFiles as $nf) delete_upload($nf);
        }
        $formData = $_POST; $editRow = $existing;
        $id = $pid;
    }
}

/* ===================== TAMPILAN ===================== */
$action = get_str('a', 'list');
if ($formData !== null) $action = $id ? 'edit' : 'add';
if (!in_array($action, ['list', 'add', 'edit'], true)) $action = 'list';

if ($action === 'edit' && $editRow === null) {
    $editRow = q_one("SELECT * FROM `$table` WHERE id = ?", [$id]);
    if (!$editRow) { flash('warning', 'Data tidak ditemukan.'); redirect($listUrl); }
}

/* ---------- FORM TAMBAH / EDIT ---------- */
if ($action === 'add' || $action === 'edit'):
    $isEdit = $action === 'edit';
    admin_head(($isEdit ? 'Edit ' : 'Tambah ') . $mod['title'], [$mod['title'] => $listUrl]);
    $val = function (array $fd) use ($formData, $editRow, $isEdit, $f, $filterField, $adminName) {
        $n = $fd['name'];
        if ($formData !== null && $fd['type'] !== 'image') {
            if ($fd['type'] === 'bool') return isset($formData[$n]) ? 1 : 0;
            return $formData[$n] ?? '';
        }
        if ($isEdit && $editRow) {
            $v = $editRow[$n] ?? '';
            if ($fd['type'] === 'datetime' && $v) return date('Y-m-d\TH:i', strtotime($v));
            if ($fd['type'] === 'time' && $v) return substr($v, 0, 5);
            return $v ?? '';
        }
        if ($filterField && $n === $filterField && $f !== '') return $f;
        if (!empty($fd['default_admin'])) return $adminName;
        return $fd['default'] ?? '';
    };
?>
<div class="adm-card">
    <?php if (!empty($errors['_'])): ?><div class="alert alert-danger"><?= e($errors['_']) ?></div><?php endif; ?>
    <?php if ($errors && empty($errors['_'])): ?><div class="alert alert-danger"><i class="fa-solid fa-circle-exclamation me-1"></i> Data belum dapat disimpan. Periksa kolom yang ditandai merah.</div><?php endif; ?>
    <?php if (!empty($mod['note'])): ?><div class="alert alert-info small"><i class="fa-solid fa-circle-info me-1"></i> <?= e($mod['note']) ?></div><?php endif; ?>
    <form method="post" enctype="multipart/form-data" action="<?= e(crud_link($mk, $f, $isEdit ? 'edit' : 'add') . ($isEdit ? '&id=' . $id : '')) ?>" novalidate data-once>
        <?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" value="<?= $isEdit ? (int)$id : 0 ?>">
        <div class="row g-3">
        <?php foreach ($fields as $fd):
            $n = $fd['name']; $t = $fd['type']; $v = $val($fd);
            $col = in_array($t, ['textarea', 'image']) ? 'col-12' : (($fd['col'] ?? '') ?: 'col-md-6');
            if ($t === 'textarea' || ($t === 'text' && ($fd['max'] ?? 255) > 150)) $col = 'col-12';
            $inv = isset($errors[$n]) ? ' is-invalid' : '';
            $req = !empty($fd['required']) || !empty($fd['required_new']);
        ?>
        <div class="<?= $col ?>">
            <?php if ($t === 'bool'): ?>
                <div class="form-check form-switch mt-md-4"><input class="form-check-input" type="checkbox" role="switch" id="f_<?= $n ?>" name="<?= $n ?>" value="1" <?= $v ? 'checked' : '' ?>><label class="form-check-label fw-semibold" for="f_<?= $n ?>"><?= e($fd['label']) ?></label></div>
            <?php else: ?>
                <label class="form-label fw-semibold" for="f_<?= $n ?>"><?= e($fd['label']) ?><?= $req ? ' <span class="text-danger">*</span>' : '' ?></label>
                <?php if ($t === 'textarea'): ?>
                    <textarea class="form-control<?= $inv ?>" id="f_<?= $n ?>" name="<?= $n ?>" rows="<?= (int)($fd['rows'] ?? 5) ?>"><?= e($v) ?></textarea>
                <?php elseif ($t === 'select' || $t === 'fk'): ?>
                    <select class="form-select<?= $inv ?>" id="f_<?= $n ?>" name="<?= $n ?>"><?php if ($t === 'fk' || empty($fd['required'])) echo '<option value="">' . ($t === 'fk' ? '- Tanpa kategori -' : '- Pilih -') . '</option>'; ?>
                        <?php foreach ($fd['options'] as $ov => $ol): ?><option value="<?= e($ov) ?>" <?= (string)$v === (string)$ov ? 'selected' : '' ?>><?= e($ol) ?></option><?php endforeach; ?></select>
                <?php elseif ($t === 'image'): ?>
                    <?php $cur = $isEdit ? ($editRow[$n] ?? '') : ''; ?>
                    <div class="d-flex flex-wrap gap-3 align-items-start">
                        <?php if ($cur): ?><div><img class="img-thumb" src="<?= e(img_url($cur)) ?>" alt="Gambar saat ini"><div class="form-check mt-1"><input class="form-check-input" type="checkbox" name="remove_<?= $n ?>" id="rm_<?= $n ?>" value="1"><label class="form-check-label small" for="rm_<?= $n ?>">Hapus gambar</label></div></div><?php endif; ?>
                        <div class="flex-grow-1"><input class="form-control<?= $inv ?>" type="file" id="f_<?= $n ?>" name="<?= $n ?>" accept="image/jpeg,image/png,image/webp,image/gif" data-preview="pv_<?= $n ?>"><img id="pv_<?= $n ?>" class="img-thumb mt-2 d-none" alt="Pratinjau"></div>
                    </div>
                <?php elseif ($t === 'date'): ?><input type="date" class="form-control<?= $inv ?>" id="f_<?= $n ?>" name="<?= $n ?>" value="<?= e($v) ?>">
                <?php elseif ($t === 'time'): ?><input type="time" class="form-control<?= $inv ?>" id="f_<?= $n ?>" name="<?= $n ?>" value="<?= e($v) ?>">
                <?php elseif ($t === 'datetime'): ?><input type="datetime-local" class="form-control<?= $inv ?>" id="f_<?= $n ?>" name="<?= $n ?>" value="<?= e($v) ?>">
                <?php elseif ($t === 'number'): ?><input type="number" class="form-control<?= $inv ?>" id="f_<?= $n ?>" name="<?= $n ?>" value="<?= e($v) ?>" <?= isset($fd['min']) ? 'min="' . (int)$fd['min'] . '"' : '' ?> <?= isset($fd['max']) ? 'max="' . (int)$fd['max'] . '"' : '' ?>>
                <?php else: ?>
                    <input type="<?= $t === 'url' ? 'url' : 'text' ?>" class="form-control<?= $inv ?>" id="f_<?= $n ?>" name="<?= $n ?>" value="<?= e($v) ?>" maxlength="<?= (int)($fd['max'] ?? 255) ?>" placeholder="<?= e($fd['placeholder'] ?? '') ?>" <?= !empty($fd['list']) ? 'list="dl_' . $n . '"' : '' ?>>
                    <?php if (!empty($fd['list'])): ?><datalist id="dl_<?= $n ?>"><?php foreach ($fd['list'] as $o) echo '<option value="' . e($o) . '">'; ?></datalist><?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
            <?php if (isset($errors[$n])): ?><div class="invalid-feedback d-block"><?= e($errors[$n]) ?></div><?php endif; ?>
            <?php if (!empty($fd['help'])): ?><div class="form-text"><?= e($fd['help']) ?></div><?php endif; ?>
        </div>
        <?php endforeach; ?>
        </div>
        <hr class="my-4">
        <div class="d-flex gap-2"><button class="btn btn-primary px-4" type="submit"><i class="fa-solid fa-floppy-disk me-2"></i>Simpan</button><a class="btn btn-light" href="<?= e($listUrl) ?>">Batal</a></div>
    </form>
</div>
<?php admin_foot(); exit; endif;

/* ---------- DAFTAR ---------- */
$q = get_str('q');
$where = []; $par = [];
if ($f !== '') { $where[] = "`$filterField` = ?"; $par[] = $f; }
if ($q !== '') {
    $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $q) . '%';
    $parts = [];
    foreach ($mod['search'] as $c) { $parts[] = "`$c` LIKE ?"; $par[] = $like; }
    $where[] = '(' . implode(' OR ', $parts) . ')';
}
$w = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$total = (int)q_val("SELECT COUNT(*) FROM `$table` $w", $par);
$pg = paginate($total, 10, (int)get_str('page', '1'));
$rows = q_all("SELECT * FROM `$table` $w ORDER BY {$mod['order']} LIMIT {$pg['per']} OFFSET {$pg['offset']}", $par);

admin_head($mod['title'], []);
?>
<div class="adm-card">
    <?php if (!empty($mod['note'])): ?><div class="alert alert-info small"><i class="fa-solid fa-circle-info me-1"></i> <?= e($mod['note']) ?></div><?php endif; ?>
    <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
        <form class="d-flex gap-2 flex-grow-1" method="get" role="search" style="max-width:460px">
            <input type="hidden" name="m" value="<?= e($mk) ?>"><?php if ($f !== ''): ?><input type="hidden" name="f" value="<?= e($f) ?>"><?php endif; ?>
            <input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="Cari data..." aria-label="Cari"><button class="btn btn-outline-primary" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
            <?php if ($q !== ''): ?><a class="btn btn-light" href="<?= e($listUrl) ?>">Reset</a><?php endif; ?>
        </form>
        <a class="btn btn-primary" href="<?= e(crud_link($mk, $f, 'add')) ?>"><i class="fa-solid fa-plus me-1"></i>Tambah <?= e($mod['title']) ?></a>
    </div>
    <?php if ($filterField): ?>
        <div class="adm-pills mb-3"><a class="<?= $f === '' ? 'active' : '' ?>" href="<?= e(crud_link($mk)) ?>">Semua</a>
            <?php foreach ($fmap[$filterField]['options'] as $ov => $ol): ?><a class="<?= $f === (string)$ov ? 'active' : '' ?>" href="<?= e(crud_link($mk, (string)$ov)) ?>"><?= e($ol) ?></a><?php endforeach; ?></div>
    <?php endif; ?>
    <div class="table-responsive">
        <table class="table adm-table align-middle">
            <thead><tr><th style="width:44px">#</th><?php foreach ($mod['list'] as $c): ?><th><?= e($c[1]) ?></th><?php endforeach; ?><th class="text-end" style="width:150px">Aksi</th></tr></thead>
            <tbody>
            <?php if (!$rows): ?><tr><td colspan="<?= count($mod['list']) + 2 ?>" class="text-center text-muted py-5"><i class="fa-regular fa-folder-open fa-2x d-block mb-2"></i><?= $q !== '' ? 'Tidak ada data yang cocok dengan pencarian.' : 'Belum ada data. Klik "Tambah" untuk membuat data pertama.' ?></td></tr><?php endif; ?>
            <?php foreach ($rows as $i => $r): ?>
                <tr>
                    <td class="text-muted"><?= $pg['offset'] + $i + 1 ?></td>
                    <?php foreach ($mod['list'] as $c):
                        $name = $c[0]; $type = $c[2] ?? 'text'; $v = $r[$name] ?? null; ?>
                        <td><?php
                        if ($type === 'image') echo '<img class="row-thumb" src="' . e(img_url($v, in_array($mk, ['staff', 'principal']) ? 'photo' : 'landscape')) . '" alt="">';
                        elseif ($type === 'bool') echo $v ? '<span class="badge bg-success">Ya</span>' : '<span class="badge bg-secondary">Tidak</span>';
                        elseif ($type === 'select' || $type === 'fk') {
                            $lbl = $fmap[$name]['options'][(string)$v] ?? ($v === null || $v === '' ? '-' : $v);
                            $cls = ($name === 'status') ? ($v === 'published' ? 'success' : 'warning text-dark') : 'light text-dark border';
                            echo '<span class="badge bg-' . $cls . '">' . e($lbl) . '</span>';
                        }
                        elseif ($type === 'date') echo e(tgl_indo($v));
                        elseif ($type === 'datetime') echo $v ? e(tgl_indo($v, true)) : '<span class="text-muted">-</span>';
                        else echo e(excerpt((string)$v, 70)) ?: '<span class="text-muted">-</span>';
                        ?></td>
                    <?php endforeach; ?>
                    <?php $label = $r['title'] ?? $r['name'] ?? $r['position'] ?? $r['student_name'] ?? $r['platform'] ?? $r['content'] ?? ('#' . $r['id']);
                          $pv = isset($publicView[$mk]) ? ($publicView[$mk])($r) : null; ?>
                    <td class="text-end text-nowrap">
                        <?php if ($pv): ?><a class="btn btn-sm btn-outline-secondary" href="<?= e($pv) ?>" target="_blank" rel="noopener" title="Lihat di website" aria-label="Lihat di website"><i class="fa-solid fa-eye"></i></a><?php endif; ?>
                        <a class="btn btn-sm btn-outline-primary" href="<?= e(crud_link($mk, $f, 'edit') . '&id=' . (int)$r['id']) ?>" title="Edit" aria-label="Edit"><i class="fa-solid fa-pen"></i></a>
                        <button class="btn btn-sm btn-outline-danger" type="button" data-delete="<?= (int)$r['id'] ?>" data-name="<?= e(excerpt((string)$label, 60)) ?>" data-action="<?= e(crud_link($mk, $f) . ($q !== '' ? '&q=' . urlencode($q) : '')) ?>" title="Hapus" aria-label="Hapus"><i class="fa-solid fa-trash"></i></button>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?= admin_pagination($pg, ['m' => $mk, 'f' => $f, 'q' => $q]) ?>
</div>
<?php admin_foot();
