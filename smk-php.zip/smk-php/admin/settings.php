<?php
/** Pengelolaan pengaturan website per kelompok (tabel website_settings). */
require_once __DIR__ . '/includes/layout.php';
require_admin();

$groups = settings_groups();
$g = get_str('g');
if (!isset($groups[$g])) show_404();
$grp = $groups[$g];
$self = admin_url('settings.php?g=' . $g);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf($self);
    $save = []; $newFiles = []; $removeOld = [];
    foreach ($grp['fields'] as $fd) {
        [$key, $label, $type] = $fd; $opts = $fd[3] ?? null;
        $cur = all_settings()[$key] ?? '';
        if ($type === 'image' || $type === 'favicon') {
            if (isset($_FILES[$key]) && ($_FILES[$key]['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                [$path, $err] = upload_image($_FILES[$key], 'general', ['ico' => $type === 'favicon']);
                if ($err) { $errors[$key] = "$label: $err"; continue; }
                $save[$key] = $path; $newFiles[] = $path; if ($cur) $removeOld[] = $cur;
            } elseif (isset($_POST['remove_' . $key]) && $cur) { $save[$key] = ''; $removeOld[] = $cur; }
            continue;
        }
        $v = post_str($key);
        $max = $type === 'textarea' ? 3000 : 255;
        if (mb_strlen($v) > $max) { $errors[$key] = "$label maksimal $max karakter."; continue; }
        if ($type === 'number' && !preg_match('/^\d{1,9}$/', $v === '' ? '0' : $v)) { $errors[$key] = "$label harus berupa angka (0 atau lebih)."; continue; }
        if ($type === 'number' && $v === '') $v = '0';
        if ($type === 'email' && $v !== '' && !filter_var($v, FILTER_VALIDATE_EMAIL)) { $errors[$key] = "$label tidak valid."; continue; }
        if ($type === 'url' && $v !== '' && !preg_match('#^https?://#i', $v)) { $errors[$key] = "$label harus diawali http:// atau https://"; continue; }
        if ($type === 'date' && $v !== '') { $d = DateTime::createFromFormat('Y-m-d', $v); if (!$d || $d->format('Y-m-d') !== $v) { $errors[$key] = "$label tidak valid."; continue; } }
        if ($type === 'select' && !array_key_exists($v, $opts)) { $errors[$key] = "Pilihan $label tidak valid."; continue; }
        if ($key === 'school_name' && $v === '') { $errors[$key] = 'Nama sekolah tidak boleh kosong.'; continue; }
        if ($key === 'ppdb_year' && !preg_match('/^\d{4}\/\d{4}$/', $v)) { $errors[$key] = 'Tahun ajaran harus berformat 2027/2028.'; continue; }
        $save[$key] = $v;
    }
    if (!$errors) {
        try {
            $pdo = db(); $pdo->beginTransaction();
            foreach ($save as $k => $v) {
                // pertahankan kelompok asli kunci jika sudah ada
                $existingGroup = q_val('SELECT setting_group FROM website_settings WHERE setting_key = ?', [$k]);
                save_setting($k, (string)$v, $existingGroup ?: $g);
            }
            $pdo->commit();
            foreach ($removeOld as $o) delete_upload($o);
            log_activity('Ubah Pengaturan', $grp['title']);
            flash('success', 'Pengaturan berhasil disimpan dan langsung diterapkan di website.');
            redirect($self);
        } catch (Throwable $e) {
            if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
            foreach ($newFiles as $nf) delete_upload($nf);
            error_log('settings save: ' . $e->getMessage());
            flash('danger', 'Pengaturan gagal disimpan karena kendala sistem.');
            redirect($self);
        }
    } else foreach ($newFiles as $nf) delete_upload($nf);
}

admin_head($grp['title']);
?>
<div class="adm-card">
    <p class="text-muted"><?= e($grp['desc']) ?></p>
    <?php if ($errors): ?><div class="alert alert-danger"><i class="fa-solid fa-circle-exclamation me-1"></i> Pengaturan belum disimpan. Periksa kolom yang ditandai.</div><?php endif; ?>
    <form method="post" enctype="multipart/form-data" action="<?= e($self) ?>" novalidate data-once>
        <?= csrf_field() ?>
        <div class="row g-3">
        <?php foreach ($grp['fields'] as $fd):
            [$key, $label, $type] = $fd; $opts = $fd[3] ?? null;
            $cur = ($_SERVER['REQUEST_METHOD'] === 'POST' && $type !== 'image' && $type !== 'favicon') ? post_str($key) : (all_settings()[$key] ?? '');
            $inv = isset($errors[$key]) ? ' is-invalid' : '';
            $col = ($type === 'textarea' || $type === 'image' || $type === 'favicon') ? 'col-12' : 'col-md-6'; ?>
            <div class="<?= $col ?>">
                <label class="form-label fw-semibold" for="s_<?= e($key) ?>"><?= e($label) ?></label>
                <?php if ($type === 'textarea'): ?><textarea class="form-control<?= $inv ?>" id="s_<?= e($key) ?>" name="<?= e($key) ?>" rows="4"><?= e($cur) ?></textarea>
                <?php elseif ($type === 'select'): ?><select class="form-select<?= $inv ?>" id="s_<?= e($key) ?>" name="<?= e($key) ?>"><?php foreach ($opts as $ov => $ol): ?><option value="<?= e($ov) ?>" <?= (string)$cur === (string)$ov ? 'selected' : '' ?>><?= e($ol) ?></option><?php endforeach; ?></select>
                <?php elseif ($type === 'image' || $type === 'favicon'): $has = $cur && is_file(ROOT_PATH . '/' . $cur); ?>
                    <div class="d-flex flex-wrap gap-3 align-items-start">
                        <?php if ($has): ?><div><img class="img-thumb" style="max-width:220px;max-height:200px;object-fit:contain" src="<?= e(url($cur)) ?>" alt="Gambar saat ini"><div class="form-check mt-1"><input class="form-check-input" type="checkbox" name="remove_<?= e($key) ?>" id="rm_<?= e($key) ?>" value="1"><label class="form-check-label small" for="rm_<?= e($key) ?>">Hapus (kembali ke bawaan)</label></div></div><?php endif; ?>
                        <div class="flex-grow-1"><input class="form-control<?= $inv ?>" type="file" id="s_<?= e($key) ?>" name="<?= e($key) ?>" accept="<?= $type === 'favicon' ? 'image/png,image/jpeg,image/webp,image/x-icon,.ico' : 'image/jpeg,image/png,image/webp,image/gif' ?>" data-preview="pv_<?= e($key) ?>"><img id="pv_<?= e($key) ?>" class="img-thumb mt-2 d-none" style="max-width:220px" alt="Pratinjau"></div>
                    </div>
                <?php else: ?><input class="form-control<?= $inv ?>" type="<?= in_array($type, ['number', 'date', 'email', 'url']) ? $type : 'text' ?>" id="s_<?= e($key) ?>" name="<?= e($key) ?>" value="<?= e($cur) ?>" <?= $type === 'number' ? 'min="0"' : '' ?>>
                <?php endif; ?>
                <?php if (isset($errors[$key])): ?><div class="invalid-feedback d-block"><?= e($errors[$key]) ?></div><?php endif; ?>
            </div>
        <?php endforeach; ?>
        </div>
        <hr class="my-4"><button class="btn btn-primary px-4" type="submit"><i class="fa-solid fa-floppy-disk me-2"></i>Simpan Pengaturan</button>
    </form>
</div>
<?php admin_foot();
