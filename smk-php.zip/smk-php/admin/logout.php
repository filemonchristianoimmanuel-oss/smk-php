<?php
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth.php';
// Logout hanya lewat POST + CSRF agar tidak bisa dipicu dari tautan/gambar pihak lain.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_valid() && admin_logged_in()) {
    log_activity('Logout', 'Admin keluar dari dashboard');
    admin_session_destroy();
    session_start();
    session_regenerate_id(true);
    flash('success', 'Anda telah logout dengan aman.');
}
redirect(admin_url('login.php'));
