-- =====================================================================
--  DATABASE WEBSITE SMK INFOKOM BOGOR (SMK Informatika Kota Bogor)
--  Cara impor: buka phpMyAdmin > tab "Import" > pilih file ini > Go.N
--  Database "smk_infokom" akan dibuat otomatis.
--  CATATAN: Akun admin TIDAK dibuat di file ini (demi keamanan).
--           Buat akun admin pertama lewat  setup_admin.php  di browser.
--  Seluruh data di bawah adalah DATA CONTOH. Ganti melalui Dashboard Admin.
-- =====================================================================
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
CREATE DATABASE IF NOT EXISTS `smk_infokom` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `smk_infokom`;

DROP TABLE IF EXISTS admin_activity_logs, login_attempts, contact_messages, agendas, agenda_categories, gallery, gallery_categories,
  news, news_categories, ppdb_registrations, ppdb_info, school_rules, student_activities, student_achievements, extracurriculars,
  student_organizations, student_affairs, staff_profiles, overseas_programs, job_center, internship_information, academic_calendar,
  curriculum, study_programs, school_facilities, school_organization, school_vision_mission, school_history, principal_greetings,
  social_links, website_settings, admins;

-- ---------------------------------------------------------------- AKUN & KEAMANAN
CREATE TABLE admins (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  email VARCHAR(120) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  last_login DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_admin_username (username),
  UNIQUE KEY uq_admin_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE login_attempts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ip_address VARCHAR(45) NOT NULL,
  username VARCHAR(100) NOT NULL,
  attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_attempt_ip (ip_address, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE admin_activity_logs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_id INT UNSIGNED NULL,
  admin_name VARCHAR(120) NOT NULL DEFAULT 'sistem',
  action VARCHAR(100) NOT NULL,
  detail VARCHAR(255) NULL,
  ip_address VARCHAR(45) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_log_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- PENGATURAN WEBSITE
CREATE TABLE website_settings (
  setting_key VARCHAR(100) PRIMARY KEY,
  setting_value TEXT NULL,
  setting_group VARCHAR(50) NOT NULL DEFAULT 'umum',
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE social_links (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  platform VARCHAR(50) NOT NULL,
  url VARCHAR(255) NOT NULL,
  icon VARCHAR(60) NOT NULL DEFAULT 'fa-brands fa-instagram',
  sort_order INT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- PROFIL SEKOLAH
CREATE TABLE principal_greetings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  position VARCHAR(150) NOT NULL DEFAULT 'Kepala Sekolah',
  title VARCHAR(200) NOT NULL DEFAULT 'Sambutan Kepala Sekolah',
  content TEXT NOT NULL,
  photo VARCHAR(255) NULL,
  period VARCHAR(60) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE school_history (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  year_label VARCHAR(30) NULL,
  title VARCHAR(200) NOT NULL,
  content TEXT NOT NULL,
  image VARCHAR(255) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE school_vision_mission (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  type ENUM('visi','misi','tujuan') NOT NULL,
  content TEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_vm_type (type, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE school_organization (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  level TINYINT UNSIGNED NOT NULL DEFAULT 1,
  position VARCHAR(150) NOT NULL,
  name VARCHAR(150) NULL,
  description VARCHAR(255) NULL,
  photo VARCHAR(255) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_org_level (level, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE school_facilities (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT NULL,
  image VARCHAR(255) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- AKADEMIK
CREATE TABLE study_programs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  slug VARCHAR(160) NOT NULL,
  short_name VARCHAR(30) NULL,
  icon VARCHAR(60) NOT NULL DEFAULT 'fa-solid fa-laptop-code',
  image VARCHAR(255) NULL,
  description TEXT NOT NULL,
  competencies TEXT NULL,
  career_prospects TEXT NULL,
  supporting_facilities TEXT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY uq_program_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE curriculum (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category ENUM('informasi','program','kegiatan','pendukung') NOT NULL DEFAULT 'informasi',
  title VARCHAR(200) NOT NULL,
  content TEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE academic_calendar (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  academic_year VARCHAR(20) NOT NULL,
  title VARCHAR(200) NOT NULL,
  category ENUM('hari_efektif','libur','ujian','akademik','ppdb') NOT NULL DEFAULT 'akademik',
  start_date DATE NOT NULL,
  end_date DATE NULL,
  description VARCHAR(255) NULL,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_cal_date (start_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE internship_information (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  section ENUM('pengertian','tujuan','tahapan','mitra','dokumentasi','pengumuman') NOT NULL,
  title VARCHAR(200) NOT NULL,
  content TEXT NULL,
  image VARCHAR(255) NULL,
  info_date DATE NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_pkl_section (section, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE job_center (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  section ENUM('informasi','layanan','lowongan','mitra','persyaratan','kontak') NOT NULL,
  title VARCHAR(200) NOT NULL,
  company VARCHAR(150) NULL,
  content TEXT NULL,
  image VARCHAR(255) NULL,
  deadline DATE NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_bkk_section (section, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE overseas_programs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  program ENUM('luar_negeri','jepang') NOT NULL,
  section ENUM('penjelasan','tujuan','persyaratan','seleksi','pelatihan','pembekalan','dokumentasi','kontak') NOT NULL,
  title VARCHAR(200) NOT NULL,
  content TEXT NULL,
  image VARCHAR(255) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_ovs (program, section, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- GURU & STAFF
CREATE TABLE staff_profiles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category ENUM('pimpinan','wakasek','guru','staff_usaha','staff_kurikulum') NOT NULL DEFAULT 'guru',
  name VARCHAR(150) NOT NULL,
  position VARCHAR(150) NULL,
  subject VARCHAR(150) NULL,
  description VARCHAR(500) NULL,
  photo VARCHAR(255) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_staff_cat (category, is_published, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- KESISWAAN
CREATE TABLE student_affairs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  section ENUM('informasi','pembinaan','dokumentasi') NOT NULL DEFAULT 'informasi',
  title VARCHAR(200) NOT NULL,
  content TEXT NULL,
  image VARCHAR(255) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE student_organizations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  section ENUM('informasi','struktur','program','dokumentasi') NOT NULL DEFAULT 'informasi',
  title VARCHAR(200) NOT NULL,
  subtitle VARCHAR(150) NULL,
  content TEXT NULL,
  image VARCHAR(255) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE extracurriculars (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT NULL,
  schedule VARCHAR(150) NULL,
  mentor VARCHAR(150) NULL,
  image VARCHAR(255) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE student_achievements (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  student_name VARCHAR(200) NOT NULL,
  title VARCHAR(200) NOT NULL,
  level ENUM('sekolah','kecamatan','kota','provinsi','nasional','internasional') NOT NULL DEFAULT 'sekolah',
  achievement_date DATE NOT NULL,
  description TEXT NULL,
  image VARCHAR(255) NULL,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_ach_date (achievement_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE student_activities (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  activity_date DATE NOT NULL,
  description TEXT NULL,
  image VARCHAR(255) NULL,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_act_date (activity_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE school_rules (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category VARCHAR(100) NOT NULL DEFAULT 'Umum',
  title VARCHAR(200) NOT NULL,
  content TEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- PPDB
CREATE TABLE ppdb_info (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  type ENUM('persyaratan','jadwal','alur','jalur','faq') NOT NULL,
  title VARCHAR(200) NOT NULL,
  content TEXT NULL,
  date_label VARCHAR(120) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_ppdb_type (type, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE ppdb_registrations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  registration_no VARCHAR(30) NULL,
  academic_year VARCHAR(20) NULL,
  full_name VARCHAR(150) NOT NULL,
  nisn VARCHAR(10) NULL,
  birth_place VARCHAR(100) NOT NULL,
  birth_date DATE NOT NULL,
  gender ENUM('L','P') NOT NULL,
  address TEXT NOT NULL,
  previous_school VARCHAR(150) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  email VARCHAR(120) NULL,
  program_id INT UNSIGNED NULL,
  program_name VARCHAR(150) NULL,
  parent_name VARCHAR(150) NOT NULL,
  status ENUM('menunggu','diverifikasi','diterima','ditolak') NOT NULL DEFAULT 'menunggu',
  admin_notes VARCHAR(500) NULL,
  ip_address VARCHAR(45) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_reg_no (registration_no),
  KEY idx_reg_status (status),
  KEY idx_reg_name (full_name),
  CONSTRAINT fk_reg_program FOREIGN KEY (program_id) REFERENCES study_programs(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- BERITA
CREATE TABLE news_categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(120) NOT NULL,
  UNIQUE KEY uq_newscat_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE news (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NULL,
  title VARCHAR(220) NOT NULL,
  slug VARCHAR(240) NOT NULL,
  summary VARCHAR(400) NULL,
  content MEDIUMTEXT NOT NULL,
  image VARCHAR(255) NULL,
  status ENUM('draft','published') NOT NULL DEFAULT 'draft',
  published_at DATETIME NULL,
  author VARCHAR(100) NULL,
  views INT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_news_slug (slug),
  KEY idx_news_pub (status, published_at),
  CONSTRAINT fk_news_cat FOREIGN KEY (category_id) REFERENCES news_categories(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- GALERI
CREATE TABLE gallery_categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(120) NOT NULL,
  UNIQUE KEY uq_galcat_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE gallery (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NULL,
  title VARCHAR(200) NOT NULL,
  caption VARCHAR(500) NULL,
  image VARCHAR(255) NULL,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_gal_cat (category_id, is_published),
  CONSTRAINT fk_gal_cat FOREIGN KEY (category_id) REFERENCES gallery_categories(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- AGENDA
CREATE TABLE agenda_categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(120) NOT NULL,
  UNIQUE KEY uq_agcat_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE agendas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NULL,
  title VARCHAR(200) NOT NULL,
  description TEXT NULL,
  event_date DATE NOT NULL,
  end_date DATE NULL,
  start_time TIME NULL,
  end_time TIME NULL,
  location VARCHAR(200) NULL,
  image VARCHAR(255) NULL,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_agenda_date (event_date),
  CONSTRAINT fk_agenda_cat FOREIGN KEY (category_id) REFERENCES agenda_categories(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- KONTAK
CREATE TABLE contact_messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(120) NOT NULL,
  subject VARCHAR(200) NOT NULL,
  message TEXT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  is_starred TINYINT(1) NOT NULL DEFAULT 0,
  ip_address VARCHAR(45) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_msg_read (is_read, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
--  DATA AWAL (CONTOH) - ganti melalui Dashboard Admin
-- =====================================================================
SET NAMES utf8mb4;

INSERT INTO website_settings (setting_key, setting_value, setting_group) VALUES
('school_name','SMK INFOKOM BOGOR','umum'),
('school_fullname','SMK Informatika Kota Bogor','umum'),
('school_tagline','Mencetak generasi terampil, berkarakter, dan siap kerja di era digital','umum'),
('logo','','umum'),
('favicon','','umum'),
('npsn','20238531','identitas'),
('school_status','Sekolah Menengah Kejuruan Swasta','identitas'),
('accreditation','A','identitas'),
('profile_summary','SMK INFOKOM BOGOR (SMK Informatika Kota Bogor) adalah Sekolah Menengah Kejuruan swasta di Kota Bogor yang membekali siswa dengan keterampilan teknologi informasi dan komunikasi, karakter yang kuat, serta pengalaman praktik di dunia usaha dan dunia industri.','identitas'),
('org_chart_image','','identitas'),
('address','Jl. Letjen Ibrahim Adjie No. 178, Sindang Barang, Kota Bogor, Jawa Barat, Indonesia','kontak'),
('phone','0251-8348108','kontak'),
('email','smk.infokom@gmail.com','kontak'),
('website','smk.infokom.sch.id','kontak'),
('service_hours','Senin - Jumat, 07.00 - 15.00 WIB (contoh, silakan sesuaikan)','kontak'),
('map_url','https://www.google.com/maps?q=Jl.+Letjen+Ibrahim+Adjie+No.+178,+Sindang+Barang,+Bogor&output=embed','kontak'),
('hero_title','Belajar Teknologi, Berkarya untuk Masa Depan','hero'),
('hero_subtitle','Selamat datang di SMK INFOKOM BOGOR. Kami membekali siswa dengan kompetensi teknologi informasi, kedisiplinan, dan pengalaman industri agar siap bekerja, berwirausaha, maupun melanjutkan pendidikan.','hero'),
('hero_image','','hero'),
('stat_students','900','statistik'),
('stat_teachers','30','statistik'),
('stat_classgroups','29','statistik'),
('stat_classrooms','27','statistik'),
('stat_labs','2','statistik'),
('stat_note','Data perkiraan awal, belum diverifikasi. Admin dapat memperbarui melalui dashboard.','statistik'),
('ppdb_title','PPDB Online SMK INFOKOM BOGOR','ppdb'),
('ppdb_year','2027/2028','ppdb'),
('ppdb_info','Penerimaan Peserta Didik Baru (PPDB) SMK INFOKOM BOGOR dibuka bagi lulusan SMP/MTs atau sederajat. Isi formulir pendaftaran online di halaman ini, lalu pantau informasi selanjutnya dari panitia PPDB melalui nomor telepon yang Anda daftarkan.','ppdb'),
('ppdb_brochure','','ppdb'),
('ppdb_contact_name','Panitia PPDB SMK INFOKOM BOGOR','ppdb'),
('ppdb_contact_phone','0251-8348108','ppdb'),
('ppdb_contact_email','smk.infokom@gmail.com','ppdb'),
('ppdb_cta_text','Jadilah bagian dari keluarga besar SMK INFOKOM BOGOR. Daftar sekarang dan wujudkan karier di bidang teknologi.','ppdb'),
('ppdb_open','1','ppdb_form'),
('ppdb_close_date','','ppdb_form'),
('ppdb_require_nisn','0','ppdb_form'),
('ppdb_require_email','0','ppdb_form'),
('ppdb_success_message','Pendaftaran Anda berhasil disimpan. Simpan nomor pendaftaran Anda dan tunggu informasi verifikasi dari panitia PPDB.','ppdb_form'),
('footer_about','SMK INFOKOM BOGOR - sekolah kejuruan teknologi informasi di Kota Bogor yang berfokus pada keterampilan, karakter, dan kesiapan kerja lulusan.','footer'),
('footer_copyright','SMK INFOKOM BOGOR. Seluruh hak cipta dilindungi.','footer'),
('meta_description','Website resmi SMK INFOKOM BOGOR (SMK Informatika Kota Bogor): profil sekolah, program keahlian, PPDB online, berita, galeri, dan agenda sekolah.','seo'),
('meta_keywords','SMK Infokom Bogor, SMK Informatika Kota Bogor, SMK Bogor, PPDB Bogor, SMK teknologi informasi','seo');

INSERT INTO social_links (platform, url, icon, sort_order) VALUES
('Instagram','https://www.instagram.com/','fa-brands fa-instagram',1),
('Facebook','https://www.facebook.com/','fa-brands fa-facebook-f',2),
('YouTube','https://www.youtube.com/','fa-brands fa-youtube',3),
('TikTok','https://www.tiktok.com/','fa-brands fa-tiktok',4);

INSERT INTO principal_greetings (name, position, title, content, period, is_active) VALUES
('Nama Kepala Sekolah (contoh)','Kepala SMK INFOKOM BOGOR','Sambutan Kepala Sekolah',
'Assalamualaikum warahmatullahi wabarakatuh. Selamat datang di website resmi SMK INFOKOM BOGOR.\n\nKami berkomitmen menghadirkan pendidikan kejuruan yang berkualitas, relevan dengan kebutuhan dunia usaha dan dunia industri, serta menanamkan karakter disiplin, jujur, dan bertanggung jawab pada setiap siswa.\n\nMelalui website ini, kami berharap orang tua, siswa, alumni, dan masyarakat dapat memperoleh informasi sekolah dengan mudah dan transparan. Mari bersama-sama membangun generasi yang unggul, terampil, dan berakhlak mulia.\n\nWassalamualaikum warahmatullahi wabarakatuh.\n\n[Teks contoh - ganti dengan sambutan resmi melalui Dashboard Admin > Profil Sekolah > Sambutan Kepala Sekolah]',
'Tahun Ajaran 2026/2027', 1);

INSERT INTO school_history (year_label, title, content, sort_order) VALUES
(NULL,'Sekilas Sejarah SMK INFOKOM BOGOR','SMK INFOKOM BOGOR adalah sekolah menengah kejuruan swasta yang berlokasi di Sindang Barang, Kota Bogor. Sekolah ini hadir untuk menyiapkan lulusan di bidang teknologi informasi dan komunikasi yang kompeten dan berkarakter.\n\n[Teks contoh - sejarah resmi (tahun berdiri, pendiri, perkembangan) dapat diisi melalui Dashboard Admin > Profil Sekolah > Sejarah Sekolah]',1);

INSERT INTO school_vision_mission (type, content, sort_order) VALUES
('visi','Menjadi SMK unggul di bidang teknologi informasi dan komunikasi yang menghasilkan lulusan kompeten, berkarakter, dan siap bersaing di dunia kerja. (contoh - sesuaikan dengan visi resmi sekolah)',1),
('misi','Menyelenggarakan pembelajaran kejuruan yang berbasis kompetensi dan kebutuhan industri.',1),
('misi','Membangun budaya disiplin, jujur, dan tanggung jawab dalam kehidupan sekolah.',2),
('misi','Menjalin kemitraan dengan dunia usaha dan dunia industri untuk praktik kerja dan penyaluran lulusan.',3),
('misi','Mengembangkan bakat dan minat siswa melalui kegiatan ekstrakurikuler dan organisasi siswa.',4),
('tujuan','Menghasilkan lulusan yang menguasai kompetensi keahlian sesuai standar industri. (contoh)',1),
('tujuan','Menyiapkan lulusan yang siap bekerja, berwirausaha, atau melanjutkan pendidikan ke jenjang lebih tinggi. (contoh)',2),
('tujuan','Membentuk peserta didik yang beriman, berakhlak mulia, dan mandiri. (contoh)',3);

INSERT INTO school_organization (level, position, name, description, sort_order) VALUES
(1,'Kepala Sekolah','Nama Kepala Sekolah (contoh)',NULL,1),
(2,'Wakil Kepala Sekolah Bidang Kurikulum','Nama (contoh)',NULL,1),
(2,'Wakil Kepala Sekolah Bidang Kesiswaan','Nama (contoh)',NULL,2),
(2,'Wakil Kepala Sekolah Bidang Sarana Prasarana','Nama (contoh)',NULL,3),
(2,'Wakil Kepala Sekolah Bidang Hubungan Industri','Nama (contoh)',NULL,4),
(3,'Ketua Program Keahlian','Nama (contoh)',NULL,1),
(3,'Kepala Tata Usaha','Nama (contoh)',NULL,2),
(3,'Koordinator BKK dan PKL','Nama (contoh)',NULL,3);

INSERT INTO school_facilities (name, description, image, sort_order) VALUES
('Ruang Kelas','Ruang kelas yang nyaman untuk kegiatan belajar mengajar.','assets/images/seed/kelas.svg',1),
('Laboratorium Komputer','Laboratorium komputer untuk praktik pemrograman, jaringan, dan multimedia.','assets/images/seed/lab.svg',2),
('Perpustakaan','Perpustakaan sebagai pusat literasi dan sumber belajar siswa.','assets/images/seed/perpus.svg',3),
('Area Kegiatan Siswa','Area terbuka untuk olahraga, upacara, dan kegiatan siswa.','assets/images/seed/olahraga.svg',4),
('Ruang Kegiatan Ekstrakurikuler','Ruang pendukung kegiatan OSIS dan ekstrakurikuler.','assets/images/seed/kegiatan.svg',5),
('Fasilitas Pendukung Pembelajaran','Jaringan internet, proyektor, dan perangkat penunjang pembelajaran.','assets/images/seed/lab.svg',6);

INSERT INTO study_programs (name, slug, short_name, icon, description, competencies, career_prospects, supporting_facilities, sort_order) VALUES
('Rekayasa Perangkat Lunak','rekayasa-perangkat-lunak','RPL','fa-solid fa-code','Program keahlian yang mempelajari pengembangan aplikasi web, desktop, dan mobile. (contoh - sesuaikan program keahlian resmi sekolah)','- Dasar pemrograman dan algoritma\n- Pemrograman web (HTML, CSS, JavaScript, PHP)\n- Basis data (MySQL)\n- Pengembangan aplikasi mobile\n- Pengujian dan dokumentasi perangkat lunak','- Web developer\n- Programmer aplikasi\n- Software tester\n- Wirausaha bidang digital','- Laboratorium komputer\n- Koneksi internet\n- Perangkat lunak pengembangan aplikasi',1),
('Teknik Komputer dan Jaringan','teknik-komputer-dan-jaringan','TKJ','fa-solid fa-network-wired','Program keahlian yang mempelajari perakitan komputer, jaringan, server, dan keamanan jaringan. (contoh - sesuaikan program keahlian resmi sekolah)','- Perakitan dan perawatan komputer\n- Administrasi sistem operasi dan server\n- Instalasi jaringan LAN dan WLAN\n- Dasar keamanan jaringan','- Teknisi jaringan\n- Administrator jaringan\n- Teknisi komputer\n- Support IT','- Laboratorium jaringan\n- Perangkat router dan switch\n- Peralatan praktik perakitan',2),
('Desain Komunikasi Visual','desain-komunikasi-visual','DKV','fa-solid fa-palette','Program keahlian yang mempelajari desain grafis, fotografi, video, dan animasi. (contoh - sesuaikan program keahlian resmi sekolah)','- Desain grafis dan tipografi\n- Fotografi dan videografi\n- Animasi 2D\n- Penyuntingan video','- Desainer grafis\n- Videografer dan editor\n- Content creator\n- Animator','- Laboratorium multimedia\n- Perangkat desain dan editing\n- Peralatan fotografi',3);

INSERT INTO curriculum (category, title, content, sort_order) VALUES
('informasi','Kurikulum yang Diterapkan','SMK INFOKOM BOGOR menerapkan kurikulum nasional untuk sekolah menengah kejuruan. (contoh - sesuaikan dengan kurikulum yang digunakan, misalnya Kurikulum Merdeka)',1),
('program','Struktur Program Pembelajaran','Pembelajaran terdiri atas kelompok mata pelajaran umum, kejuruan, dan projek penguatan karakter, dengan porsi praktik yang lebih besar.\n\n- Mata pelajaran umum\n- Mata pelajaran kejuruan\n- Projek kreatif dan kewirausahaan\n- Praktik Kerja Lapangan',1),
('kegiatan','Kegiatan Pembelajaran','Kegiatan pembelajaran dilakukan melalui teori, praktik di laboratorium, projek kelompok, dan kunjungan industri.',1),
('pendukung','Informasi Pendukung Akademik','Penilaian dilakukan secara berkelanjutan melalui ujian sekolah, uji kompetensi keahlian (UKK), dan penilaian projek. Informasi lengkap disampaikan oleh wali kelas dan bagian kurikulum.',1);

INSERT INTO academic_calendar (academic_year, title, category, start_date, end_date, description) VALUES
('2026/2027','Hari efektif semester ganjil','hari_efektif','2026-07-13','2026-12-18','Kegiatan belajar mengajar semester ganjil'),
('2026/2027','Masa Pengenalan Lingkungan Sekolah','akademik','2026-07-13','2026-07-15',NULL),
('2026/2027','Penilaian Tengah Semester Ganjil','ujian','2026-09-28','2026-10-02',NULL),
('2026/2027','Penilaian Akhir Semester Ganjil','ujian','2026-12-07','2026-12-12',NULL),
('2026/2027','Libur akhir semester ganjil','libur','2026-12-21','2027-01-02',NULL),
('2026/2027','Hari efektif semester genap','hari_efektif','2027-01-04','2027-06-19','Kegiatan belajar mengajar semester genap'),
('2026/2027','Uji Kompetensi Keahlian (UKK)','ujian','2027-03-15','2027-03-27',NULL),
('2026/2027','Pendaftaran peserta didik baru (PPDB)','ppdb','2027-01-11','2027-06-05','Gelombang pendaftaran (contoh, sesuaikan jadwal resmi)'),
('2026/2027','Penilaian Akhir Tahun','ujian','2027-06-07','2027-06-12',NULL),
('2026/2027','Pembagian rapor dan libur kenaikan kelas','libur','2027-06-21','2027-07-10',NULL);

INSERT INTO internship_information (section, title, content, sort_order) VALUES
('pengertian','Apa itu PKL?','Praktik Kerja Lapangan (PKL) adalah kegiatan belajar siswa di dunia usaha atau dunia industri untuk menerapkan kompetensi keahlian pada situasi kerja yang nyata.',1),
('tujuan','Tujuan PKL','- Menerapkan ilmu yang dipelajari di sekolah pada pekerjaan nyata\n- Membangun disiplin dan etos kerja\n- Mengenal budaya kerja industri\n- Menambah pengalaman dan jejaring profesional',1),
('tahapan','Persiapan dan pembekalan','Siswa mengikuti pembekalan tentang etika kerja, keselamatan kerja, dan tata cara PKL.',1),
('tahapan','Penempatan','Siswa ditempatkan di mitra industri sesuai program keahlian dan ketersediaan tempat.',2),
('tahapan','Pelaksanaan dan bimbingan','Siswa melaksanakan PKL dengan bimbingan pembimbing industri dan pembimbing sekolah.',3),
('tahapan','Penilaian dan laporan','Siswa menyusun laporan dan mengikuti penilaian akhir PKL.',4),
('mitra','Mitra Industri (contoh)','Daftar mitra industri resmi diisi oleh admin setelah terverifikasi. Jangan menampilkan nama perusahaan yang belum bekerja sama.',1),
('dokumentasi','Dokumentasi Kegiatan PKL (contoh)','Foto kegiatan PKL dapat diunggah oleh admin.',1),
('pengumuman','Pengumuman PKL (contoh)','Informasi jadwal dan penempatan PKL akan diumumkan di halaman ini.',1);

INSERT INTO job_center (section, title, company, content, sort_order) VALUES
('informasi','Tentang Bursa Kerja Khusus (BKK)',NULL,'Bursa Kerja Khusus (BKK) adalah unit sekolah yang membantu lulusan memperoleh informasi dan penempatan kerja yang sesuai kompetensi.',1),
('layanan','Layanan Penempatan Kerja',NULL,'- Informasi lowongan kerja\n- Bimbingan karier dan persiapan wawancara\n- Penyaluran lulusan ke mitra perusahaan\n- Pelacakan alumni (tracer study)',1),
('lowongan','Informasi Lowongan Kerja (contoh)','Nama perusahaan mitra','Belum ada lowongan resmi yang dipublikasikan. Admin dapat menambahkan lowongan melalui dashboard.',1),
('mitra','Perusahaan Mitra (contoh)',NULL,'Daftar perusahaan mitra diisi setelah kerja sama terverifikasi.',1),
('persyaratan','Persyaratan Pendaftaran Pencari Kerja','','- Lulusan atau alumni SMK INFOKOM BOGOR\n- Mengisi data diri di BKK\n- Membawa fotokopi ijazah dan transkrip nilai\n- Membawa CV/lamaran dan pas foto\n(contoh - sesuaikan dengan ketentuan BKK)',1),
('kontak','Kontak BKK',NULL,'Hubungi BKK melalui nomor sekolah 0251-8348108 atau email smk.infokom@gmail.com.',1);

INSERT INTO overseas_programs (program, section, title, content, sort_order) VALUES
('luar_negeri','penjelasan','Program Kerja ke Luar Negeri','Informasi program kerja ke luar negeri bagi lulusan. Detail kerja sama dan jadwal keberangkatan hanya dipublikasikan setelah terverifikasi resmi oleh sekolah dan lembaga penyalur yang sah.',1),
('luar_negeri','tujuan','Tujuan Program','Membuka kesempatan lulusan memperoleh pengalaman kerja internasional melalui jalur resmi dan aman.',1),
('luar_negeri','kontak','Kontak','Informasi lebih lanjut dapat ditanyakan ke BKK sekolah di 0251-8348108.',1),
('jepang','penjelasan','Program Kerja ke Jepang','Halaman ini disiapkan untuk informasi program kerja ke Jepang. Isi resmi (mitra, kuota, jadwal) akan diperbarui oleh admin setelah ada informasi terverifikasi. (contoh)',1),
('jepang','tujuan','Tujuan Program','Menyiapkan lulusan yang memiliki kompetensi kerja dan kemampuan bahasa untuk peluang kerja di Jepang melalui jalur resmi.',1),
('jepang','persyaratan','Persyaratan (contoh)','- Lulusan SMK/sederajat\n- Sehat jasmani dan rohani\n- Bersedia mengikuti pelatihan bahasa dan pembekalan\n- Persyaratan lain sesuai lembaga penyalur resmi',1),
('jepang','seleksi','Tahapan Seleksi (contoh)','- Pendaftaran dan seleksi administrasi\n- Tes kemampuan dasar\n- Wawancara\n- Pengumuman hasil seleksi',1),
('jepang','pelatihan','Pelatihan Bahasa Jepang (contoh)','Peserta mengikuti pelatihan bahasa Jepang sesuai jadwal yang ditetapkan penyelenggara.',1),
('jepang','pembekalan','Informasi Pembekalan (contoh)','Pembekalan mencakup budaya kerja, etika, keselamatan kerja, dan hal administratif.',1),
('jepang','dokumentasi','Dokumentasi (contoh)','Dokumentasi kegiatan akan ditampilkan setelah tersedia.',1),
('jepang','kontak','Kontak yang Dapat Dihubungi','Hubungi sekolah di 0251-8348108 atau smk.infokom@gmail.com.',1);

INSERT INTO staff_profiles (category, name, position, subject, description, sort_order) VALUES
('pimpinan','Nama Kepala Sekolah (contoh)','Kepala Sekolah',NULL,'Pimpinan SMK INFOKOM BOGOR. (data contoh - ganti dengan data resmi)',1),
('wakasek','Nama Wakasek Kurikulum (contoh)','Wakil Kepala Sekolah Bidang Kurikulum',NULL,'Data contoh',1),
('wakasek','Nama Wakasek Kesiswaan (contoh)','Wakil Kepala Sekolah Bidang Kesiswaan',NULL,'Data contoh',2),
('wakasek','Nama Wakasek Sarpras (contoh)','Wakil Kepala Sekolah Bidang Sarana Prasarana',NULL,'Data contoh',3),
('wakasek','Nama Wakasek Humas (contoh)','Wakil Kepala Sekolah Bidang Hubungan Industri',NULL,'Data contoh',4),
('guru','Nama Guru 1 (contoh)','Guru Produktif','Pemrograman Web',NULL,1),
('guru','Nama Guru 2 (contoh)','Guru Produktif','Jaringan Komputer',NULL,2),
('guru','Nama Guru 3 (contoh)','Guru Produktif','Desain Grafis',NULL,3),
('guru','Nama Guru 4 (contoh)','Guru Produktif','Basis Data',NULL,4),
('guru','Nama Guru 5 (contoh)','Guru Normatif','Pendidikan Agama',NULL,5),
('guru','Nama Guru 6 (contoh)','Guru Normatif','Bahasa Indonesia',NULL,6),
('guru','Nama Guru 7 (contoh)','Guru Adaptif','Matematika',NULL,7),
('guru','Nama Guru 8 (contoh)','Guru Adaptif','Bahasa Inggris',NULL,8),
('staff_usaha','Nama Staff Usaha 1 (contoh)','Kepala Tata Usaha',NULL,'Data contoh',1),
('staff_usaha','Nama Staff Usaha 2 (contoh)','Staff Administrasi Keuangan',NULL,'Data contoh',2),
('staff_usaha','Nama Staff Usaha 3 (contoh)','Staff Administrasi Umum',NULL,'Data contoh',3),
('staff_kurikulum','Nama Staff Kurikulum 1 (contoh)','Staff Kurikulum',NULL,'Data contoh',1),
('staff_kurikulum','Nama Staff Kurikulum 2 (contoh)','Staff Kurikulum',NULL,'Data contoh',2);

INSERT INTO student_affairs (section, title, content, sort_order) VALUES
('informasi','Informasi Umum Kesiswaan','Bidang kesiswaan membina karakter, kedisiplinan, bakat, dan prestasi siswa SMK INFOKOM BOGOR melalui program pembinaan yang terarah.',1),
('pembinaan','Pembinaan Karakter dan Kedisiplinan','Pembiasaan sikap disiplin, religius, jujur, dan peduli lingkungan melalui kegiatan rutin di sekolah.',1),
('pembinaan','Pembinaan Bakat dan Minat','Siswa dapat mengembangkan bakat melalui ekstrakurikuler, lomba, dan kegiatan OSIS.',2),
('dokumentasi','Dokumentasi Kegiatan Kesiswaan (contoh)','Foto dan dokumentasi kegiatan dapat ditambahkan oleh admin.',1);

INSERT INTO student_organizations (section, title, subtitle, content, sort_order) VALUES
('informasi','Tentang OSIS',NULL,'OSIS (Organisasi Siswa Intra Sekolah) adalah wadah siswa untuk berorganisasi, belajar memimpin, dan menyelenggarakan kegiatan positif di sekolah.',1),
('struktur','Ketua OSIS','Nama (contoh)','Periode 2026/2027 (contoh)',1),
('struktur','Wakil Ketua OSIS','Nama (contoh)',NULL,2),
('struktur','Sekretaris','Nama (contoh)',NULL,3),
('struktur','Bendahara','Nama (contoh)',NULL,4),
('program','Program Kerja OSIS','','- Masa Pengenalan Lingkungan Sekolah\n- Peringatan Hari Besar Nasional dan Keagamaan\n- Pekan olahraga dan seni\n- Kegiatan sosial dan kebersihan lingkungan\n(contoh - sesuaikan program kerja resmi)',1),
('dokumentasi','Dokumentasi Kegiatan OSIS (contoh)','','Foto kegiatan OSIS dapat diunggah oleh admin.',1);

INSERT INTO extracurriculars (name, description, schedule, mentor, image, sort_order) VALUES
('Pramuka','Kegiatan kepramukaan untuk melatih kemandirian, kepemimpinan, dan kerja sama. (contoh)','Jumat, 14.00 WIB (contoh)',NULL,'assets/images/seed/kegiatan.svg',1),
('Paskibra','Latihan baris-berbaris dan kedisiplinan. (contoh)','Sabtu, 07.00 WIB (contoh)',NULL,'assets/images/seed/olahraga.svg',2),
('Futsal','Kegiatan olahraga futsal untuk kebugaran dan sportivitas. (contoh)','Rabu, 15.00 WIB (contoh)',NULL,'assets/images/seed/olahraga.svg',3),
('Komunitas Programming','Belajar pemrograman lanjutan dan persiapan lomba. (contoh)','Kamis, 15.00 WIB (contoh)',NULL,'assets/images/seed/lab.svg',4),
('Rohis','Pembinaan keagamaan dan akhlak siswa. (contoh)','Jumat, 13.00 WIB (contoh)',NULL,'assets/images/seed/kegiatan.svg',5),
('Multimedia Club','Praktik fotografi, videografi, dan desain. (contoh)','Selasa, 15.00 WIB (contoh)',NULL,'assets/images/seed/lab.svg',6);

INSERT INTO student_achievements (student_name, title, level, achievement_date, description, image) VALUES
('Nama Siswa/Tim (contoh)','Contoh Prestasi Lomba Kompetensi','kota','2026-08-17','Data contoh. Admin dapat mengganti dengan prestasi siswa yang sebenarnya.','assets/images/seed/prestasi.svg'),
('Nama Siswa/Tim (contoh)','Contoh Prestasi Olahraga','kecamatan','2026-05-10','Data contoh.','assets/images/seed/prestasi.svg'),
('Nama Siswa/Tim (contoh)','Contoh Prestasi Karya Digital','provinsi','2026-03-21','Data contoh.','assets/images/seed/prestasi.svg');

INSERT INTO student_activities (title, activity_date, description, image) VALUES
('Masa Pengenalan Lingkungan Sekolah (contoh)','2026-07-13','Kegiatan pengenalan sekolah bagi siswa baru.','assets/images/seed/kegiatan.svg'),
('Peringatan Hari Kemerdekaan (contoh)','2026-08-17','Upacara dan lomba antarkelas dalam rangka HUT Kemerdekaan RI.','assets/images/seed/kegiatan.svg'),
('Kunjungan Industri (contoh)','2026-09-18','Kunjungan siswa ke dunia industri.','assets/images/seed/kelas.svg');

INSERT INTO school_rules (category, title, content, sort_order) VALUES
('Peraturan Sekolah','Kehadiran dan Ketepatan Waktu','- Siswa hadir sebelum bel masuk\n- Izin atau sakit disertai surat keterangan\n- Siswa mengikuti seluruh jam pelajaran',1),
('Peraturan Sekolah','Seragam dan Penampilan','- Mengenakan seragam sesuai jadwal\n- Berpakaian rapi dan sopan\n- Menjaga kebersihan diri',2),
('Ketentuan Kedisiplinan','Sikap dan Perilaku','- Menghormati guru, staf, dan teman\n- Tidak melakukan perundungan\n- Menjaga kebersihan dan fasilitas sekolah',1),
('Ketentuan Kedisiplinan','Larangan','- Membawa atau menggunakan barang terlarang\n- Meninggalkan sekolah tanpa izin\n- Merusak fasilitas sekolah',2),
('Informasi Tata Tertib Siswa','Sanksi dan Pembinaan','Pelanggaran ditangani secara bertahap melalui teguran, pembinaan, pemanggilan orang tua, hingga tindakan sesuai ketentuan sekolah. (teks contoh - sesuaikan dengan tata tertib resmi)',1);

INSERT INTO ppdb_info (type, title, content, date_label, sort_order) VALUES
('persyaratan','Lulusan SMP/MTs atau sederajat',NULL,NULL,1),
('persyaratan','Mengisi formulir pendaftaran online',NULL,NULL,2),
('persyaratan','Menyiapkan fotokopi ijazah/SKL, kartu keluarga, dan pas foto (dibawa saat verifikasi)',NULL,NULL,3),
('jadwal','Pendaftaran gelombang 1','Jadwal contoh, sesuaikan dengan jadwal resmi panitia.','Januari - Maret 2027 (contoh)',1),
('jadwal','Pendaftaran gelombang 2','Jadwal contoh.','April - Juni 2027 (contoh)',2),
('jadwal','Verifikasi berkas dan pengumuman','Jadwal contoh.','Juni 2027 (contoh)',3),
('alur','Isi formulir online','Lengkapi data diri dan pilih program keahlian pada formulir di halaman ini.',NULL,1),
('alur','Simpan nomor pendaftaran','Nomor pendaftaran muncul setelah data berhasil disimpan.',NULL,2),
('alur','Verifikasi oleh panitia','Panitia memverifikasi data dan menghubungi pendaftar.',NULL,3),
('alur','Pengumuman hasil','Hasil seleksi diumumkan oleh panitia PPDB.',NULL,4),
('jalur','Jalur Reguler (contoh)','Pendaftaran umum bagi calon siswa. Jalur lain (prestasi, afirmasi) diisi sesuai kebijakan resmi sekolah.',NULL,1),
('faq','Apakah pendaftaran online dipungut biaya?','Informasi biaya mengikuti ketentuan resmi panitia PPDB. Silakan hubungi panitia untuk kepastian. (jawaban contoh)',NULL,1),
('faq','Bagaimana jika salah mengisi data?','Hubungi panitia PPDB dengan menyebutkan nomor pendaftaran agar data dapat diperbaiki.',NULL,2),
('faq','Bagaimana mengetahui hasil seleksi?','Panitia akan menghubungi melalui nomor telepon yang didaftarkan dan mengumumkan hasil melalui sekolah.',NULL,3);

INSERT INTO news_categories (name, slug) VALUES ('Berita Sekolah','berita-sekolah'),('Prestasi','prestasi'),('PPDB','ppdb'),('Kegiatan Siswa','kegiatan-siswa');
INSERT INTO news (category_id, title, slug, summary, content, image, status, published_at, author) VALUES
(3,'Pendaftaran PPDB Online Dibuka','pendaftaran-ppdb-online-dibuka','Calon siswa kini dapat mendaftar secara online melalui website resmi sekolah.','Panitia PPDB SMK INFOKOM BOGOR membuka pendaftaran online. Calon siswa dapat mengisi formulir pada halaman PPDB Online dan memantau informasi dari panitia.\n\nPeriksa persyaratan, jadwal, dan alur pendaftaran pada halaman PPDB. (berita contoh)','assets/images/seed/agenda.svg','published', NOW() - INTERVAL 1 DAY,'Admin'),
(1,'Website Resmi SMK INFOKOM BOGOR Diluncurkan','website-resmi-smk-infokom-bogor-diluncurkan','Website baru hadir untuk memudahkan akses informasi sekolah.','Website resmi SMK INFOKOM BOGOR kini hadir dengan informasi profil sekolah, program keahlian, PPDB online, berita, galeri, dan agenda.\n\nKonten website dikelola langsung oleh admin sekolah. (berita contoh)','assets/images/seed/berita.svg','published', NOW() - INTERVAL 3 DAY,'Admin'),
(4,'Siswa Mengikuti Kegiatan Kunjungan Industri','siswa-mengikuti-kegiatan-kunjungan-industri','Kunjungan industri memberi gambaran dunia kerja kepada siswa.','Siswa mengikuti kunjungan industri untuk mengenal budaya kerja dan teknologi terbaru. (berita contoh)','assets/images/seed/kegiatan.svg','published', NOW() - INTERVAL 6 DAY,'Admin'),
(2,'Contoh Berita Prestasi Siswa','contoh-berita-prestasi-siswa','Template berita prestasi yang dapat diganti oleh admin.','Berita ini adalah contoh. Ganti dengan prestasi siswa yang sebenarnya melalui dashboard admin.','assets/images/seed/prestasi.svg','published', NOW() - INTERVAL 9 DAY,'Admin'),
(1,'Contoh Berita Draft (tidak tampil di publik)','contoh-berita-draft','Berita ini berstatus draft sehingga tidak tampil di website.','Berita draft hanya terlihat oleh admin di dashboard.',NULL,'draft',NULL,'Admin');

INSERT INTO gallery_categories (name, slug) VALUES ('Kegiatan Sekolah','kegiatan-sekolah'),('Kegiatan Siswa','kegiatan-siswa'),('Ekstrakurikuler','ekstrakurikuler'),('Prestasi','prestasi'),('PKL','pkl'),('Fasilitas Sekolah','fasilitas-sekolah');
INSERT INTO gallery (category_id, title, caption, image) VALUES
(6,'Laboratorium Komputer','Fasilitas laboratorium (gambar contoh)','assets/images/seed/lab.svg'),
(6,'Ruang Kelas','Ruang kelas (gambar contoh)','assets/images/seed/kelas.svg'),
(6,'Perpustakaan','Perpustakaan sekolah (gambar contoh)','assets/images/seed/perpus.svg'),
(2,'Kegiatan Siswa','Kegiatan siswa (gambar contoh)','assets/images/seed/kegiatan.svg'),
(4,'Prestasi Siswa','Dokumentasi prestasi (gambar contoh)','assets/images/seed/prestasi.svg'),
(3,'Kegiatan Olahraga','Ekstrakurikuler olahraga (gambar contoh)','assets/images/seed/olahraga.svg'),
(1,'Agenda Sekolah','Dokumentasi agenda (gambar contoh)','assets/images/seed/agenda.svg'),
(5,'Dokumentasi PKL','Kegiatan PKL (gambar contoh)','assets/images/seed/kelas.svg');

INSERT INTO agenda_categories (name, slug) VALUES ('Akademik','akademik'),('Kesiswaan','kesiswaan'),('PPDB','ppdb-agenda'),('Umum','umum');
INSERT INTO agendas (category_id, title, description, event_date, end_date, start_time, end_time, location, image) VALUES
(1,'Penilaian Tengah Semester (contoh)','Pelaksanaan penilaian tengah semester.', CURDATE() + INTERVAL 7 DAY, CURDATE() + INTERVAL 11 DAY,'07:30','12:00','Ruang kelas masing-masing','assets/images/seed/agenda.svg'),
(2,'Pelantikan Pengurus OSIS (contoh)','Pelantikan pengurus OSIS periode baru.', CURDATE() + INTERVAL 14 DAY, NULL,'08:00','11:00','Lapangan sekolah','assets/images/seed/kegiatan.svg'),
(3,'Sosialisasi PPDB (contoh)','Sosialisasi program PPDB kepada calon siswa dan orang tua.', CURDATE() + INTERVAL 30 DAY, NULL,'09:00','12:00','Aula SMK INFOKOM BOGOR','assets/images/seed/agenda.svg'),
(1,'Rapat Dewan Guru (contoh)','Rapat evaluasi pembelajaran semester ganjil.', CURDATE() - INTERVAL 10 DAY, NULL,'13:00','15:00','Ruang guru',NULL);
