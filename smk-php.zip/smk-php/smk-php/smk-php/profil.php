<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/components.php';

$sections = [
    'sambutan' => 'Sambutan Kepala Sekolah', 'sejarah' => 'Sejarah Sekolah', 'identitas' => 'Identitas Sekolah',
    'visi-misi' => 'Visi dan Misi', 'struktur' => 'Struktur Organisasi', 'fasilitas' => 'Fasilitas Sekolah',
    'data' => 'Data Sekolah', 'kontak' => 'Kontak Sekolah',
];
$s = get_str('s','');
if ($s !== '' && !isset($sections[$s])) show_404();
$show = fn(string $k) => $s === '' || $s === $k;

$pageTitle = $s ? $sections[$s] : 'Profil Sekolah';
$metaDesc  = 'Profil lengkap ' . setting('school_name') . ': sambutan kepala sekolah, sejarah, visi misi, struktur organisasi, fasilitas, dan data sekolah.';
require __DIR__ . '/includes/header.php';
page_banner($s ? $sections[$s] : 'Profil Sekolah', $s ? ['Profil Sekolah' => 'profil.php'] : [], setting('school_fullname'));
echo sub_nav(['' => 'Semua'] + $sections, $s, 'profil.php');
?>
<div class="container py-5">

<?php if ($show('sambutan')):
    $g = q_one('SELECT * FROM principal_greetings WHERE is_active = 1 ORDER BY id DESC LIMIT 1'); ?>
<section id="sambutan" class="mb-5 pb-3">
    <?= section_title('Sambutan Kepala Sekolah') ?>
    <?php if ($g): ?>
    <div class="row g-5 align-items-center">
        <div class="col-md-5 col-lg-4"><div class="greet-photo"><img src="<?= e(img_url($g['photo'], 'photo')) ?>" alt="Foto <?= e($g['name']) ?>" loading="lazy"></div>
            <div class="text-center mt-4"><h3 class="greet-name h5"><?= e($g['name']) ?></h3><p class="greet-pos mb-1"><?= e($g['position']) ?></p>
            <?php if ($g['period']): ?><span class="badge bg-warning text-dark"><?= e($g['period']) ?></span><?php endif; ?></div></div>
        <div class="col-md-7 col-lg-8"><h3 class="mb-3"><?= e($g['title']) ?></h3><div class="rich quote-box"><?= format_text($g['content']) ?></div></div>
    </div>
    <?php else: echo empty_state('Sambutan kepala sekolah belum diisi.'); endif; ?>
</section>
<?php endif; ?>

<?php if ($show('sejarah')): $hist = q_all('SELECT * FROM school_history WHERE is_published = 1 ORDER BY sort_order, id'); ?>
<section id="sejarah" class="mb-5 pb-3">
    <?= section_title('Sejarah Sekolah') ?>
    <?php if (!$hist) echo empty_state('Sejarah sekolah belum diisi.'); ?>
    <div class="row justify-content-center"><div class="col-lg-9">
    <?php foreach ($hist as $h): ?>
        <div class="timeline-item rich">
            <?php if ($h['year_label']): ?><span class="badge bg-primary mb-1"><?= e($h['year_label']) ?></span><?php endif; ?>
            <h4><?= e($h['title']) ?></h4>
            <?php if ($h['image']): ?><img class="block-img" src="<?= e(img_url($h['image'])) ?>" alt="<?= e($h['title']) ?>" loading="lazy"><?php endif; ?>
            <?= format_text($h['content']) ?>
        </div>
    <?php endforeach; ?></div></div>
</section>
<?php endif; ?>

<?php if ($show('identitas')): ?>
<section id="identitas" class="mb-5 pb-3">
    <?= section_title('Identitas Sekolah') ?>
    <div class="row g-4 justify-content-center">
        <div class="col-lg-8"><div class="ppdb-card"><table class="table data-table mb-0"><tbody>
            <tr><th>Nama Sekolah</th><td><?= e(setting('school_name')) ?></td></tr>
            <tr><th>Nama Lengkap</th><td><?= e(setting('school_fullname')) ?></td></tr>
            <tr><th>NPSN</th><td><?= e(setting('npsn')) ?></td></tr>
            <tr><th>Status</th><td><?= e(setting('school_status')) ?></td></tr>
            <tr><th>Akreditasi</th><td><?= e(setting('accreditation')) ?></td></tr>
            <tr><th>Alamat</th><td><?= e(setting('address')) ?></td></tr>
            <tr><th>Telepon</th><td><?= e(setting('phone')) ?></td></tr>
            <tr><th>Email</th><td><?= e(setting('email')) ?></td></tr>
            <tr><th>Website</th><td><?= e(setting('website')) ?></td></tr>
        </tbody></table></div></div>
    </div>
</section>
<?php endif; ?>

<?php if ($show('visi-misi')): $vm = q_all("SELECT * FROM school_vision_mission WHERE is_published = 1 ORDER BY FIELD(type,'visi','misi','tujuan'), sort_order, id");
    $by = ['visi' => [], 'misi' => [], 'tujuan' => []]; foreach ($vm as $r) $by[$r['type']][] = $r['content']; ?>
<section id="visi-misi" class="mb-5 pb-3">
    <?= section_title('Visi, Misi, dan Tujuan') ?>
    <?php if ($by['visi']): ?><div class="visi-box mb-4"><div class="text-warning fw-bold mb-2"><i class="fa-solid fa-eye me-2"></i>VISI</div><?php foreach ($by['visi'] as $v) echo '<p class="mb-2">' . e($v) . '</p>'; ?></div><?php endif; ?>
    <div class="row g-4">
        <div class="col-lg-6"><div class="vm-card"><h3 class="h4"><i class="fa-solid fa-bullseye"></i>Misi</h3>
            <?php if ($by['misi']): ?><ol class="vm-list"><?php foreach ($by['misi'] as $m) echo '<li>' . e($m) . '</li>'; ?></ol><?php else: echo '<p class="text-muted">Belum diisi.</p>'; endif; ?></div></div>
        <div class="col-lg-6"><div class="vm-card"><h3 class="h4"><i class="fa-solid fa-flag-checkered"></i>Tujuan</h3>
            <?php if ($by['tujuan']): ?><ol class="vm-list"><?php foreach ($by['tujuan'] as $m) echo '<li>' . e($m) . '</li>'; ?></ol><?php else: echo '<p class="text-muted">Belum diisi.</p>'; endif; ?></div></div>
    </div>
</section>
<?php endif; ?>

<?php if ($show('struktur')): $org = q_all('SELECT * FROM school_organization WHERE is_published = 1 ORDER BY level, sort_order, id');
    $lv = []; foreach ($org as $o) $lv[$o['level']][] = $o; $chart = setting('org_chart_image'); ?>
<section id="struktur" class="mb-5 pb-3">
    <?= section_title('Struktur Organisasi') ?>
    <?php if ($chart && is_file(ROOT_PATH . '/' . $chart)): ?>
        <div class="text-center mb-4"><a href="<?= e(url($chart)) ?>" data-lightbox data-title="Bagan Struktur Organisasi"><img src="<?= e(url($chart)) ?>" class="img-fluid rounded-4 shadow" alt="Bagan struktur organisasi sekolah" loading="lazy"></a></div>
    <?php endif; ?>
    <?php if (!$lv && !$chart) echo empty_state('Struktur organisasi belum diisi.'); ?>
    <?php foreach ($lv as $level => $list): ?>
        <div class="org-level org-level-<?= (int)$level ?>">
            <?php foreach ($list as $o): ?><div class="org-box"><span class="org-pos"><?= e($o['position']) ?></span><?php if ($o['name']): ?><strong><?= e($o['name']) ?></strong><?php endif; ?><?php if ($o['description']): ?><small><?= e($o['description']) ?></small><?php endif; ?></div><?php endforeach; ?>
        </div>
    <?php endforeach; ?>
</section>
<?php endif; ?>

<?php if ($show('fasilitas')): $fac = q_all('SELECT * FROM school_facilities WHERE is_published = 1 ORDER BY sort_order, id'); ?>
<section id="fasilitas" class="mb-5 pb-3">
    <?= section_title('Fasilitas Sekolah', 'Foto lingkungan dan sarana prasarana') ?>
    <?php if (!$fac) echo empty_state('Fasilitas belum ditambahkan.'); ?>
    <div class="row g-4">
        <?php foreach ($fac as $f): ?>
        <div class="col-sm-6 col-lg-4"><a class="fac-card" href="<?= e(img_url($f['image'])) ?>" data-lightbox data-title="<?= e($f['name']) ?>" data-caption="<?= e($f['description']) ?>">
            <img src="<?= e(img_url($f['image'])) ?>" alt="<?= e($f['name']) ?>" loading="lazy"><div class="fac-cap"><h3><?= e($f['name']) ?></h3><p><?= e(excerpt($f['description'], 90)) ?></p></div></a></div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<?php if ($show('data')): ?>
<section id="data" class="mb-5 pb-3">
    <?= section_title('Data Sekolah') ?>
    <div class="row g-3 justify-content-center">
        <?php foreach ([['fa-user-graduate','stat_students','Jumlah Siswa'],['fa-chalkboard-user','stat_teachers','Jumlah Guru'],['fa-people-roof','stat_classgroups','Rombongan Belajar'],['fa-door-open','stat_classrooms','Ruang Kelas'],['fa-computer','stat_labs','Laboratorium']] as $st): ?>
            <div class="col-6 col-md-4 col-lg"><div class="contact-card"><div class="ic"><i class="fa-solid <?= $st[0] ?>"></i></div><div class="h3 mb-0 text-primary"><?= number_format((int)setting($st[1], '0'), 0, ',', '.') ?></div><small class="text-muted"><?= e($st[2]) ?></small></div></div>
        <?php endforeach; ?>
    </div>
    <?php if (setting('stat_note') !== ''): ?><p class="text-center text-muted small mt-3"><i class="fa-solid fa-circle-info"></i> <?= e(setting('stat_note')) ?></p><?php endif; ?>
</section>
<?php endif; ?>

<?php if ($show('kontak')): ?>
<section id="kontak" class="mb-2">
    <?= section_title('Kontak Sekolah') ?>
    <div class="row justify-content-center"><div class="col-lg-8"><div class="ppdb-card"><ul class="info-list">
        <li><span class="ic"><i class="fa-solid fa-location-dot"></i></span><div><span class="lb">Alamat</span><span class="vl"><?= e(setting('address')) ?></span></div></li>
        <li><span class="ic"><i class="fa-solid fa-phone"></i></span><div><span class="lb">Telepon</span><span class="vl"><?= e(setting('phone')) ?></span></div></li>
        <li><span class="ic"><i class="fa-solid fa-envelope"></i></span><div><span class="lb">Email</span><span class="vl"><?= e(setting('email')) ?></span></div></li>
        <li><span class="ic"><i class="fa-solid fa-globe"></i></span><div><span class="lb">Website</span><span class="vl"><?= e(setting('website')) ?></span></div></li>
    </ul><div class="text-center mt-2"><a class="btn btn-blue" href="<?= url('kontak.php') ?>">Kirim Pesan</a></div></div></div></div>
</section>
<?php endif; ?>

</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
