<?php
$navCur = current_script();
$navMenu = [
    ['label' => 'Beranda', 'icon' => 'fa-house', 'href' => 'index.php', 'files' => ['index.php']],
    ['label' => 'Profil Sekolah', 'icon' => 'fa-school', 'files' => ['profil.php'], 'children' => [
        ['Sambutan Kepala Sekolah', 'profil.php?s=sambutan', 'fa-user-tie'],
        ['Sejarah Sekolah', 'profil.php?s=sejarah', 'fa-landmark'],
        ['Identitas Sekolah', 'profil.php?s=identitas', 'fa-id-card'],
        ['Visi dan Misi', 'profil.php?s=visi-misi', 'fa-bullseye'],
        ['Struktur Organisasi', 'profil.php?s=struktur', 'fa-sitemap'],
        ['Fasilitas Sekolah', 'profil.php?s=fasilitas', 'fa-building'],
        ['Data Sekolah', 'profil.php?s=data', 'fa-chart-pie'],
    ]],
    ['label' => 'Akademik', 'icon' => 'fa-graduation-cap', 'files' => ['akademik.php', 'program-detail.php'], 'children' => [
        ['Program Keahlian', 'akademik.php?s=program', 'fa-laptop-code'],
        ['Kurikulum', 'akademik.php?s=kurikulum', 'fa-book-open'],
        ['Kalender Pendidikan', 'akademik.php?s=kalender', 'fa-calendar-days'],
        ['Praktik Kerja Lapangan (PKL)', 'akademik.php?s=pkl', 'fa-briefcase'],
        ['Bursa Kerja Khusus (BKK)', 'akademik.php?s=bkk', 'fa-handshake'],
        ['Program Kerja ke Luar Negeri', 'akademik.php?s=luar-negeri', 'fa-earth-asia'],
        ['Program Kerja ke Jepang', 'akademik.php?s=jepang', 'fa-torii-gate'],
    ]],
    ['label' => 'Guru dan Staff', 'icon' => 'fa-chalkboard-user', 'files' => ['guru-staff.php'], 'children' => [
        ['Pimpinan Sekolah', 'guru-staff.php#pimpinan', 'fa-user-tie'],
        ['Wakil Kepala Sekolah', 'guru-staff.php#wakasek', 'fa-user-group'],
        ['Guru', 'guru-staff.php#guru', 'fa-chalkboard-user'],
        ['Staff Usaha', 'guru-staff.php#staff-usaha', 'fa-folder-open'],
        ['Staff Kurikulum', 'guru-staff.php#staff-kurikulum', 'fa-book-bookmark'],
    ]],
    ['label' => 'Kesiswaan', 'icon' => 'fa-users', 'files' => ['kesiswaan.php'], 'children' => [
        ['Beranda Kesiswaan', 'kesiswaan.php?s=beranda', 'fa-house-user'],
        ['OSIS', 'kesiswaan.php?s=osis', 'fa-people-group'],
        ['Ekstrakurikuler', 'kesiswaan.php?s=ekskul', 'fa-futbol'],
        ['Prestasi Siswa', 'kesiswaan.php?s=prestasi', 'fa-trophy'],
        ['Kegiatan Siswa', 'kesiswaan.php?s=kegiatan', 'fa-camera-retro'],
        ['Tata Tertib', 'kesiswaan.php?s=tata-tertib', 'fa-scale-balanced'],
    ]],
];
$navSimple = [
    ['Berita', 'berita.php', 'fa-newspaper', ['berita.php', 'detail-berita.php']],
    ['Galeri', 'galeri.php', 'fa-images', ['galeri.php']],
    ['Agenda', 'agenda.php', 'fa-calendar-check', ['agenda.php', 'agenda-detail.php']],
    ['Kontak', 'kontak.php', 'fa-envelope', ['kontak.php']],
];
?>
<header class="site-header" id="siteHeader">
    <div class="topbar d-none d-lg-block">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex gap-4">
                <span><i class="fa-solid fa-phone"></i> <?= e(setting('phone')) ?></span>
                <span><i class="fa-solid fa-envelope"></i> <?= e(setting('email')) ?></span>
            </div>
            <span><i class="fa-solid fa-location-dot"></i> Kota Bogor, Jawa Barat</span>
        </div>
    </div>
    <nav class="navbar navbar-expand-xl main-nav" aria-label="Navigasi utama">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2" href="<?= url('index.php') ?>">
                <img src="<?= e(logo_url()) ?>" alt="Logo <?= e(setting('school_name')) ?>" width="48" height="48">
                <span class="brand-text"><strong><?= e(setting('school_name', 'SMK INFOKOM BOGOR')) ?></strong><small><?= e(setting('school_fullname')) ?></small></span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainMenu" aria-controls="mainMenu" aria-expanded="false" aria-label="Buka menu">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="mainMenu">
                <ul class="navbar-nav ms-auto align-items-xl-center">
                    <?php foreach ($navMenu as $nm):
                        $active = in_array($navCur, $nm['files'], true); ?>
                        <?php if (empty($nm['children'])): ?>
                            <li class="nav-item"><a class="nav-link <?= $active ? 'active' : '' ?>" href="<?= url($nm['href']) ?>"><?= e($nm['label']) ?></a></li>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle <?= $active ? 'active' : '' ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><?= e($nm['label']) ?></a>
                                <ul class="dropdown-menu nav-dropdown">
                                    <?php foreach ($nm['children'] as $nc): ?>
                                        <li><a class="dropdown-item" href="<?= url($nc[1]) ?>"><i class="fa-solid <?= e($nc[2]) ?>"></i><?= e($nc[0]) ?></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    <li class="nav-item ms-xl-1"><a class="nav-link nav-ppdb-mobile d-xl-none <?= $navCur === 'ppdb.php' ? 'active' : '' ?>" href="<?= url('ppdb.php') ?>">PPDB ONLINE</a></li>
                    <?php foreach ($navSimple as $nsi): ?>
                        <li class="nav-item"><a class="nav-link <?= in_array($navCur, $nsi[3], true) ? 'active' : '' ?>" href="<?= url($nsi[1]) ?>"><?= e($nsi[0]) ?></a></li>
                    <?php endforeach; ?>
                    <li class="nav-item d-none d-xl-block ms-xl-2">
                        <a class="btn btn-ppdb" href="<?= url('ppdb.php') ?>"><i class="fa-solid fa-user-plus"></i> PPDB ONLINE</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
