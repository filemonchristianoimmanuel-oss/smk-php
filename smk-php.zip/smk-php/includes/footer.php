</main>
<?php $footSocials = q_all('SELECT * FROM social_links WHERE is_active = 1 ORDER BY sort_order, id'); ?>
<footer class="site-footer">
    <div class="container">
        <div class="row g-4 py-5">
            <div class="col-lg-4">
                <a class="d-flex align-items-center gap-3 mb-3 text-decoration-none" href="<?= url('index.php') ?>">
                    <img src="<?= e(logo_url()) ?>" alt="Logo <?= e(setting('school_name')) ?>" width="64" height="64">
                    <span class="text-white fw-bold fs-5"><?= e(setting('school_name')) ?></span>
                </a>
                <p class="footer-about"><?= e(setting('footer_about')) ?></p>
                <?php if ($footSocials): ?>
                <div class="d-flex gap-2 mt-3">
                    <?php foreach ($footSocials as $fs): ?>
                        <a class="social-btn" href="<?= e($fs['url']) ?>" target="_blank" rel="noopener noreferrer" aria-label="<?= e($fs['platform']) ?>" title="<?= e($fs['platform']) ?>"><i class="<?= e($fs['icon']) ?>"></i></a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-6 col-lg-2">
                <h2 class="footer-title">Tautan Penting</h2>
                <ul class="footer-links">
                    <li><a href="<?= url('profil.php') ?>">Profil Sekolah</a></li>
                    <li><a href="<?= url('akademik.php?s=program') ?>">Program Keahlian</a></li>
                    <li><a href="<?= url('guru-staff.php') ?>">Guru dan Staff</a></li>
                    <li><a href="<?= url('kesiswaan.php') ?>">Kesiswaan</a></li>
                    <li><a href="<?= url('ppdb.php') ?>">PPDB Online</a></li>
                </ul>
            </div>
            <div class="col-6 col-lg-2">
                <h2 class="footer-title">Informasi</h2>
                <ul class="footer-links">
                    <li><a href="<?= url('berita.php') ?>">Berita</a></li>
                    <li><a href="<?= url('galeri.php') ?>">Galeri</a></li>
                    <li><a href="<?= url('agenda.php') ?>">Agenda</a></li>
                    <li><a href="<?= url('akademik.php?s=bkk') ?>">BKK</a></li>
                    <li><a href="<?= url('kontak.php') ?>">Kontak</a></li>
                </ul>
            </div>
            <div class="col-lg-4">
                <h2 class="footer-title">Hubungi Kami</h2>
                <ul class="footer-contact">
                    <li><i class="fa-solid fa-location-dot"></i><span><?= e(setting('address')) ?></span></li>
                    <li><i class="fa-solid fa-phone"></i><a href="tel:<?= e(preg_replace('/[^0-9+]/', '', setting('phone'))) ?>"><?= e(setting('phone')) ?></a></li>
                    <li><i class="fa-solid fa-envelope"></i><a href="mailto:<?= e(setting('email')) ?>"><?= e(setting('email')) ?></a></li>
                    <li><i class="fa-solid fa-globe"></i><span><?= e(setting('website')) ?></span></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <span>&copy; <?= date('Y') ?> <?= e(setting('footer_copyright')) ?></span>
            <a href="<?= admin_url('login.php') ?>" class="footer-admin"><i class="fa-solid fa-lock"></i> Login Admin</a>
        </div>
    </div>
</footer>
<button class="to-top" id="toTop" type="button" aria-label="Kembali ke atas"><i class="fa-solid fa-chevron-up"></i></button>
<script src="<?= asset('vendor/bootstrap/bootstrap.bundle.min.js') ?>"></script>
<script src="<?= asset('js/script.js') ?>?v=3"></script>
<?= $extraScripts ?? '' ?>
</body>
</html>
