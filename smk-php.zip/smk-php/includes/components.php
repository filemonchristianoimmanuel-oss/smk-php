<?php
/** Komponen tampilan yang dipakai ulang di banyak halaman. */
function page_banner(string $title, array $crumbs = [], string $subtitle = ''): void
{ ?>
<section class="page-banner">
    <div class="container">
        <h1><?= e($title) ?></h1>
        <?php if ($subtitle): ?><p class="lead"><?= e($subtitle) ?></p><?php endif; ?>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= url('index.php') ?>">Beranda</a></li>
                <?php foreach ($crumbs as $label => $href): ?>
                    <li class="breadcrumb-item"><a href="<?= url($href) ?>"><?= e($label) ?></a></li>
                <?php endforeach; ?>
                <li class="breadcrumb-item active" aria-current="page"><?= e($title) ?></li>
            </ol>
        </nav>
    </div>
</section>
<?php }

function section_title(string $title, string $sub = '', bool $center = true): string
{
    return '<div class="section-title ' . ($center ? 'text-center' : '') . '"><h2>' . e($title) . '</h2>'
        . ($sub !== '' ? '<p>' . e($sub) . '</p>' : '') . '<span class="title-bar"></span></div>';
}

function empty_state(string $text = 'Belum ada data yang ditampilkan.'): string
{
    return '<div class="empty-state"><i class="fa-regular fa-folder-open"></i><p>' . e($text) . '</p></div>';
}

function staff_card(array $s, bool $large = false): string
{
    $h = '<article class="staff-card ' . ($large ? 'staff-card-lg' : '') . '"><div class="staff-photo"><img src="' . e(img_url($s['photo'], 'photo')) . '" alt="Foto ' . e($s['name']) . '" loading="lazy"></div>'
       . '<div class="staff-body"><h3>' . e($s['name']) . '</h3>';
    if (!empty($s['position'])) $h .= '<p class="staff-pos">' . e($s['position']) . '</p>';
    if (!empty($s['subject']))  $h .= '<p class="staff-sub"><i class="fa-solid fa-book"></i> ' . e($s['subject']) . '</p>';
    if (!empty($s['description'])) $h .= '<p class="staff-desc">' . e($s['description']) . '</p>';
    return $h . '</div></article>';
}

function news_card(array $n): string
{
    $link = url('detail-berita.php?slug=' . urlencode($n['slug']));
    return '<article class="card-x news-card h-100"><a class="card-img-wrap" href="' . e($link) . '"><img src="' . e(img_url($n['image'])) . '" alt="' . e($n['title']) . '" loading="lazy">'
        . ($n['category_name'] ? '<span class="cat-badge">' . e($n['category_name']) . '</span>' : '') . '</a>'
        . '<div class="card-body-x"><div class="meta"><i class="fa-regular fa-calendar"></i> ' . e(tgl_indo($n['published_at'])) . '</div>'
        . '<h3><a href="' . e($link) . '">' . e($n['title']) . '</a></h3><p>' . e(excerpt($n['summary'] ?: $n['content'], 110)) . '</p>'
        . '<a class="read-more" href="' . e($link) . '">Baca Selengkapnya <i class="fa-solid fa-arrow-right"></i></a></div></article>';
}

function published_news_sql(): string
{
    return "n.status = 'published' AND n.published_at IS NOT NULL AND n.published_at <= NOW()";
}

function agenda_date_label(array $a): string
{
    $s = tgl_indo($a['event_date']);
    if (!empty($a['end_date']) && $a['end_date'] !== $a['event_date']) $s .= ' - ' . tgl_indo($a['end_date']);
    return $s;
}
function agenda_time_label(array $a): string
{
    if (empty($a['start_time'])) return 'Sepanjang hari';
    $s = substr($a['start_time'], 0, 5);
    if (!empty($a['end_time'])) $s .= ' - ' . substr($a['end_time'], 0, 5);
    return $s . ' WIB';
}
function agenda_card(array $a): string
{
    $ts = strtotime($a['event_date']);
    return '<article class="agenda-card h-100"><div class="agenda-date"><span class="d">' . date('d', $ts) . '</span><span class="m">' . e(mb_substr(bulan_id((int)date('n', $ts)), 0, 3)) . '</span><span class="y">' . date('Y', $ts) . '</span></div>'
        . '<div class="agenda-info"><h3><a href="' . e(url('agenda-detail.php?id=' . (int)$a['id'])) . '">' . e($a['title']) . '</a></h3>'
        . '<ul><li><i class="fa-regular fa-clock"></i> ' . e(agenda_time_label($a)) . '</li>'
        . ($a['location'] ? '<li><i class="fa-solid fa-location-dot"></i> ' . e($a['location']) . '</li>' : '')
        . '</ul><p>' . e(excerpt($a['description'], 90)) . '</p></div></article>';
}

/** Render blok konten per "section" (dipakai PKL, BKK, program luar negeri). */
function render_blocks(array $rows, array $sections, string $field = 'section'): void
{
    $any = false;
    foreach ($sections as $key => $cfg) {
        $items = array_values(array_filter($rows, fn($r) => $r[$field] === $key));
        if (!$items) continue;
        $any = true;
        $style = $cfg['style'] ?? 'text';
        echo '<section class="block-section" id="' . e($key) . '"><h3 class="block-title"><i class="fa-solid ' . e($cfg['icon'] ?? 'fa-circle-info') . '"></i> ' . e($cfg['label']) . '</h3>';
        if ($style === 'steps') {
            echo '<ol class="steps">';
            foreach ($items as $i) echo '<li><div><h4>' . e($i['title']) . '</h4>' . format_text($i['content'] ?? '') . '</div></li>';
            echo '</ol>';
        } elseif ($style === 'cards' || $style === 'gallery') {
            echo '<div class="row g-4">';
            foreach ($items as $i) {
                echo '<div class="col-md-6 col-lg-4"><div class="card-x h-100">';
                if (!empty($i['image'])) echo '<div class="card-img-wrap"><img src="' . e(img_url($i['image'])) . '" alt="' . e($i['title']) . '" loading="lazy"></div>';
                echo '<div class="card-body-x"><h4 class="h6 fw-bold">' . e($i['title']) . '</h4>';
                if (!empty($i['company'])) echo '<p class="meta mb-1"><i class="fa-solid fa-building"></i> ' . e($i['company']) . '</p>';
                if (!empty($i['deadline'])) echo '<p class="meta mb-1"><i class="fa-regular fa-calendar-xmark"></i> Batas: ' . e(tgl_indo($i['deadline'])) . '</p>';
                echo format_text($i['content'] ?? '') . '</div></div></div>';
            }
            echo '</div>';
        } else {
            foreach ($items as $i) {
                echo '<div class="content-block">';
                if (!empty($i['image'])) echo '<img class="block-img" src="' . e(img_url($i['image'])) . '" alt="' . e($i['title']) . '" loading="lazy">';
                echo '<h4>' . e($i['title']) . '</h4>';
                if (!empty($i['company'])) echo '<p class="meta"><i class="fa-solid fa-building"></i> ' . e($i['company']) . '</p>';
                echo format_text($i['content'] ?? '') . '</div>';
            }
        }
        echo '</section>';
    }
    if (!$any) echo empty_state('Informasi belum tersedia. Silakan kembali lagi nanti.');
}

function sub_nav(array $items, string $current, string $base): string
{
    $h = '<div class="sub-nav"><div class="container"><ul class="nav nav-pills">';
    foreach ($items as $k => $label) {
        $h .= '<li class="nav-item"><a class="nav-link ' . ($k === $current ? 'active' : '') . '" href="' . e(url($base . '?s=' . $k)) . '">' . e($label) . '</a></li>';
    }
    return $h . '</ul></div></div>';
}
