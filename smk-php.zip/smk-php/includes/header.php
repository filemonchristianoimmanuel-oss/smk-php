<?php
/** Kepala HTML publik. Variabel opsional: $pageTitle, $metaDesc, $metaImage, $bodyClass */
require_once __DIR__ . '/functions.php';
$siteName  = setting('school_name', 'SMK INFOKOM BOGOR');
$fullTitle = isset($pageTitle) && $pageTitle !== '' ? $pageTitle . ' | ' . $siteName : $siteName . ' - ' . setting('school_fullname', 'SMK Informatika Kota Bogor');
$desc      = isset($metaDesc) && $metaDesc !== '' ? $metaDesc : setting('meta_description');
?>
<!DOCTYPE html>
<html lang="id" class="no-js">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($fullTitle) ?></title>
    <meta name="description" content="<?= e(excerpt($desc, 160)) ?>">
    <meta name="keywords" content="<?= e(setting('meta_keywords')) ?>">
    <meta name="theme-color" content="#1717E8">
    <meta property="og:title" content="<?= e($fullTitle) ?>">
    <meta property="og:description" content="<?= e(excerpt($desc, 160)) ?>">
    <meta property="og:type" content="website">
    <meta property="og:image" content="<?= e(isset($metaImage) ? $metaImage : logo_url()) ?>">
    <link rel="icon" href="<?= e(favicon_url()) ?>">
    <link rel="stylesheet" href="<?= asset('vendor/bootstrap/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="<?= asset('vendor/fontawesome/css/all.min.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>?v=3">
</head>
<body class="<?= e($bodyClass ?? '') ?>">
<a class="visually-hidden-focusable skip-link" href="#konten">Lewati ke konten utama</a>
<?php require __DIR__ . '/navbar.php'; ?>
<main id="konten">
