<?php
/**
 * Autentikasi admin: session, throttle login, dan proteksi halaman.
 */
require_once __DIR__ . '/functions.php';

const LOGIN_MAX_ATTEMPTS = 5;     // percobaan gagal
const LOGIN_WINDOW_MIN   = 15;    // dalam menit
const SESSION_IDLE_SEC   = 7200;  // 2 jam tidak aktif -> logout otomatis

function admin_fingerprint(): string
{
    return hash('sha256', ($_SERVER['HTTP_USER_AGENT'] ?? '') . '|smkinfokom');
}
function admin_logged_in(): bool
{
    if (empty($_SESSION['admin_id']) || empty($_SESSION['admin_fp'])) return false;
    if (!hash_equals($_SESSION['admin_fp'], admin_fingerprint())) return false;
    if (isset($_SESSION['admin_last']) && (time() - $_SESSION['admin_last']) > SESSION_IDLE_SEC) return false;
    return true;
}
/** Wajib dipanggil di setiap halaman admin (selain login). */
function require_admin(): void
{
    if (!admin_logged_in()) {
        $reason = !empty($_SESSION['admin_id']) ? 'expired' : '';
        admin_session_destroy();
        session_start();
        if ($reason) flash('warning', 'Sesi Anda berakhir. Silakan login kembali.');
        redirect(admin_url('login.php'));
    }
    // pastikan akun masih ada di database
    $adm = q_one('SELECT id, username, full_name, email, is_active FROM admins WHERE id = ?', [$_SESSION['admin_id']]);
    if (!$adm || !(int)$adm['is_active']) {
        admin_session_destroy();
        session_start();
        redirect(admin_url('login.php'));
    }
    $_SESSION['admin_last'] = time();
    $_SESSION['admin_name'] = $adm['full_name'];
    $GLOBALS['CURRENT_ADMIN'] = $adm;
    header('Cache-Control: no-store, no-cache, must-revalidate');
}
function admin_session_destroy(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', $p['secure'], $p['httponly']);
    }
    if (session_status() === PHP_SESSION_ACTIVE) session_destroy();
}
function login_attempts_count(): int
{
    return (int)q_val('SELECT COUNT(*) FROM login_attempts WHERE ip_address = ? AND attempted_at > (NOW() - INTERVAL ' . LOGIN_WINDOW_MIN . ' MINUTE)', [client_ip()]);
}
function login_is_blocked(string $username): bool
{
    return login_attempts_count() >= LOGIN_MAX_ATTEMPTS;
}
function login_record_failure(string $username): void
{
    q_exec('INSERT INTO login_attempts (ip_address, username) VALUES (?,?)', [client_ip(), mb_substr($username, 0, 100)]);
}
function login_clear_attempts(): void
{
    q_exec('DELETE FROM login_attempts WHERE ip_address = ?', [client_ip()]);
    q_exec('DELETE FROM login_attempts WHERE attempted_at < (NOW() - INTERVAL 1 DAY)');
}
/** Coba login. Mengembalikan null jika sukses, atau pesan error. */
function admin_attempt_login(string $identity, string $password): ?string
{
    $identity = trim($identity);
    if ($identity === '' || $password === '') return 'Username/email dan password wajib diisi.';
    if (login_is_blocked($identity)) {
        return 'Terlalu banyak percobaan login gagal. Coba lagi dalam ' . LOGIN_WINDOW_MIN . ' menit.';
    }
    $adm = q_one('SELECT * FROM admins WHERE (username = ? OR email = ?) LIMIT 1', [$identity, $identity]);
    // verifikasi tetap dijalankan agar waktu respons relatif sama
    $hash = $adm['password_hash'] ?? password_hash('dummy-password', PASSWORD_DEFAULT);
    $ok = password_verify($password, $hash) && $adm && (int)$adm['is_active'] === 1;
    if (!$ok) {
        login_record_failure($identity);
        return 'Username/email atau password salah.';
    }
    login_clear_attempts();
    session_regenerate_id(true);
    $_SESSION['admin_id']   = (int)$adm['id'];
    $_SESSION['admin_name'] = $adm['full_name'];
    $_SESSION['admin_fp']   = admin_fingerprint();
    $_SESSION['admin_last'] = time();
    unset($_SESSION['csrf']);
    if (password_needs_rehash($adm['password_hash'], PASSWORD_DEFAULT)) {
        q_exec('UPDATE admins SET password_hash = ? WHERE id = ?', [password_hash($password, PASSWORD_DEFAULT), $adm['id']]);
    }
    q_exec('UPDATE admins SET last_login = NOW() WHERE id = ?', [$adm['id']]);
    log_activity('Login', 'Admin masuk ke dashboard');
    return null;
}
function password_strength_error(string $pw): ?string
{
    if (mb_strlen($pw) < 8) return 'Password minimal 8 karakter.';
    if (!preg_match('/[A-Za-z]/', $pw) || !preg_match('/\d/', $pw)) return 'Password harus mengandung huruf dan angka.';
    return null;
}
