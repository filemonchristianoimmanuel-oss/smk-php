<?php
/**
 * Fungsi-fungsi inti yang dipakai di seluruh website (frontend dan admin).
 */
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(__DIR__));
}
require_once ROOT_PATH . '/config/database.php';

mb_internal_encoding('UTF-8');
date_default_timezone_set('Asia/Jakarta');

if (APP_DEBUG) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL);
    ini_set('log_errors', '1');
}

if (session_status() === PHP_SESSION_NONE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0, 'path' => '/', 'secure' => $secure,
        'httponly' => true, 'samesite' => 'Lax',
    ]);
    session_name('SMKINFOKOMSESS');
    session_start();
}

if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}

/* ---------- Alamat dasar (otomatis, aman untuk subfolder htdocs) ---------- */
function base_path(): string
{
    static $base = null;
    if ($base !== null) return $base;
    if (BASE_PATH_OVERRIDE !== '') return $base = rtrim(BASE_PATH_OVERRIDE, '/');
    $doc  = isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : false;
    $root = realpath(ROOT_PATH);
    if ($doc && $root && strpos(str_replace('\\', '/', $root), str_replace('\\', '/', $doc)) === 0) {
        $base = substr(str_replace('\\', '/', $root), strlen(str_replace('\\', '/', $doc)));
    } else {
        $base = '';
    }
    return $base = rtrim($base, '/');
}
function url(string $path = ''): string
{
    return base_path() . '/' . ltrim($path, '/');
}
function admin_url(string $path = ''): string
{
    return url('admin/' . ltrim($path, '/'));
}
function redirect(string $to): void
{
    header('Location: ' . $to);
    exit;
}

/* ---------- Database (PDO) ---------- */
function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    try {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        $pdo->exec("SET time_zone = '+07:00'");
    } catch (Throwable $e) {
        error_log('DB connection error: ' . $e->getMessage());
        show_error_page(500, 'Koneksi database gagal',
            'Website belum dapat terhubung ke database. Periksa pengaturan di config/database.php dan pastikan MySQL sudah berjalan.',
            APP_DEBUG ? $e->getMessage() : '');
    }
    return $pdo;
}
function q_all(string $sql, array $params = []): array
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}
function q_one(string $sql, array $params = [])
{
    $st = db()->prepare($sql);
    $st->execute($params);
    $r = $st->fetch();
    return $r === false ? null : $r;
}
function q_val(string $sql, array $params = [])
{
    $st = db()->prepare($sql);
    $st->execute($params);
    $v = $st->fetchColumn();
    return $v === false ? null : $v;
}
function q_exec(string $sql, array $params = []): int
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->rowCount();
}

/* ---------- Halaman error ---------- */
function show_error_page(int $code, string $title, string $message, string $detail = ''): void
{
    if (!headers_sent()) http_response_code($code);
    echo '<!DOCTYPE html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<title>' . htmlspecialchars($title) . '</title><style>body{font-family:system-ui,Arial,sans-serif;background:#f4f6ff;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0;padding:20px}'
       . '.b{background:#fff;border-top:6px solid #FFD700;border-radius:14px;padding:36px;max-width:520px;box-shadow:0 10px 40px rgba(23,23,232,.15);text-align:center}'
       . 'h1{color:#1717E8;margin:0 0 10px;font-size:1.5rem}p{color:#444;line-height:1.6}a{display:inline-block;margin-top:14px;background:#1717E8;color:#fff;padding:10px 22px;border-radius:30px;text-decoration:none}'
       . 'code{display:block;margin-top:12px;font-size:.8rem;color:#a00;word-break:break-all}</style></head><body><div class="b"><h1>'
       . htmlspecialchars($title) . '</h1><p>' . htmlspecialchars($message) . '</p>'
       . ($detail !== '' ? '<code>' . htmlspecialchars($detail) . '</code>' : '')
       . '<a href="' . htmlspecialchars(url('index.php')) . '">Kembali ke Beranda</a></div></body></html>';
    exit;
}
function show_404(): void
{
    show_error_page(404, 'Halaman tidak ditemukan', 'Halaman yang Anda cari tidak tersedia atau sudah dipindahkan.');
}

/** Ambil parameter GET sebagai string aman (menolak array agar tidak memicu error). */
function get_str(string $key, string $default = ''): string
{
    return (isset($_GET[$key]) && is_string($_GET[$key])) ? trim($_GET[$key]) : $default;
}
function post_str(string $key, string $default = ''): string
{
    return (isset($_POST[$key]) && is_string($_POST[$key])) ? trim($_POST[$key]) : $default;
}

/* ---------- Escape & format teks ---------- */
function e($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
/** Ubah teks biasa dari admin menjadi HTML aman: paragraf, baris baru, dan daftar ("- item"). */
function format_text(?string $text): string
{
    $text = trim(str_replace("\r", '', (string)$text));
    if ($text === '') return '';
    $out = '';
    foreach (preg_split("/\n{2,}/", $text) as $block) {
        $lines = explode("\n", trim($block));
        $isList = true;
        foreach ($lines as $l) { if (!preg_match('/^\s*[-*•]\s+/u', $l)) { $isList = false; break; } }
        if ($isList) {
            $out .= '<ul class="rich-list">';
            foreach ($lines as $l) $out .= '<li>' . e(preg_replace('/^\s*[-*•]\s+/u', '', $l)) . '</li>';
            $out .= '</ul>';
        } else {
            $out .= '<p>' . nl2br(e(trim($block))) . '</p>';
        }
    }
    return $out;
}
function excerpt(?string $text, int $len = 140): string
{
    $t = trim(preg_replace('/\s+/u', ' ', strip_tags((string)$text)));
    if (mb_strlen($t) <= $len) return $t;
    return rtrim(mb_substr($t, 0, $len)) . '…';
}
function slugify(string $text): string
{
    $text = mb_strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/u', '-', $text);
    $text = trim($text, '-');
    return $text !== '' ? mb_substr($text, 0, 120) : 'item';
}
function unique_slug(string $table, string $base, ?int $ignoreId = null, string $col = 'slug'): string
{
    $slug = slugify($base);
    $try = $slug; $i = 2;
    while (true) {
        $sql = "SELECT COUNT(*) FROM `$table` WHERE `$col` = ?" . ($ignoreId ? ' AND id <> ' . (int)$ignoreId : '');
        if ((int)q_val($sql, [$try]) === 0) return $try;
        $try = $slug . '-' . $i++;
    }
}

/* ---------- Tanggal Indonesia ---------- */
function bulan_id(int $m): string
{
    return ['', 'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'][$m] ?? '';
}
function tgl_indo(?string $date, bool $withTime = false): string
{
    if (!$date || strpos($date, '0000-00-00') === 0) return '-';
    $ts = strtotime($date);
    if (!$ts) return '-';
    $s = date('j', $ts) . ' ' . bulan_id((int)date('n', $ts)) . ' ' . date('Y', $ts);
    return $withTime ? $s . ', ' . date('H.i', $ts) . ' WIB' : $s;
}
function hari_id(string $date): string
{
    return ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'][(int)date('w', strtotime($date))];
}

/* ---------- Pengaturan website (satu sumber data: tabel website_settings) ---------- */
function all_settings(): array
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (q_all('SELECT setting_key, setting_value FROM website_settings') as $r) {
            $cache[$r['setting_key']] = (string)$r['setting_value'];
        }
    }
    return $cache;
}
function setting(string $key, string $default = ''): string
{
    $s = all_settings();
    return (isset($s[$key]) && $s[$key] !== '') ? $s[$key] : $default;
}
function save_setting(string $key, string $value, string $group = 'umum'): void
{
    q_exec('INSERT INTO website_settings (setting_key, setting_value, setting_group) VALUES (?,?,?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)', [$key, $value, $group]);
}

/* ---------- Gambar & upload ---------- */
function asset(string $path): string
{
    return url('assets/' . ltrim($path, '/'));
}
/** URL gambar dari path tersimpan di database. Jika kosong/hilang, pakai placeholder. */
function img_url(?string $path, string $placeholder = 'landscape'): string
{
    if ($path && is_file(ROOT_PATH . '/' . ltrim($path, '/'))) {
        return url($path);
    }
    return asset('images/placeholder-' . $placeholder . '.svg');
}
function logo_url(): string
{
    $p = setting('logo');
    if ($p && is_file(ROOT_PATH . '/' . ltrim($p, '/'))) {
        return url($p);
    }
    foreach (['logo.png', 'logo.jpg', 'logo.jpeg', 'logo.webp', 'logo.svg'] as $f) {
        if (is_file(ROOT_PATH . '/assets/images/' . $f)) {
            return asset('images/' . $f);
        }
    }
    return asset('images/logo.svg');
}
function favicon_url(): string
{
    $p = setting('favicon');
    if ($p && is_file(ROOT_PATH . '/' . ltrim($p, '/'))) {
        return url($p);
    }
    foreach (['favicon.ico', 'favicon.png', 'favicon.jpg', 'favicon.jpeg', 'favicon.webp', 'favicon.svg'] as $f) {
        if (is_file(ROOT_PATH . '/assets/images/' . $f)) {
            return asset('images/' . $f);
        }
    }
    return asset('images/favicon.svg');
}

const UPLOAD_MAX_BYTES = 3145728; // 3 MB
/**
 * Unggah gambar dengan validasi ukuran, ekstensi, MIME, dan isi gambar.
 * @return array [path|null, errorMessage|null] ; path relatif dari root project.
 */
function upload_image(array $file, string $subdir, array $extra = []): array
{
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) return [null, null];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $msg = in_array($file['error'], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)
            ? 'Ukuran file melebihi batas server.' : 'Unggah file gagal (kode ' . (int)$file['error'] . ').';
        return [null, $msg];
    }
    if ($file['size'] > UPLOAD_MAX_BYTES) return [null, 'Ukuran gambar maksimal 3 MB.'];
    if (!is_uploaded_file($file['tmp_name'])) return [null, 'File unggahan tidak valid.'];

    $allowed = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif'];
    if (!empty($extra['ico'])) { $allowed['ico'] = 'image/x-icon'; }
    $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
    if (!isset($allowed[$ext])) return [null, 'Format file harus JPG, PNG, WEBP, atau GIF' . (!empty($extra['ico']) ? ' (ICO diperbolehkan untuk favicon)' : '') . '.'];

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']);
    $okMimes = [$allowed[$ext]];
    if ($ext === 'ico') $okMimes = ['image/x-icon', 'image/vnd.microsoft.icon'];
    if (!in_array($mime, $okMimes, true)) return [null, 'Isi file tidak sesuai dengan format gambar.'];
    if ($ext !== 'ico' && @getimagesize($file['tmp_name']) === false) return [null, 'File bukan gambar yang valid.'];

    $subdir = preg_replace('/[^a-z0-9_-]/i', '', $subdir) ?: 'general';
    $dir = ROOT_PATH . '/assets/uploads/' . $subdir;
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) return [null, 'Folder upload tidak dapat dibuat. Periksa izin folder assets/uploads.'];
    if (!is_writable($dir)) return [null, 'Folder upload tidak dapat ditulis. Periksa izin folder assets/uploads.'];

    $name = date('Ymd') . '_' . bin2hex(random_bytes(8)) . '.' . ($ext === 'jpeg' ? 'jpg' : $ext);
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) return [null, 'Gagal menyimpan file ke server.'];
    return ['assets/uploads/' . $subdir . '/' . $name, null];
}
/** Hapus file hasil unggahan (hanya di dalam assets/uploads, aman dari path traversal). */
function delete_upload(?string $path): void
{
    if (!$path) return;
    $path = str_replace('\\', '/', $path);
    if (strpos($path, 'assets/uploads/') !== 0 || strpos($path, '..') !== false) return;
    $full = ROOT_PATH . '/' . $path;
    if (is_file($full) && basename($full) !== 'index.html') @unlink($full);
}

/* ---------- CSRF ---------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}
function csrf_valid(): bool
{
    $t = $_POST['csrf_token'] ?? '';
    return is_string($t) && !empty($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $t);
}
function require_csrf(string $backTo = ''): void
{
    if (!csrf_valid()) {
        flash('danger', 'Sesi formulir tidak valid atau sudah kedaluwarsa. Silakan coba lagi.');
        redirect($backTo !== '' ? $backTo : ($_SERVER['HTTP_REFERER'] ?? url('index.php')));
    }
}

/* ---------- Flash message ---------- */
function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $message];
}
function flash_render(): string
{
    if (empty($_SESSION['flash'])) return '';
    $html = '';
    foreach ($_SESSION['flash'] as $f) {
        $icon = ['success' => 'fa-circle-check', 'danger' => 'fa-circle-exclamation', 'warning' => 'fa-triangle-exclamation', 'info' => 'fa-circle-info'][$f['type']] ?? 'fa-circle-info';
        $html .= '<div class="alert alert-' . e($f['type']) . ' alert-dismissible fade show d-flex align-items-start gap-2" role="alert"><i class="fa-solid ' . $icon . ' mt-1"></i><div>'
              . e($f['msg']) . '</div><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button></div>';
    }
    unset($_SESSION['flash']);
    return $html;
}

/* ---------- Pagination ---------- */
function paginate(int $total, int $perPage, int $page): array
{
    $pages = max(1, (int)ceil($total / $perPage));
    $page  = min(max(1, $page), $pages);
    return ['page' => $page, 'pages' => $pages, 'offset' => ($page - 1) * $perPage, 'per' => $perPage, 'total' => $total];
}
function page_url(int $page, array $keep = []): string
{
    $q = array_filter($keep, fn($v) => $v !== '' && $v !== null);
    $q['page'] = $page;
    return '?' . http_build_query($q);
}
function pagination_html(array $p, array $keep = []): string
{
    if ($p['pages'] <= 1) return '';
    $h = '<nav aria-label="Navigasi halaman"><ul class="pagination justify-content-center flex-wrap">';
    $cur = $p['page']; $last = $p['pages'];
    $h .= '<li class="page-item ' . ($cur <= 1 ? 'disabled' : '') . '"><a class="page-link" href="' . e(page_url($cur - 1, $keep)) . '" aria-label="Sebelumnya">&laquo;</a></li>';
    for ($i = 1; $i <= $last; $i++) {
        if ($i === 1 || $i === $last || abs($i - $cur) <= 2) {
            $h .= '<li class="page-item ' . ($i === $cur ? 'active' : '') . '"><a class="page-link" href="' . e(page_url($i, $keep)) . '">' . $i . '</a></li>';
        } elseif (abs($i - $cur) === 3) {
            $h .= '<li class="page-item disabled"><span class="page-link">…</span></li>';
        }
    }
    $h .= '<li class="page-item ' . ($cur >= $last ? 'disabled' : '') . '"><a class="page-link" href="' . e(page_url($cur + 1, $keep)) . '" aria-label="Berikutnya">&raquo;</a></li></ul></nav>';
    return $h;
}

/* ---------- Pembatasan laju (anti-spam sederhana berbasis session) ---------- */
function rate_limited(string $key, int $maxHits, int $seconds): bool
{
    $now = time();
    $_SESSION['rl'][$key] = array_filter($_SESSION['rl'][$key] ?? [], fn($t) => $t > $now - $seconds);
    if (count($_SESSION['rl'][$key]) >= $maxHits) return true;
    $_SESSION['rl'][$key][] = $now;
    return false;
}
function client_ip(): string
{
    return substr((string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45);
}

/* ---------- Log aktivitas admin ---------- */
function log_activity(string $action, string $detail = ''): void
{
    try {
        q_exec('INSERT INTO admin_activity_logs (admin_id, admin_name, action, detail, ip_address) VALUES (?,?,?,?,?)', [
            $_SESSION['admin_id'] ?? null, $_SESSION['admin_name'] ?? 'sistem', mb_substr($action, 0, 100), mb_substr($detail, 0, 255), client_ip(),
        ]);
    } catch (Throwable $e) { error_log('log_activity: ' . $e->getMessage()); }
}

/* ---------- Label kategori staff & pilihan umum ---------- */
function staff_categories(): array
{
    return ['pimpinan' => 'Pimpinan Sekolah', 'wakasek' => 'Wakil Kepala Sekolah', 'guru' => 'Guru', 'staff_usaha' => 'Staff Usaha', 'staff_kurikulum' => 'Staff Kurikulum'];
}
function ppdb_statuses(): array
{
    return ['menunggu' => 'Menunggu Verifikasi', 'diverifikasi' => 'Sedang Diverifikasi', 'diterima' => 'Diterima', 'ditolak' => 'Tidak Diterima'];
}
function status_badge(string $status): string
{
    $cls = ['menunggu' => 'warning text-dark', 'diverifikasi' => 'info text-dark', 'diterima' => 'success', 'ditolak' => 'danger'][$status] ?? 'secondary';
    return '<span class="badge bg-' . $cls . '">' . e(ppdb_statuses()[$status] ?? $status) . '</span>';
}
/** Tentukan menu navbar aktif berdasarkan nama file saat ini. */
function current_script(): string
{
    return basename($_SERVER['SCRIPT_NAME'] ?? '');
}
