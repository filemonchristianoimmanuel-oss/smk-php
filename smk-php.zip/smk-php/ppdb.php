<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/components.php';

$year = setting('ppdb_year');
$closeDate = setting('ppdb_close_date');
$isOpen = (int)setting('ppdb_open', '1') === 1 && !($closeDate !== '' && strtotime($closeDate . ' 23:59:59') < time());
$reqNisn  = (int)setting('ppdb_require_nisn', '0') === 1;
$reqEmail = (int)setting('ppdb_require_email', '0') === 1;
$programs = q_all('SELECT id, name FROM study_programs WHERE is_published = 1 ORDER BY sort_order, id');

$old = []; $errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $back = url('ppdb.php#formulir');
    if (!csrf_valid()) { flash('danger', 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.'); redirect($back); }
    if (!$isOpen) { flash('danger', 'Pendaftaran PPDB saat ini ditutup.'); redirect($back); }
    if (!empty($_POST['website_url'])) { redirect(url('index.php')); } // honeypot
    if (rate_limited('ppdb_submit', 3, 600)) { flash('danger', 'Terlalu banyak pengiriman. Coba lagi beberapa menit lagi.'); redirect($back); }

    $f = fn($k) => trim((string)($_POST[$k] ?? ''));
    $old = ['full_name' => $f('full_name'), 'nisn' => $f('nisn'), 'birth_place' => $f('birth_place'), 'birth_date' => $f('birth_date'),
        'gender' => $f('gender'), 'address' => $f('address'), 'previous_school' => $f('previous_school'), 'phone' => $f('phone'),
        'email' => $f('email'), 'program_id' => $f('program_id'), 'parent_name' => $f('parent_name')];

    $len = fn($s) => mb_strlen($s);
    if ($old['full_name'] === '' || $len($old['full_name']) < 3 || $len($old['full_name']) > 150 || !preg_match("/^[\p{L}\s.'\-]+$/u", $old['full_name'])) $errors['full_name'] = 'Nama lengkap wajib diisi (3-150 huruf).';
    if ($old['nisn'] === '' ? $reqNisn : !preg_match('/^\d{10}$/', $old['nisn'])) $errors['nisn'] = 'NISN harus 10 digit angka' . ($reqNisn ? ' dan wajib diisi.' : ' (boleh dikosongkan).');
    if ($old['birth_place'] === '' || $len($old['birth_place']) > 100) $errors['birth_place'] = 'Tempat lahir wajib diisi.';
    $bd = DateTime::createFromFormat('Y-m-d', $old['birth_date']);
    if (!$bd || $bd->format('Y-m-d') !== $old['birth_date']) $errors['birth_date'] = 'Tanggal lahir tidak valid.';
    else { $age = (int)$bd->diff(new DateTime())->y; if ($age < 11 || $age > 25) $errors['birth_date'] = 'Tanggal lahir tidak wajar. Periksa kembali.'; }
    if (!in_array($old['gender'], ['L', 'P'], true)) $errors['gender'] = 'Pilih jenis kelamin.';
    if ($old['address'] === '' || $len($old['address']) < 10 || $len($old['address']) > 500) $errors['address'] = 'Alamat wajib diisi (minimal 10 karakter).';
    if ($old['previous_school'] === '' || $len($old['previous_school']) > 150) $errors['previous_school'] = 'Asal sekolah wajib diisi.';
    if (!preg_match('/^(\+62|62|0)8[0-9]{8,12}$/', preg_replace('/[\s-]/', '', $old['phone'])) && !preg_match('/^0\d{2,3}-?\d{6,8}$/', $old['phone'])) $errors['phone'] = 'Nomor telepon tidak valid (contoh: 08123456789).';
    if ($old['email'] === '' ? $reqEmail : (!filter_var($old['email'], FILTER_VALIDATE_EMAIL) || $len($old['email']) > 120)) $errors['email'] = 'Email tidak valid' . ($reqEmail ? ' dan wajib diisi.' : '.');
    $prog = null;
    foreach ($programs as $p) if ((string)$p['id'] === $old['program_id']) $prog = $p;
    if (!$prog) $errors['program_id'] = 'Pilih program keahlian.';
    if ($old['parent_name'] === '' || $len($old['parent_name']) < 3 || $len($old['parent_name']) > 150) $errors['parent_name'] = 'Nama orang tua/wali wajib diisi.';

    if (!$errors && $old['nisn'] !== '' && q_val('SELECT COUNT(*) FROM ppdb_registrations WHERE nisn = ? AND academic_year = ?', [$old['nisn'], $year])) {
        $errors['nisn'] = 'NISN ini sudah terdaftar pada PPDB ' . $year . '. Hubungi panitia jika ada kesalahan data.';
    }

    if (!$errors) {
        try {
            $pdo = db(); $pdo->beginTransaction();
            q_exec('INSERT INTO ppdb_registrations (academic_year, full_name, nisn, birth_place, birth_date, gender, address, previous_school, phone, email, program_id, program_name, parent_name, ip_address)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [
                $year, $old['full_name'], $old['nisn'] ?: null, $old['birth_place'], $old['birth_date'], $old['gender'], $old['address'],
                $old['previous_school'], $old['phone'], $old['email'] ?: null, $prog['id'], $prog['name'], $old['parent_name'], client_ip()]);
            $id = (int)$pdo->lastInsertId();
            $no = 'PPDB-' . preg_replace('/\D/', '', substr($year, 0, 4)) . '-' . str_pad((string)$id, 5, '0', STR_PAD_LEFT);
            q_exec('UPDATE ppdb_registrations SET registration_no = ? WHERE id = ?', [$no, $id]);
            $pdo->commit();
            $_SESSION['ppdb_success'] = ['no' => $no, 'name' => $old['full_name']];
            redirect(url('ppdb.php?berhasil=1#formulir'));
        } catch (Throwable $ex) {
            if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
            error_log('PPDB insert failed: ' . $ex->getMessage());
            flash('danger', 'Pendaftaran GAGAL disimpan karena kendala sistem. Data Anda belum tercatat, silakan coba lagi atau hubungi panitia.');
        }
    } else {
        flash('danger', 'Pendaftaran belum dapat disimpan. Periksa kolom yang ditandai merah.');
    }
}
$success = null;
if (isset($_GET['berhasil']) && !empty($_SESSION['ppdb_success'])) { $success = $_SESSION['ppdb_success']; unset($_SESSION['ppdb_success']); }

$info = [];
foreach (q_all('SELECT * FROM ppdb_info WHERE is_published = 1 ORDER BY sort_order, id') as $r) $info[$r['type']][] = $r;
$brochure = setting('ppdb_brochure');
$hasBrochure = $brochure !== '' && is_file(ROOT_PATH . '/' . $brochure);
$brochureUrl = $hasBrochure ? url($brochure) : asset('images/placeholder-brochure.svg');
$fv = fn($k) => e($old[$k] ?? '');
$inv = fn($k) => isset($errors[$k]) ? ' is-invalid' : '';
$err = fn($k) => isset($errors[$k]) ? '<div class="invalid-feedback d-block">' . e($errors[$k]) . '</div>' : '';

$pageTitle = 'PPDB Online ' . $year;
$metaDesc  = 'Pendaftaran peserta didik baru ' . setting('school_name') . ' tahun ajaran ' . $year . '. Lihat persyaratan, jadwal, alur, dan daftar online.';
require __DIR__ . '/includes/header.php';
page_banner(setting('ppdb_title', 'PPDB Online'), [], 'Tahun Ajaran ' . $year);
?>
<!-- BROSUR (bagian paling atas) -->
<section class="section pb-4">
    <div class="container">
        <div class="brosur-box">
            <a href="<?= e($brochureUrl) ?>" data-lightbox data-title="<?= $hasBrochure ? 'Brosur PPDB ' . e($year) : 'CONTOH BROSUR PPDB' ?>"><img src="<?= e($brochureUrl) ?>" alt="<?= $hasBrochure ? 'Brosur PPDB ' . e($year) : 'Contoh brosur PPDB (placeholder)' ?>"></a>
            <div class="d-flex flex-wrap gap-2 justify-content-center mt-4">
                <a href="<?= e($brochureUrl) ?>" class="btn btn-blue" data-lightbox data-title="Brosur PPDB <?= e($year) ?>"><i class="fa-solid fa-eye me-2"></i>Lihat Brosur</a>
                <a href="<?= e($brochureUrl) ?>" class="btn btn-gold" download="Brosur-PPDB-<?= e(preg_replace('/\W+/', '-', $year)) ?>.<?= e(pathinfo($brochureUrl, PATHINFO_EXTENSION)) ?>"><i class="fa-solid fa-download me-2"></i>Unduh Brosur</a>
            </div>
            <?php if (!$hasBrochure): ?><p class="small text-muted mt-3"><i class="fa-solid fa-circle-info"></i> Ini hanya contoh. Admin dapat mengunggah brosur resmi melalui Dashboard &gt; PPDB Online &gt; Brosur PPDB.</p><?php endif; ?>
        </div>
    </div>
</section>

<section class="section pt-4">
<div class="container">
    <?= section_title(setting('ppdb_title'), 'Tahun Ajaran ' . $year) ?>
    <div class="row justify-content-center mb-5"><div class="col-lg-9"><div class="ppdb-card rich">
        <h3><i class="fa-solid fa-circle-info"></i> Informasi Pendaftaran</h3>
        <?= format_text(setting('ppdb_info')) ?>
        <p class="mb-0"><span class="badge <?= $isOpen ? 'bg-success' : 'bg-secondary' ?>"><?= $isOpen ? 'Pendaftaran DIBUKA' : 'Pendaftaran DITUTUP' ?></span>
        <?php if ($closeDate !== '' && $isOpen): ?> <small class="text-muted">sampai <?= e(tgl_indo($closeDate)) ?></small><?php endif; ?></p>
    </div></div></div>

    <div class="row g-4 mb-5">
        <div class="col-lg-6"><div class="ppdb-card"><h3><i class="fa-solid fa-clipboard-check"></i> Persyaratan Pendaftaran</h3>
            <?php if (!empty($info['persyaratan'])): ?><ul class="check-list"><?php foreach ($info['persyaratan'] as $r) echo '<li>' . e($r['title']) . ($r['content'] ? '<br><small class="text-muted">' . e($r['content']) . '</small>' : '') . '</li>'; ?></ul><?php else: echo '<p class="text-muted">Belum diisi.</p>'; endif; ?></div></div>
        <div class="col-lg-6"><div class="ppdb-card"><h3><i class="fa-solid fa-calendar-days"></i> Jadwal Pendaftaran</h3>
            <?php if (!empty($info['jadwal'])): foreach ($info['jadwal'] as $r): ?><div class="sched-item"><div class="sched-date"><?= e($r['date_label']) ?></div><div><strong><?= e($r['title']) ?></strong><?= $r['content'] ? '<br><small class="text-muted">' . e($r['content']) . '</small>' : '' ?></div></div><?php endforeach; else: echo '<p class="text-muted">Belum diisi.</p>'; endif; ?></div></div>
        <div class="col-lg-7"><div class="ppdb-card"><h3><i class="fa-solid fa-route"></i> Alur Pendaftaran</h3>
            <?php if (!empty($info['alur'])): ?><ol class="steps mb-0"><?php foreach ($info['alur'] as $r) echo '<li><div><h4>' . e($r['title']) . '</h4>' . ($r['content'] ? '<p class="mb-0 text-muted">' . e($r['content']) . '</p>' : '') . '</div></li>'; ?></ol><?php else: echo '<p class="text-muted">Belum diisi.</p>'; endif; ?></div></div>
        <div class="col-lg-5"><div class="ppdb-card"><h3><i class="fa-solid fa-signs-post"></i> Jalur Pendaftaran</h3>
            <?php if (!empty($info['jalur'])): foreach ($info['jalur'] as $r) echo '<div class="mb-3"><strong>' . e($r['title']) . '</strong><p class="mb-0 text-muted small">' . e($r['content']) . '</p></div>'; else: echo '<p class="text-muted">Belum ada informasi jalur khusus.</p>'; endif; ?></div></div>
    </div>

    <?php if (!empty($info['faq'])): ?>
    <div class="row justify-content-center mb-5"><div class="col-lg-9">
        <?= section_title('Pertanyaan yang Sering Diajukan') ?>
        <div class="accordion" id="faq">
            <?php foreach ($info['faq'] as $i => $r): ?>
            <div class="accordion-item"><h3 class="accordion-header"><button class="accordion-button <?= $i ? 'collapsed' : '' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#f<?= (int)$r['id'] ?>"><?= e($r['title']) ?></button></h3>
                <div id="f<?= (int)$r['id'] ?>" class="accordion-collapse collapse <?= $i ? '' : 'show' ?>" data-bs-parent="#faq"><div class="accordion-body"><?= format_text($r['content']) ?></div></div></div>
            <?php endforeach; ?>
        </div></div></div>
    <?php endif; ?>

    <div class="row justify-content-center mb-5"><div class="col-lg-9"><div class="ppdb-card text-center">
        <h3><i class="fa-solid fa-headset"></i> Kontak Panitia PPDB</h3>
        <p class="mb-1 fw-bold"><?= e(setting('ppdb_contact_name')) ?></p>
        <p class="mb-0"><i class="fa-solid fa-phone text-primary"></i> <a href="tel:<?= e(preg_replace('/[^0-9+]/', '', setting('ppdb_contact_phone'))) ?>"><?= e(setting('ppdb_contact_phone')) ?></a>
        &nbsp;&bull;&nbsp; <i class="fa-solid fa-envelope text-primary"></i> <a href="mailto:<?= e(setting('ppdb_contact_email')) ?>"><?= e(setting('ppdb_contact_email')) ?></a></p>
    </div></div></div>

    <!-- FORMULIR -->
    <div id="formulir" class="row justify-content-center"><div class="col-lg-9">
        <?= section_title('Formulir Pendaftaran', 'Isi data dengan benar sesuai dokumen resmi') ?>
        <?= flash_render() ?>
        <?php if ($success): ?>
            <div class="reg-success">
                <i class="fa-solid fa-circle-check fa-3x text-success"></i>
                <h3 class="mt-2">Pendaftaran Berhasil Disimpan</h3>
                <p class="mb-0">Terima kasih, <strong><?= e($success['name']) ?></strong>. Nomor pendaftaran Anda:</p>
                <div class="reg-no"><?= e($success['no']) ?></div>
                <p class="mb-0"><?= e(setting('ppdb_success_message')) ?></p>
            </div>
        <?php elseif (!$isOpen): ?>
            <div class="alert alert-secondary text-center"><i class="fa-solid fa-lock me-2"></i>Pendaftaran PPDB saat ini sedang ditutup. Pantau informasi terbaru dari sekolah.</div>
        <?php else: ?>
        <div class="form-card"><form method="post" action="<?= url('ppdb.php#formulir') ?>" novalidate data-once>
            <?= csrf_field() ?>
            <div class="hp-field" aria-hidden="true"><label>Jangan diisi<input type="text" name="website_url" tabindex="-1" autocomplete="off"></label></div>
            <div class="row g-3">
                <div class="col-md-8"><label class="form-label" for="full_name">Nama Lengkap <span class="req">*</span></label><input class="form-control<?= $inv('full_name') ?>" id="full_name" name="full_name" maxlength="150" value="<?= $fv('full_name') ?>" required><?= $err('full_name') ?></div>
                <div class="col-md-4"><label class="form-label" for="nisn">NISN <?= $reqNisn ? '<span class="req">*</span>' : '<small class="text-muted fw-normal">(jika ada)</small>' ?></label><input class="form-control<?= $inv('nisn') ?>" id="nisn" name="nisn" inputmode="numeric" maxlength="10" value="<?= $fv('nisn') ?>"><?= $err('nisn') ?></div>
                <div class="col-md-5"><label class="form-label" for="birth_place">Tempat Lahir <span class="req">*</span></label><input class="form-control<?= $inv('birth_place') ?>" id="birth_place" name="birth_place" maxlength="100" value="<?= $fv('birth_place') ?>" required><?= $err('birth_place') ?></div>
                <div class="col-md-4"><label class="form-label" for="birth_date">Tanggal Lahir <span class="req">*</span></label><input type="date" class="form-control<?= $inv('birth_date') ?>" id="birth_date" name="birth_date" max="<?= date('Y-m-d') ?>" value="<?= $fv('birth_date') ?>" required><?= $err('birth_date') ?></div>
                <div class="col-md-3"><label class="form-label" for="gender">Jenis Kelamin <span class="req">*</span></label><select class="form-select<?= $inv('gender') ?>" id="gender" name="gender" required><option value="">Pilih</option><option value="L" <?= ($old['gender'] ?? '') === 'L' ? 'selected' : '' ?>>Laki-laki</option><option value="P" <?= ($old['gender'] ?? '') === 'P' ? 'selected' : '' ?>>Perempuan</option></select><?= $err('gender') ?></div>
                <div class="col-12"><label class="form-label" for="address">Alamat <span class="req">*</span></label><textarea class="form-control<?= $inv('address') ?>" id="address" name="address" rows="3" maxlength="500" required><?= $fv('address') ?></textarea><?= $err('address') ?></div>
                <div class="col-md-6"><label class="form-label" for="previous_school">Asal Sekolah <span class="req">*</span></label><input class="form-control<?= $inv('previous_school') ?>" id="previous_school" name="previous_school" maxlength="150" value="<?= $fv('previous_school') ?>" required><?= $err('previous_school') ?></div>
                <div class="col-md-6"><label class="form-label" for="program_id">Program Keahlian yang Dipilih <span class="req">*</span></label><select class="form-select<?= $inv('program_id') ?>" id="program_id" name="program_id" required><option value="">Pilih program keahlian</option><?php foreach ($programs as $p): ?><option value="<?= (int)$p['id'] ?>" <?= ($old['program_id'] ?? '') === (string)$p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?></option><?php endforeach; ?></select><?= $err('program_id') ?></div>
                <div class="col-md-6"><label class="form-label" for="phone">Nomor Telepon / WhatsApp <span class="req">*</span></label><input type="tel" class="form-control<?= $inv('phone') ?>" id="phone" name="phone" maxlength="20" value="<?= $fv('phone') ?>" placeholder="08xxxxxxxxxx" required><?= $err('phone') ?></div>
                <div class="col-md-6"><label class="form-label" for="email">Email <?= $reqEmail ? '<span class="req">*</span>' : '<small class="text-muted fw-normal">(jika ada)</small>' ?></label><input type="email" class="form-control<?= $inv('email') ?>" id="email" name="email" maxlength="120" value="<?= $fv('email') ?>"><?= $err('email') ?></div>
                <div class="col-12"><label class="form-label" for="parent_name">Nama Orang Tua / Wali <span class="req">*</span></label><input class="form-control<?= $inv('parent_name') ?>" id="parent_name" name="parent_name" maxlength="150" value="<?= $fv('parent_name') ?>" required><?= $err('parent_name') ?></div>
            </div>
            <p class="small text-muted mt-3 mb-3"><i class="fa-solid fa-shield-halved text-primary"></i> Data Anda hanya digunakan untuk keperluan PPDB dan tidak ditampilkan kepada publik.</p>
            <button type="submit" class="btn btn-blue btn-lg w-100"><i class="fa-solid fa-paper-plane me-2"></i>Daftar Sekarang</button>
        </form></div>
        <?php endif; ?>
    </div></div>
</div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
