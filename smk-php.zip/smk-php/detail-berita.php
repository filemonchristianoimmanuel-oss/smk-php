<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/components.php';

$n = q_one('SELECT n.*, c.name AS category_name, c.slug AS category_slug FROM news n LEFT JOIN news_categories c ON c.id = n.category_id WHERE n.slug = ? AND ' . published_news_sql(), [get_str('slug','')]);
if (!$n) show_404();
if (empty($_SESSION['viewed_news'][$n['id']])) {
    q_exec('UPDATE news SET views = views + 1 WHERE id = ?', [$n['id']]);
    $_SESSION['viewed_news'][$n['id']] = 1; $n['views']++;
}
$related = q_all('SELECT n.*, c.name AS category_name FROM news n LEFT JOIN news_categories c ON c.id = n.category_id WHERE ' . published_news_sql() . ' AND n.id <> ? ' . ($n['category_id'] ? 'AND n.category_id = ' . (int)$n['category_id'] : '') . ' ORDER BY n.published_at DESC LIMIT 3', [$n['id']]);
if (count($related) < 3) {
    $ids = array_merge([(int)$n['id']], array_map(fn($r) => (int)$r['id'], $related));
    $more = q_all('SELECT n.*, c.name AS category_name FROM news n LEFT JOIN news_categories c ON c.id = n.category_id WHERE ' . published_news_sql() . ' AND n.id NOT IN (' . implode(',', $ids) . ') ORDER BY n.published_at DESC LIMIT ' . (3 - count($related)));
    $related = array_merge($related, $more);
}
$pageTitle = $n['title'];
$metaDesc  = $n['summary'] ?: excerpt($n['content'], 160);
$metaImage = (!empty($n['image']) && is_file(ROOT_PATH . '/' . $n['image'])) ? ((isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . url($n['image'])) : null;
if (!$metaImage) unset($metaImage);
require __DIR__ . '/includes/header.php';
page_banner('Detail Berita', ['Berita' => 'berita.php']);
?>
<div class="container py-5 news-detail">
    <div class="row justify-content-center"><div class="col-lg-9">
        <?php if ($n['category_name']): ?><a class="badge bg-warning text-dark text-decoration-none mb-2" href="<?= e(url('berita.php?kategori=' . urlencode($n['category_slug']))) ?>"><?= e($n['category_name']) ?></a><?php endif; ?>
        <h2 class="mb-3"><?= e($n['title']) ?></h2>
        <div class="meta mb-4"><i class="fa-regular fa-calendar"></i> <?= e(tgl_indo($n['published_at'])) ?> &nbsp;<i class="fa-regular fa-user"></i> <?= e($n['author'] ?: 'Admin') ?> &nbsp;<i class="fa-regular fa-eye"></i> <?= number_format((int)$n['views'], 0, ',', '.') ?> kali dibaca</div>
        <?php if ($n['image']): ?><img class="cover mb-4" src="<?= e(img_url($n['image'])) ?>" alt="<?= e($n['title']) ?>"><?php endif; ?>
        <div class="article rich"><?= format_text($n['content']) ?></div>
        <hr class="my-4"><a href="<?= url('berita.php') ?>" class="btn btn-outline-blue"><i class="fa-solid fa-arrow-left me-2"></i>Kembali ke Berita</a>
    </div></div>
    <?php if ($related): ?>
    <div class="mt-5 pt-4"><?= section_title('Berita Terkait') ?><div class="row g-4"><?php foreach ($related as $r): ?><div class="col-md-6 col-lg-4"><?= news_card($r) ?></div><?php endforeach; ?></div></div>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
