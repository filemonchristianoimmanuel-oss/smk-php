<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/components.php';
$p = q_one('SELECT * FROM study_programs WHERE slug = ? AND is_published = 1', [get_str('slug','')]);
if (!$p) show_404();
$others = q_all('SELECT name, slug FROM study_programs WHERE is_published = 1 AND id <> ? ORDER BY sort_order, id', [$p['id']]);
$pageTitle = $p['name'];
$metaDesc  = excerpt($p['description'], 160);
require __DIR__ . '/includes/header.php';
page_banner($p['name'], ['Akademik' => 'akademik.php?s=program', 'Program Keahlian' => 'akademik.php?s=program']);
?>
<div class="container py-5">
<div class="row g-5">
    <div class="col-lg-8">
        <?php if ($p['image']): ?><img class="img-fluid rounded-4 shadow mb-4" src="<?= e(img_url($p['image'])) ?>" alt="<?= e($p['name']) ?>"><?php endif; ?>
        <div class="d-flex align-items-center gap-3 mb-3"><div class="prog-icon m-0" style="width:64px;height:64px;font-size:1.5rem"><i class="<?= e($p['icon']) ?>"></i></div>
            <div><?php if ($p['short_name']): ?><span class="prog-short mb-0"><?= e($p['short_name']) ?></span><?php endif; ?><h2 class="h3 mb-0"><?= e($p['name']) ?></h2></div></div>
        <div class="rich mb-4"><?= format_text($p['description']) ?></div>
        <?php foreach ([['competencies', 'Kompetensi yang Dipelajari', 'fa-list-check'], ['career_prospects', 'Prospek Karier', 'fa-briefcase'], ['supporting_facilities', 'Fasilitas Pendukung', 'fa-computer']] as $b):
            if (!trim((string)$p[$b[0]])) continue; ?>
            <section class="block-section"><h3 class="block-title"><i class="fa-solid <?= $b[2] ?>"></i> <?= $b[1] ?></h3><div class="rich"><?= format_text($p[$b[0]]) ?></div></section>
        <?php endforeach; ?>
    </div>
    <aside class="col-lg-4">
        <div class="side-box"><h3>Program Keahlian Lain</h3><ul class="side-list">
            <?php foreach ($others as $o): ?><li><a href="<?= e(url('program-detail.php?slug=' . urlencode($o['slug']))) ?>"><i class="fa-solid fa-angle-right text-primary me-1"></i><?= e($o['name']) ?></a></li><?php endforeach; ?>
            <?php if (!$others) echo '<li class="text-muted small">Belum ada program lain.</li>'; ?></ul></div>
        <div class="side-box text-center" style="background:var(--blue);color:#fff;border:0"><h3 class="text-white" style="border-color:var(--gold)">Tertarik?</h3><p>Daftarkan diri Anda pada PPDB Online.</p><a class="btn btn-gold w-100" href="<?= url('ppdb.php#formulir') ?>">Daftar Sekarang</a></div>
    </aside>
</div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
