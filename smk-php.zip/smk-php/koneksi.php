
<?php
// Konfigurasi database
$host     = "localhost";
$username = "root";
$password = "";
$database = "smk_infokom";

// Membuat koneksi ke database
$conn = mysqli_connect($host, $username, $password, $database);

// Mengecek koneksi
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Mengatur charset
mysqli_set_charset($conn, "utf8mb4");
?>
