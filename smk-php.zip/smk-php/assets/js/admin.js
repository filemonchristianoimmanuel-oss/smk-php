/* JavaScript dashboard admin SMK INFOKOM BOGOR */
(function () {
    'use strict';
    var sb = document.getElementById('admSidebar'), ov = document.getElementById('admOverlay'), tg = document.getElementById('admToggle');
    function toggle(open) {
        if (!sb) return;
        sb.classList.toggle('open', open);
        if (ov) ov.classList.toggle('show', open);
        if (tg) tg.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
    if (tg) tg.addEventListener('click', function () { toggle(!sb.classList.contains('open')); });
    if (ov) ov.addEventListener('click', function () { toggle(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') toggle(false); });

    // Mode gelap / terang
    var tt = document.getElementById('themeToggle');
    function paintIcon() {
        if (!tt) return;
        var dark = document.documentElement.getAttribute('data-theme') === 'dark';
        tt.innerHTML = '<i class="fa-solid ' + (dark ? 'fa-sun' : 'fa-moon') + '"></i>';
    }
    paintIcon();
    if (tt) tt.addEventListener('click', function () {
        var next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        try { localStorage.setItem('adm-theme', next); } catch (e) {}
        paintIcon();
    });

    // Konfirmasi hapus (modal, metode POST + CSRF)
    var modalEl = document.getElementById('deleteModal');
    if (modalEl && window.bootstrap) {
        var modal = new bootstrap.Modal(modalEl);
        document.addEventListener('click', function (e) {
            var b = e.target.closest('[data-delete]');
            if (!b) return;
            document.getElementById('deleteId').value = b.getAttribute('data-delete');
            document.getElementById('deleteName').textContent = '"' + (b.getAttribute('data-name') || 'data ini') + '"';
            document.getElementById('deleteForm').setAttribute('action', b.getAttribute('data-action') || window.location.href);
            modal.show();
        });
    }

    // Pratinjau gambar sebelum diunggah + validasi ukuran
    document.querySelectorAll('input[type=file][data-preview]').forEach(function (inp) {
        inp.addEventListener('change', function () {
            var pv = document.getElementById(inp.getAttribute('data-preview')), f = inp.files && inp.files[0];
            if (!f) { if (pv) pv.classList.add('d-none'); return; }
            if (f.size > 3 * 1024 * 1024) { alert('Ukuran gambar maksimal 3 MB.'); inp.value = ''; if (pv) pv.classList.add('d-none'); return; }
            if (pv && f.type.indexOf('image/') === 0 && f.type !== 'image/x-icon') {
                var r = new FileReader();
                r.onload = function (ev) { pv.src = ev.target.result; pv.classList.remove('d-none'); };
                r.readAsDataURL(f);
            }
        });
    });

    // Cegah kirim ganda
    document.querySelectorAll('form[data-once]').forEach(function (f) {
        f.addEventListener('submit', function () {
            var b = f.querySelector('button[type=submit], button:not([type])');
            if (b) { setTimeout(function () { b.disabled = true; }, 0); }
        });
    });
})();
