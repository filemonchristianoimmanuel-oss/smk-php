/* JavaScript publik SMK INFOKOM BOGOR */
(function () {
    'use strict';
    document.documentElement.classList.remove('no-js');

    // Tombol kembali ke atas
    var toTop = document.getElementById('toTop');
    if (toTop) {
        window.addEventListener('scroll', function () { toTop.classList.toggle('show', window.scrollY > 500); }, { passive: true });
        toTop.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
    }

    // Animasi muncul halus (hanya untuk elemen bertanda .reveal)
    var rev = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window && rev.length) {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
        }, { threshold: 0.12 });
        rev.forEach(function (el) { io.observe(el); });
    } else { rev.forEach(function (el) { el.classList.add('in'); }); }

    // Hitung angka statistik
    document.querySelectorAll('[data-count]').forEach(function (el) {
        var target = parseInt(el.getAttribute('data-count'), 10) || 0, done = false;
        function run() {
            if (done) return; done = true;
            var start = null, dur = 1200;
            function step(ts) {
                if (!start) start = ts;
                var p = Math.min((ts - start) / dur, 1);
                el.textContent = Math.floor(p * target).toLocaleString('id-ID');
                if (p < 1) requestAnimationFrame(step); else el.textContent = target.toLocaleString('id-ID');
            }
            requestAnimationFrame(step);
        }
        if ('IntersectionObserver' in window) {
            new IntersectionObserver(function (e, o) { if (e[0].isIntersecting) { run(); o.disconnect(); } }).observe(el);
        } else { run(); }
    });

    // Menutup menu mobile setelah memilih tautan
    var menu = document.getElementById('mainMenu');
    if (menu) {
        menu.querySelectorAll('.dropdown-item, .nav-link:not(.dropdown-toggle)').forEach(function (a) {
            a.addEventListener('click', function () {
                if (window.innerWidth < 1200 && menu.classList.contains('show')) {
                    bootstrap.Collapse.getOrCreateInstance(menu).hide();
                }
            });
        });
    }

    // Lightbox galeri / brosur
    var items = Array.prototype.slice.call(document.querySelectorAll('[data-lightbox]'));
    if (items.length) {
        var box = document.createElement('div');
        box.className = 'lightbox';
        box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.setAttribute('aria-label', 'Tampilan gambar');
        box.innerHTML = '<button class="lb-btn lb-close" aria-label="Tutup"><i class="fa-solid fa-xmark"></i></button>' +
            '<button class="lb-btn lb-prev" aria-label="Sebelumnya"><i class="fa-solid fa-chevron-left"></i></button>' +
            '<figure><img alt=""><figcaption></figcaption></figure>' +
            '<button class="lb-btn lb-next" aria-label="Berikutnya"><i class="fa-solid fa-chevron-right"></i></button>';
        document.body.appendChild(box);
        var img = box.querySelector('img'), cap = box.querySelector('figcaption'), idx = 0;
        function show(i) {
            idx = (i + items.length) % items.length;
            var it = items[idx];
            img.src = it.getAttribute('data-full') || it.getAttribute('href');
            img.alt = it.getAttribute('data-title') || '';
            cap.innerHTML = '';
            var t = document.createElement('strong'); t.textContent = it.getAttribute('data-title') || '';
            cap.appendChild(t);
            var c = it.getAttribute('data-caption');
            if (c) { var s = document.createElement('small'); s.textContent = c; cap.appendChild(s); }
            var single = items.length < 2;
            box.querySelector('.lb-prev').style.display = single ? 'none' : '';
            box.querySelector('.lb-next').style.display = single ? 'none' : '';
        }
        function open(i) { show(i); box.classList.add('open'); document.body.style.overflow = 'hidden'; box.querySelector('.lb-close').focus(); }
        function close() { box.classList.remove('open'); document.body.style.overflow = ''; }
        items.forEach(function (it, i) { it.addEventListener('click', function (e) { e.preventDefault(); open(i); }); });
        box.querySelector('.lb-close').addEventListener('click', close);
        box.querySelector('.lb-prev').addEventListener('click', function () { show(idx - 1); });
        box.querySelector('.lb-next').addEventListener('click', function () { show(idx + 1); });
        box.addEventListener('click', function (e) { if (e.target === box) close(); });
        document.addEventListener('keydown', function (e) {
            if (!box.classList.contains('open')) return;
            if (e.key === 'Escape') close();
            if (e.key === 'ArrowLeft') show(idx - 1);
            if (e.key === 'ArrowRight') show(idx + 1);
        });
    }

    // Hindari kirim ganda pada formulir publik
    document.querySelectorAll('form[data-once]').forEach(function (f) {
        f.addEventListener('submit', function () {
            var b = f.querySelector('button[type=submit]');
            if (b) { b.disabled = true; b.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Memproses...'; }
        });
    });
})();
