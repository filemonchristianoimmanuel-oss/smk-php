<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/components.php';

$all = q_all('SELECT * FROM staff_profiles WHERE is_published = 1 ORDER BY sort_order, name');
$by = array_fill_keys(array_keys(staff_categories()), []);
foreach ($all as $r) { if (isset($by[$r['category']])) $by[$r['category']][] = $r; }
$anchors = ['pimpinan' => 'pimpinan', 'wakasek' => 'wakasek', 'guru' => 'guru', 'staff_usaha' => 'staff-usaha', 'staff_kurikulum' => 'staff-kurikulum'];
$descs = [
    'pimpinan' => 'Pemimpin yang mengarahkan visi dan mutu sekolah',
    'wakasek' => 'Pendamping pimpinan di bidang kurikulum, kesiswaan, sarana, dan hubungan industri',
    'guru' => 'Pendidik yang membimbing siswa di setiap bidang keahlian',
    'staff_usaha' => 'Tenaga administrasi yang mendukung layanan sekolah',
    'staff_kurikulum' => 'Staff yang mengelola administrasi dan pelaksanaan kurikulum',
];
$pageTitle = 'Guru dan Staff';
$metaDesc  = 'Profil pimpinan, wakil kepala sekolah, guru, staff usaha, dan staff kurikulum ' . setting('school_name') . '.';
require __DIR__ . '/includes/header.php';
page_banner('Guru dan Staff', [], 'Tenaga pendidik dan kependidikan ' . setting('school_name'));
?>
<div class="container pb-5">
<?php foreach (staff_categories() as $key => $label): ?>
    <section class="staff-section" id="<?= $anchors[$key] ?>">
        <div class="staff-heading"><h2><?= e($label) ?></h2><p><?= e($descs[$key]) ?></p></div>
        <?php if (!$by[$key]): echo empty_state('Data ' . mb_strtolower($label) . ' belum tersedia.'); else: ?>
        <div class="staff-grid">
            <?php foreach ($by[$key] as $s) echo staff_card($s, $key === 'pimpinan'); ?>
        </div>
        <?php endif; ?>
    </section>
<?php endforeach; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
