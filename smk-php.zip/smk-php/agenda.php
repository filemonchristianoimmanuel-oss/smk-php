<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/components.php';

$cats = q_all('SELECT * FROM agenda_categories ORDER BY name');
$tab  = (get_str('tab','mendatang')) === 'lalu' ? 'lalu' : 'mendatang';
$cat  = trim(get_str('kategori',''));
$from = preg_match('/^\d{4}-\d{2}-\d{2}$/', get_str('dari','')) ? get_str('dari') : '';
$to   = preg_match('/^\d{4}-\d{2}-\d{2}$/', get_str('sampai','')) ? get_str('sampai') : '';

$where = ['a.is_published = 1']; $par = [];
$where[] = $tab === 'mendatang' ? 'COALESCE(a.end_date, a.event_date) >= CURDATE()' : 'COALESCE(a.end_date, a.event_date) < CURDATE()';
if ($cat !== '') { $where[] = 'c.slug = ?'; $par[] = $cat; }
if ($from) { $where[] = 'COALESCE(a.end_date, a.event_date) >= ?'; $par[] = $from; }
if ($to)   { $where[] = 'a.event_date <= ?'; $par[] = $to; }
$w = implode(' AND ', $where);
$total = (int)q_val("SELECT COUNT(*) FROM agendas a LEFT JOIN agenda_categories c ON c.id = a.category_id WHERE $w", $par);
$pg = paginate($total, 9, (int)get_str('page','1'));
$order = $tab === 'mendatang' ? 'a.event_date ASC, a.start_time ASC' : 'a.event_date DESC';
$rows = q_all("SELECT a.*, c.name AS category_name FROM agendas a LEFT JOIN agenda_categories c ON c.id = a.category_id WHERE $w ORDER BY $order LIMIT {$pg['per']} OFFSET {$pg['offset']}", $par);

$keep = ['tab' => $tab, 'kategori' => $cat, 'dari' => $from, 'sampai' => $to];
$pageTitle = 'Agenda Sekolah';
$metaDesc  = 'Agenda kegiatan ' . setting('school_name') . ': jadwal kegiatan mendatang dan yang sudah berlangsung.';
require __DIR__ . '/includes/header.php';
page_banner('Agenda', [], 'Jadwal kegiatan sekolah');
?>
<div class="container py-5">
    <ul class="nav nav-pills justify-content-center mb-4 gap-2">
        <li class="nav-item"><a class="btn <?= $tab === 'mendatang' ? 'btn-blue' : 'btn-outline-blue' ?>" href="?tab=mendatang"><i class="fa-solid fa-calendar-plus me-1"></i>Agenda Mendatang</a></li>
        <li class="nav-item"><a class="btn <?= $tab === 'lalu' ? 'btn-blue' : 'btn-outline-blue' ?>" href="?tab=lalu"><i class="fa-solid fa-clock-rotate-left me-1"></i>Sudah Berlangsung</a></li>
    </ul>
    <form class="row g-2 justify-content-center mb-4" method="get">
        <input type="hidden" name="tab" value="<?= e($tab) ?>">
        <div class="col-md-3"><select name="kategori" class="form-select" aria-label="Kategori"><option value="">Semua kategori</option><?php foreach ($cats as $c): ?><option value="<?= e($c['slug']) ?>" <?= $cat === $c['slug'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
        <div class="col-6 col-md-2"><input type="date" name="dari" class="form-control" value="<?= e($from) ?>" aria-label="Dari tanggal" title="Dari tanggal"></div>
        <div class="col-6 col-md-2"><input type="date" name="sampai" class="form-control" value="<?= e($to) ?>" aria-label="Sampai tanggal" title="Sampai tanggal"></div>
        <div class="col-auto"><button class="btn btn-blue" type="submit"><i class="fa-solid fa-filter me-1"></i>Filter</button> <a class="btn btn-outline-blue" href="?tab=<?= e($tab) ?>">Reset</a></div>
    </form>
    <?php if (!$rows): echo empty_state($tab === 'mendatang' ? 'Belum ada agenda mendatang.' : 'Belum ada agenda yang sudah berlangsung.'); else: ?>
    <div class="row g-4"><?php foreach ($rows as $a): ?><div class="col-lg-4 col-md-6"><?= agenda_card($a) ?></div><?php endforeach; ?></div>
    <div class="mt-5"><?= pagination_html($pg, $keep) ?></div>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
