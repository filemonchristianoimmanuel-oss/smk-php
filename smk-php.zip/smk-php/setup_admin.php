<?php
/**
 * SETUP ADMIN PERTAMA KALI.
 * - Hanya bisa dijalankan jika belum ada admin dan file config/installed.lock belum ada.
 * - Setelah akun dibuat, file kunci dibuat otomatis. HAPUS file ini dari server setelah instalasi.
 */
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$lockFile = ROOT_PATH . '/config/installed.lock';
$locked = is_file($lockFile);
$dbError = '';
$hasAdmin = false;
try { $hasAdmin = ((int)q_val('SELECT COUNT(*) FROM admins') > 0); }
catch (Throwable $e) { $dbError = 'Tabel database belum ditemukan. Impor database/smk_infokom.sql lewat phpMyAdmin terlebih dahulu.'; }

$done = false; $errors = []; $old = ['full_name' => '', 'username' => '', 'email' => ''];
if (!$locked && !$hasAdmin && !$dbError && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) { $errors[] = 'Sesi formulir tidak valid. Muat ulang halaman.'; }
    else {
        $old = ['full_name' => post_str('full_name'), 'username' => post_str('username'), 'email' => post_str('email')];
        $pw = (string)($_POST['password'] ?? ''); $pw2 = (string)($_POST['password2'] ?? '');
        if (mb_strlen($old['full_name']) < 3 || mb_strlen($old['full_name']) > 120) $errors[] = 'Nama lengkap wajib diisi (3-120 karakter).';
        if (!preg_match('/^[a-zA-Z0-9_.]{4,50}$/', $old['username'])) $errors[] = 'Username 4-50 karakter: huruf, angka, titik, atau garis bawah.';
        if (in_array(strtolower($old['username']), ['admin', 'administrator', 'root', 'user', 'test', 'smk', 'admin123'], true)) $errors[] = 'Username terlalu mudah ditebak. Gunakan username lain.';
        if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Email tidak valid.';
        if ($e = password_strength_error($pw)) $errors[] = $e;
        if ($pw !== $pw2) $errors[] = 'Konfirmasi password tidak sama.';
        if (!$errors) {
            try {
                $pdo = db(); $pdo->beginTransaction();
                if ((int)q_val('SELECT COUNT(*) FROM admins FOR UPDATE') > 0) throw new RuntimeException('exists');
                q_exec('INSERT INTO admins (username, email, full_name, password_hash) VALUES (?,?,?,?)', [$old['username'], $old['email'], $old['full_name'], password_hash($pw, PASSWORD_DEFAULT)]);
                $pdo->commit();
                $lockOk = @file_put_contents($lockFile, "Instalasi selesai pada " . date('c') . "\n");
                $done = true; $locked = true;
                if ($lockOk === false) $errors[] = 'Akun dibuat, tetapi file kunci config/installed.lock gagal ditulis. Hapus setup_admin.php secara manual.';
            } catch (Throwable $ex) {
                if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
                error_log('setup_admin: ' . $ex->getMessage());
                $errors[] = 'Akun gagal dibuat (username/email mungkin sudah dipakai).';
            }
        }
    }
}
$closed = ($locked || $hasAdmin) && !$done;
?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex, nofollow">
<title>Setup Admin | <?= e(setting('school_name', 'SMK INFOKOM BOGOR')) ?></title>
<link rel="stylesheet" href="<?= asset('vendor/bootstrap/bootstrap.min.css') ?>"><link rel="stylesheet" href="<?= asset('vendor/fontawesome/css/all.min.css') ?>"><link rel="stylesheet" href="<?= asset('css/admin.css') ?>?v=4"></head>
<body class="login-body"><div class="login-bg"></div>
<main class="login-wrap"><div class="login-card" style="max-width:520px">
    <div class="text-center mb-3"><img src="<?= e(logo_url()) ?>" width="84" height="84" alt="Logo" class="login-logo"><h1 class="h4 mt-3">Setup Akun Admin Pertama</h1></div>
    <?php if ($dbError): ?>
        <div class="alert alert-danger"><i class="fa-solid fa-database me-1"></i> <?= e($dbError) ?></div>
    <?php elseif ($done): ?>
        <div class="alert alert-success"><i class="fa-solid fa-circle-check me-1"></i> Akun admin berhasil dibuat dan setup dikunci.</div>
        <?php foreach ($errors as $e): ?><div class="alert alert-warning small"><?= e($e) ?></div><?php endforeach; ?>
        <div class="alert alert-warning small"><strong>Penting:</strong> hapus file <code>setup_admin.php</code> dari server sebelum website dipublikasikan.</div>
        <a class="btn btn-login w-100" href="<?= admin_url('login.php') ?>">Lanjut ke Login Admin</a>
    <?php elseif ($closed): ?>
        <div class="alert alert-secondary"><i class="fa-solid fa-lock me-1"></i> Setup sudah selesai dan dikunci. Halaman ini tidak dapat digunakan lagi. Silakan hapus file <code>setup_admin.php</code>.</div>
        <a class="btn btn-login w-100" href="<?= admin_url('login.php') ?>">Ke Login Admin</a>
    <?php else: ?>
        <p class="text-muted small">Buat akun admin dengan password milik Anda sendiri. Tidak ada akun bawaan. Password disimpan dalam bentuk hash.</p>
        <?php if ($errors): ?><div class="alert alert-danger small"><ul class="mb-0 ps-3"><?php foreach ($errors as $e) echo '<li>' . e($e) . '</li>'; ?></ul></div><?php endif; ?>
        <form method="post" novalidate autocomplete="off" data-once><?= csrf_field() ?>
            <div class="mb-3"><label class="form-label fw-semibold" for="full_name">Nama Lengkap</label><input class="form-control" id="full_name" name="full_name" value="<?= e($old['full_name']) ?>" required maxlength="120"></div>
            <div class="mb-3"><label class="form-label fw-semibold" for="username">Username</label><input class="form-control" id="username" name="username" value="<?= e($old['username']) ?>" required maxlength="50" autocomplete="off"></div>
            <div class="mb-3"><label class="form-label fw-semibold" for="email">Email</label><input type="email" class="form-control" id="email" name="email" value="<?= e($old['email']) ?>" required maxlength="120"></div>
            <div class="mb-3"><label class="form-label fw-semibold" for="password">Password (min. 8 karakter, huruf + angka)</label><input type="password" class="form-control" id="password" name="password" required autocomplete="new-password"></div>
            <div class="mb-4"><label class="form-label fw-semibold" for="password2">Ulangi Password</label><input type="password" class="form-control" id="password2" name="password2" required autocomplete="new-password"></div>
            <button class="btn btn-login w-100" type="submit"><i class="fa-solid fa-user-shield me-2"></i>Buat Akun Admin</button>
        </form>
    <?php endif; ?>
</div></main>
<script>document.querySelectorAll('form[data-once]').forEach(function(f){f.addEventListener('submit',function(){var b=f.querySelector('button[type=submit]');if(b){b.disabled=true;b.innerHTML='<span class="spinner-border spinner-border-sm me-2"></span>Memproses...';}});});</script>
</body></html>
