<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/components.php';

$cats = q_all('SELECT * FROM gallery_categories ORDER BY id');
$cat = trim(get_str('kategori',''));
$where = 'g.is_published = 1'; $par = []; $catName = '';
if ($cat !== '') { $where .= ' AND c.slug = ?'; $par[] = $cat; foreach ($cats as $c) if ($c['slug'] === $cat) $catName = $c['name']; }
$total = (int)q_val("SELECT COUNT(*) FROM gallery g LEFT JOIN gallery_categories c ON c.id = g.category_id WHERE $where", $par);
$pg = paginate($total, 12, (int)get_str('page','1'));
$rows = q_all("SELECT g.*, c.name AS category_name FROM gallery g LEFT JOIN gallery_categories c ON c.id = g.category_id WHERE $where ORDER BY g.created_at DESC, g.id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $par);

$pageTitle = 'Galeri' . ($catName ? ' - ' . $catName : '');
$metaDesc  = 'Galeri foto dan dokumentasi kegiatan ' . setting('school_name') . '.';
require __DIR__ . '/includes/header.php';
page_banner('Galeri', [], 'Dokumentasi kegiatan dan fasilitas sekolah');
?>
<div class="container py-5">
    <div class="filter-pills">
        <a href="galeri.php" class="<?= $cat === '' ? 'active' : '' ?>">Semua</a>
        <?php foreach ($cats as $c): ?><a href="?kategori=<?= e(urlencode($c['slug'])) ?>" class="<?= $cat === $c['slug'] ? 'active' : '' ?>"><?= e($c['name']) ?></a><?php endforeach; ?>
    </div>
    <?php if (!$rows): echo empty_state('Belum ada foto pada kategori ini.'); else: ?>
    <div class="row g-3">
        <?php foreach ($rows as $g): ?>
        <div class="col-6 col-md-4 col-lg-3">
            <a class="gal-item" href="<?= e(img_url($g['image'])) ?>" data-lightbox data-title="<?= e($g['title']) ?>" data-caption="<?= e(trim(($g['category_name'] ? $g['category_name'] . ' - ' : '') . tgl_indo($g['created_at']) . ($g['caption'] ? ' - ' . $g['caption'] : ''))) ?>">
                <img src="<?= e(img_url($g['image'])) ?>" alt="<?= e($g['title']) ?>" loading="lazy"><span class="zoom"><i class="fa-solid fa-magnifying-glass-plus"></i></span><span class="ov"><?= e($g['title']) ?></span>
            </a>
            <div class="small mt-2"><strong><?= e($g['title']) ?></strong><div class="meta"><?= e($g['category_name'] ?: 'Umum') ?> &bull; <?= e(tgl_indo($g['created_at'])) ?></div></div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="mt-5"><?= pagination_html($pg, ['kategori' => $cat]) ?></div>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
