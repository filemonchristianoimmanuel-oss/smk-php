<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/components.php';

$tabs = [
    'program' => 'Program Keahlian', 'kurikulum' => 'Kurikulum', 'kalender' => 'Kalender Pendidikan', 'pkl' => 'PKL',
    'bkk' => 'BKK', 'luar-negeri' => 'Kerja ke Luar Negeri', 'jepang' => 'Kerja ke Jepang',
];
$titles = [
    'program' => 'Program Keahlian', 'kurikulum' => 'Kurikulum', 'kalender' => 'Kalender Pendidikan',
    'pkl' => 'Praktik Kerja Lapangan (PKL)', 'bkk' => 'Bursa Kerja Khusus (BKK)',
    'luar-negeri' => 'Program Kerja ke Luar Negeri', 'jepang' => 'Program Kerja ke Jepang',
];
$s = get_str('s','program');
if (!isset($tabs[$s])) show_404();

$pageTitle = $titles[$s];
$metaDesc  = 'Informasi akademik ' . setting('school_name') . ': ' . $titles[$s] . '.';
require __DIR__ . '/includes/header.php';
page_banner($titles[$s], ['Akademik' => 'akademik.php?s=program']);
echo sub_nav($tabs, $s, 'akademik.php');
?>
<div class="container py-5">
<?php
switch ($s) {
    case 'program':
        $rows = q_all('SELECT * FROM study_programs WHERE is_published = 1 ORDER BY sort_order, id');
        if (!$rows) { echo empty_state('Program keahlian belum ditambahkan.'); break; }
        echo '<div class="row g-4 justify-content-center">';
        foreach ($rows as $p) {
            $link = url('program-detail.php?slug=' . urlencode($p['slug']));
            echo '<div class="col-md-6 col-lg-4"><div class="card-x prog-card">';
            if ($p['image']) echo '<img src="' . e(img_url($p['image'])) . '" alt="' . e($p['name']) . '" class="rounded-4 mb-3" style="aspect-ratio:16/10;object-fit:cover;width:100%" loading="lazy">';
            else echo '<div class="prog-icon"><i class="' . e($p['icon']) . '"></i></div>';
            if ($p['short_name']) echo '<span class="prog-short">' . e($p['short_name']) . '</span>';
            echo '<h3>' . e($p['name']) . '</h3><p>' . e(excerpt($p['description'], 150)) . '</p>';
            if ($p['competencies']) echo '<p class="small text-start"><strong class="text-primary">Kompetensi:</strong> ' . e(excerpt(str_replace(["\n", '- '], [', ', ''], $p['competencies']), 90)) . '</p>';
            echo '<a href="' . e($link) . '" class="btn btn-blue btn-sm mt-auto">Detail Program</a></div></div>';
        }
        echo '</div>';
        break;

    case 'kurikulum':
        $rows = q_all('SELECT * FROM curriculum WHERE is_published = 1 ORDER BY FIELD(category,"informasi","program","kegiatan","pendukung"), sort_order, id');
        $labels = ['informasi' => ['Kurikulum yang Diterapkan', 'fa-book-open'], 'program' => ['Program Pembelajaran', 'fa-list-check'], 'kegiatan' => ['Kegiatan Pembelajaran', 'fa-person-chalkboard'], 'pendukung' => ['Informasi Pendukung Akademik', 'fa-circle-info']];
        if (!$rows) { echo empty_state('Informasi kurikulum belum diisi.'); break; }
        foreach ($labels as $k => $l) {
            $items = array_filter($rows, fn($r) => $r['category'] === $k);
            if (!$items) continue;
            echo '<section class="block-section"><h3 class="block-title"><i class="fa-solid ' . $l[1] . '"></i> ' . e($l[0]) . '</h3>';
            foreach ($items as $i) echo '<div class="content-block"><h4>' . e($i['title']) . '</h4>' . format_text($i['content']) . '</div>';
            echo '</section>';
        }
        break;

    case 'kalender':
        $cats = ['hari_efektif' => ['Hari Efektif', 'success'], 'libur' => ['Libur Sekolah', 'danger'], 'ujian' => ['Ujian', 'warning text-dark'], 'akademik' => ['Kegiatan Akademik', 'primary'], 'ppdb' => ['Penerimaan Siswa Baru', 'info text-dark']];
        $years = array_column(q_all('SELECT DISTINCT academic_year FROM academic_calendar WHERE is_published = 1 ORDER BY academic_year DESC'), 'academic_year');
        $year = in_array(get_str('year',''), $years, true) ? get_str('year') : ($years[0] ?? '');
        $cat  = isset($cats[get_str('cat','')]) ? get_str('cat') : '';
        $sql = 'SELECT * FROM academic_calendar WHERE is_published = 1 AND academic_year = ?'; $par = [$year];
        if ($cat) { $sql .= ' AND category = ?'; $par[] = $cat; }
        $rows = q_all($sql . ' ORDER BY start_date, id', $par);
        echo '<form class="row g-2 justify-content-center mb-4" method="get"><input type="hidden" name="s" value="kalender">'
           . '<div class="col-auto"><select name="year" class="form-select" aria-label="Tahun ajaran" onchange="this.form.submit()">';
        foreach ($years as $y) echo '<option ' . ($y === $year ? 'selected' : '') . '>' . e($y) . '</option>';
        echo '</select></div><div class="col-auto"><select name="cat" class="form-select" aria-label="Kategori" onchange="this.form.submit()"><option value="">Semua kategori</option>';
        foreach ($cats as $k => $c) echo '<option value="' . $k . '" ' . ($k === $cat ? 'selected' : '') . '>' . e($c[0]) . '</option>';
        echo '</select></div><noscript><div class="col-auto"><button class="btn btn-blue">Terapkan</button></div></noscript></form>';
        if (!$rows) { echo empty_state('Belum ada data kalender untuk pilihan ini.'); break; }
        $byMonth = [];
        foreach ($rows as $r) $byMonth[date('Y-m', strtotime($r['start_date']))][] = $r;
        foreach ($byMonth as $ym => $list) {
            echo '<div class="ppdb-card mb-4"><h3>' . e(bulan_id((int)substr($ym, 5, 2)) . ' ' . substr($ym, 0, 4)) . '</h3><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Tanggal</th><th>Kegiatan</th><th>Kategori</th></tr></thead><tbody>';
            foreach ($list as $r) {
                $d = tgl_indo($r['start_date']);
                if ($r['end_date'] && $r['end_date'] !== $r['start_date']) $d .= ' - ' . tgl_indo($r['end_date']);
                echo '<tr><td class="text-nowrap fw-bold text-primary">' . e($d) . '</td><td>' . e($r['title']) . ($r['description'] ? '<br><small class="text-muted">' . e($r['description']) . '</small>' : '') . '</td><td><span class="badge bg-' . $cats[$r['category']][1] . '">' . e($cats[$r['category']][0]) . '</span></td></tr>';
            }
            echo '</tbody></table></div></div>';
        }
        break;

    case 'pkl':
        $rows = q_all('SELECT * FROM internship_information WHERE is_published = 1 ORDER BY sort_order, id');
        render_blocks($rows, [
            'pengertian' => ['label' => 'Pengertian PKL', 'icon' => 'fa-circle-question'],
            'tujuan' => ['label' => 'Tujuan PKL', 'icon' => 'fa-bullseye'],
            'tahapan' => ['label' => 'Tahapan PKL', 'icon' => 'fa-stairs', 'style' => 'steps'],
            'mitra' => ['label' => 'Mitra Industri', 'icon' => 'fa-handshake', 'style' => 'cards'],
            'dokumentasi' => ['label' => 'Dokumentasi Kegiatan PKL', 'icon' => 'fa-camera', 'style' => 'gallery'],
            'pengumuman' => ['label' => 'Pengumuman PKL', 'icon' => 'fa-bullhorn'],
        ]);
        break;

    case 'bkk':
        $rows = q_all('SELECT * FROM job_center WHERE is_published = 1 ORDER BY sort_order, id');
        render_blocks($rows, [
            'informasi' => ['label' => 'Informasi BKK', 'icon' => 'fa-circle-info'],
            'layanan' => ['label' => 'Layanan Penempatan Kerja', 'icon' => 'fa-people-arrows'],
            'lowongan' => ['label' => 'Informasi Lowongan Kerja', 'icon' => 'fa-briefcase', 'style' => 'cards'],
            'mitra' => ['label' => 'Perusahaan Mitra', 'icon' => 'fa-building', 'style' => 'cards'],
            'persyaratan' => ['label' => 'Persyaratan Pendaftaran', 'icon' => 'fa-clipboard-check'],
            'kontak' => ['label' => 'Kontak BKK', 'icon' => 'fa-phone'],
        ]);
        break;

    case 'luar-negeri':
    case 'jepang':
        $prog = $s === 'jepang' ? 'jepang' : 'luar_negeri';
        $rows = q_all('SELECT * FROM overseas_programs WHERE is_published = 1 AND program = ? ORDER BY sort_order, id', [$prog]);
        render_blocks($rows, [
            'penjelasan' => ['label' => 'Penjelasan Program', 'icon' => 'fa-circle-info'],
            'tujuan' => ['label' => 'Tujuan Program', 'icon' => 'fa-bullseye'],
            'persyaratan' => ['label' => 'Persyaratan', 'icon' => 'fa-clipboard-check'],
            'seleksi' => ['label' => 'Tahapan Seleksi', 'icon' => 'fa-filter'],
            'pelatihan' => ['label' => 'Pelatihan Bahasa', 'icon' => 'fa-language'],
            'pembekalan' => ['label' => 'Informasi Pembekalan', 'icon' => 'fa-suitcase'],
            'dokumentasi' => ['label' => 'Dokumentasi', 'icon' => 'fa-camera', 'style' => 'gallery'],
            'kontak' => ['label' => 'Kontak yang Dapat Dihubungi', 'icon' => 'fa-phone'],
        ]);
        if ($s === 'luar-negeri') echo '<div class="text-center mt-4"><a class="btn btn-gold" href="' . url('akademik.php?s=jepang') . '"><i class="fa-solid fa-torii-gate me-2"></i>Lihat Program Kerja ke Jepang</a></div>';
        echo '<div class="alert alert-warning mt-4 small"><i class="fa-solid fa-triangle-exclamation me-1"></i> Informasi keberangkatan hanya dianggap resmi jika diumumkan oleh sekolah dan lembaga penyalur yang sah. Konfirmasi ke sekolah sebelum mendaftar.</div>';
        break;
}
?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
