<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/components.php';

$greet     = q_one('SELECT * FROM principal_greetings WHERE is_active = 1 ORDER BY id DESC LIMIT 1');
$programs  = q_all('SELECT * FROM study_programs WHERE is_published = 1 ORDER BY sort_order, id LIMIT 6');
$facilities= q_all('SELECT * FROM school_facilities WHERE is_published = 1 ORDER BY sort_order, id LIMIT 6');
$news      = q_all('SELECT n.*, c.name AS category_name FROM news n LEFT JOIN news_categories c ON c.id = n.category_id WHERE ' . published_news_sql() . ' ORDER BY n.published_at DESC LIMIT 3');
$gallery   = q_all('SELECT g.*, c.name AS category_name FROM gallery g LEFT JOIN gallery_categories c ON c.id = g.category_id WHERE g.is_published = 1 ORDER BY g.created_at DESC, g.id DESC LIMIT 8');
$agendas   = q_all('SELECT * FROM agendas WHERE is_published = 1 AND COALESCE(end_date, event_date) >= CURDATE() ORDER BY event_date, start_time LIMIT 3');
$hasPhoto  = setting('hero_image') !== '' && is_file(ROOT_PATH . '/' . setting('hero_image'));

$stats = [
    ['fa-user-graduate', 'stat_students', 'Jumlah Siswa'],
    ['fa-chalkboard-user', 'stat_teachers', 'Jumlah Guru'],
    ['fa-people-roof', 'stat_classgroups', 'Rombongan Belajar'],
    ['fa-door-open', 'stat_classrooms', 'Ruang Kelas'],
];
if ((int)setting('stat_labs', '0') > 0) $stats[] = ['fa-computer', 'stat_labs', 'Laboratorium'];

$pageTitle = '';
$bodyClass = 'page-home';
require __DIR__ . '/includes/header.php';
?>

<!-- HERO -->
<section class="hero <?= $hasPhoto ? 'has-photo' : '' ?>" <?= $hasPhoto ? 'style="--hero-img:url(\'' . e(url(setting('hero_image'))) . '\')"' : '' ?>>
    <?php if ($hasPhoto): ?><div style="position:absolute;inset:0;background:url('<?= e(url(setting('hero_image'))) ?>') center/cover;opacity:.3"></div><?php endif; ?>
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-7">
                <span class="hero-badge"><i class="fa-solid fa-fire-flame-curved"></i> <?= e(setting('school_fullname')) ?> &bull; Akreditasi <?= e(setting('accreditation', 'A')) ?></span>
                <h1><span class="school"><?= e(setting('school_name')) ?></span><?= e(setting('hero_title')) ?></h1>
                <p class="lead"><?= e(setting('hero_subtitle')) ?></p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="<?= url('profil.php') ?>" class="btn btn-outline-light-x"><i class="fa-solid fa-school me-2"></i>Lihat Profil Sekolah</a>
                    <a href="<?= url('ppdb.php') ?>" class="btn btn-gold"><i class="fa-solid fa-user-plus me-2"></i>PPDB ONLINE</a>
                </div>
            </div>
            <div class="col-lg-5 text-center d-none d-lg-block">
                <img class="hero-logo" src="<?= e(logo_url()) ?>" alt="Logo <?= e(setting('school_name')) ?>">
            </div>
        </div>
    </div>
    <div class="hero-wave"><svg viewBox="0 0 1440 60" preserveAspectRatio="none"><path d="M0,40 C240,70 480,0 720,20 C960,40 1200,70 1440,30 L1440,60 L0,60Z" fill="#fff"/></svg></div>
</section>

<!-- SAMBUTAN -->
<?php if ($greet): ?>
<section class="section">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-5">
                <div class="greet-photo"><img src="<?= e(img_url($greet['photo'], 'photo')) ?>" alt="Foto <?= e($greet['name']) ?>" loading="lazy"></div>
            </div>
            <div class="col-lg-7">
                <?= section_title($greet['title'], '', false) ?>
                <div class="quote-box rich"><?= format_text(excerpt($greet['content'], 520)) ?></div>
                <h3 class="greet-name h5 mt-3"><?= e($greet['name']) ?></h3>
                <p class="greet-pos mb-3"><?= e($greet['position']) ?></p>
                <a href="<?= url('profil.php?s=sambutan') ?>" class="btn btn-blue">Baca Selengkapnya <i class="fa-solid fa-arrow-right ms-1"></i></a>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- PROFIL SINGKAT -->
<section class="section section-soft">
    <div class="container">
        <?= section_title('Profil Singkat Sekolah', 'Mengenal lebih dekat ' . setting('school_name')) ?>
        <div class="row g-4">
            <div class="col-lg-7">
                <div class="ppdb-card rich">
                    <h3><i class="fa-solid fa-landmark"></i> Tentang Sekolah</h3>
                    <?= format_text(setting('profile_summary')) ?>
                    <?php $hist = q_one('SELECT * FROM school_history WHERE is_published = 1 ORDER BY sort_order, id LIMIT 1');
                    if ($hist): ?><p class="mb-3"><?= e(excerpt($hist['content'], 220)) ?></p><?php endif; ?>
                    <a href="<?= url('profil.php?s=sejarah') ?>" class="btn btn-outline-blue btn-sm">Sejarah Sekolah</a>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="ppdb-card">
                    <h3><i class="fa-solid fa-id-card"></i> Identitas</h3>
                    <ul class="info-list">
                        <li><span class="ic"><i class="fa-solid fa-hashtag"></i></span><div><span class="lb">NPSN</span><span class="vl"><?= e(setting('npsn')) ?></span></div></li>
                        <li><span class="ic"><i class="fa-solid fa-award"></i></span><div><span class="lb">Akreditasi</span><span class="vl"><?= e(setting('accreditation')) ?></span></div></li>
                        <li><span class="ic"><i class="fa-solid fa-location-dot"></i></span><div><span class="lb">Alamat</span><span class="vl"><?= e(setting('address')) ?></span></div></li>
                        <li><span class="ic"><i class="fa-solid fa-phone"></i></span><div><span class="lb">Telepon / Email</span><span class="vl"><?= e(setting('phone')) ?> &bull; <?= e(setting('email')) ?></span></div></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- STATISTIK -->
<section class="stat-wrap" aria-label="Statistik sekolah">
    <div class="container">
        <div class="row g-3 justify-content-center">
            <?php foreach ($stats as $s): ?>
                <div class="col-6 col-md-3 <?= count($stats) > 4 ? 'col-lg' : '' ?>">
                    <div class="stat-card"><i class="fa-solid <?= $s[0] ?> d-block"></i><div class="num" data-count="<?= (int)setting($s[1], '0') ?>"><?= number_format((int)setting($s[1], '0'), 0, ',', '.') ?></div><div class="lbl"><?= e($s[2]) ?></div></div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php if (setting('stat_note') !== ''): ?><p class="stat-note"><i class="fa-solid fa-circle-info"></i> <?= e(setting('stat_note')) ?></p><?php endif; ?>
    </div>
</section>

<!-- PROGRAM KEAHLIAN -->
<section class="section">
    <div class="container">
        <?= section_title('Program Keahlian', 'Pilih jurusan yang sesuai dengan minat dan bakat Anda') ?>
        <?php if (!$programs): echo empty_state('Program keahlian belum ditambahkan.'); else: ?>
        <div class="row g-4 justify-content-center">
            <?php foreach ($programs as $p): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card-x prog-card">
                        <div class="prog-icon"><i class="<?= e($p['icon']) ?>"></i></div>
                        <?php if ($p['short_name']): ?><span class="prog-short"><?= e($p['short_name']) ?></span><?php endif; ?>
                        <h3><?= e($p['name']) ?></h3>
                        <p><?= e(excerpt($p['description'], 120)) ?></p>
                        <a href="<?= url('program-detail.php?slug=' . urlencode($p['slug'])) ?>" class="btn btn-outline-blue btn-sm mt-auto">Detail <i class="fa-solid fa-arrow-right ms-1"></i></a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- FASILITAS -->
<section class="section section-soft">
    <div class="container">
        <?= section_title('Fasilitas Sekolah', 'Sarana pendukung kegiatan belajar dan praktik siswa') ?>
        <?php if (!$facilities): echo empty_state('Fasilitas belum ditambahkan.'); else: ?>
        <div class="row g-4">
            <?php foreach ($facilities as $f): ?>
                <div class="col-sm-6 col-lg-4">
                    <a class="fac-card" href="<?= url('profil.php?s=fasilitas') ?>"><img src="<?= e(img_url($f['image'])) ?>" alt="<?= e($f['name']) ?>" loading="lazy"><div class="fac-cap"><h3><?= e($f['name']) ?></h3><p><?= e(excerpt($f['description'], 70)) ?></p></div></a>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-4"><a class="btn btn-blue" href="<?= url('profil.php?s=fasilitas') ?>">Semua Fasilitas</a></div>
        <?php endif; ?>
    </div>
</section>

<!-- BERITA -->
<section class="section">
    <div class="container">
        <?= section_title('Berita Terbaru', 'Informasi dan kegiatan terkini dari sekolah') ?>
        <?php if (!$news): echo empty_state('Belum ada berita yang diterbitkan.'); else: ?>
        <div class="row g-4">
            <?php foreach ($news as $n): ?><div class="col-md-6 col-lg-4"><?= news_card($n) ?></div><?php endforeach; ?>
        </div>
        <div class="text-center mt-4"><a class="btn btn-blue" href="<?= url('berita.php') ?>">Semua Berita</a></div>
        <?php endif; ?>
    </div>
</section>

<!-- GALERI -->
<section class="section section-soft">
    <div class="container">
        <?= section_title('Galeri Kegiatan', 'Dokumentasi kegiatan SMK INFOKOM BOGOR') ?>
        <?php if (!$gallery): echo empty_state('Galeri belum berisi foto.'); else: ?>
        <div class="row g-3">
            <?php foreach ($gallery as $i => $g): ?>
                <div class="col-6 col-md-3">
                    <a class="gal-item" href="<?= e(img_url($g['image'])) ?>" data-lightbox data-title="<?= e($g['title']) ?>" data-caption="<?= e($g['caption']) ?>">
                        <img src="<?= e(img_url($g['image'])) ?>" alt="<?= e($g['title']) ?>" loading="lazy"><span class="zoom"><i class="fa-solid fa-magnifying-glass-plus"></i></span><span class="ov"><?= e($g['title']) ?></span>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-4"><a class="btn btn-blue" href="<?= url('galeri.php') ?>">Buka Galeri</a></div>
        <?php endif; ?>
    </div>
</section>

<!-- AGENDA -->
<section class="section">
    <div class="container">
        <?= section_title('Agenda Sekolah', 'Kegiatan yang akan datang') ?>
        <?php if (!$agendas): echo empty_state('Belum ada agenda mendatang.'); else: ?>
        <div class="row g-4">
            <?php foreach ($agendas as $a): ?><div class="col-lg-4"><?= agenda_card($a) ?></div><?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="text-center mt-4"><a class="btn btn-blue" href="<?= url('agenda.php') ?>">Semua Agenda</a></div>
    </div>
</section>

<!-- CTA PPDB -->
<section class="cta">
    <div class="container">
        <h2><?= (int)setting("ppdb_open","1") === 1 ? "PPDB Online <span>" . e(setting("ppdb_year")) . "</span> Telah Dibuka" : "Informasi <span>PPDB " . e(setting("ppdb_year")) . "</span>" ?></h2>
        <p><?= e(setting('ppdb_cta_text')) ?></p>
        <a class="btn btn-gold btn-lg" href="<?= url('ppdb.php#formulir') ?>"><i class="fa-solid fa-pen-to-square me-2"></i>Daftar Sekarang</a>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
