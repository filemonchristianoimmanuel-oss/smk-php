<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/components.php';

$old = []; $errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $back = url('kontak.php#form-pesan');
    if (!csrf_valid()) { flash('danger', 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.'); redirect($back); }
    if (!empty($_POST['website_url'])) redirect(url('kontak.php'));
    if (rate_limited('contact_submit', 3, 600)) { flash('danger', 'Terlalu banyak pesan dalam waktu singkat. Coba lagi nanti.'); redirect($back); }
    $old = ['name' => trim((string)($_POST['name'] ?? '')), 'email' => trim((string)($_POST['email'] ?? '')), 'subject' => trim((string)($_POST['subject'] ?? '')), 'message' => trim((string)($_POST['message'] ?? ''))];
    if (mb_strlen($old['name']) < 2 || mb_strlen($old['name']) > 120) $errors['name'] = 'Nama wajib diisi (2-120 karakter).';
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($old['email']) > 120) $errors['email'] = 'Alamat email tidak valid.';
    if (mb_strlen($old['subject']) < 3 || mb_strlen($old['subject']) > 200) $errors['subject'] = 'Subjek wajib diisi (3-200 karakter).';
    if (mb_strlen($old['message']) < 10 || mb_strlen($old['message']) > 3000) $errors['message'] = 'Pesan wajib diisi (10-3000 karakter).';
    if (!$errors) {
        try {
            q_exec('INSERT INTO contact_messages (name, email, subject, message, ip_address) VALUES (?,?,?,?,?)', [$old['name'], $old['email'], $old['subject'], $old['message'], client_ip()]);
            flash('success', 'Pesan Anda berhasil dikirim. Terima kasih, kami akan menindaklanjuti secepatnya.');
            redirect(url('kontak.php#form-pesan'));
        } catch (Throwable $ex) {
            error_log('contact insert: ' . $ex->getMessage());
            flash('danger', 'Pesan gagal dikirim karena kendala sistem. Silakan coba lagi.');
        }
    } else flash('danger', 'Pesan belum terkirim. Periksa kolom yang ditandai merah.');
}
$inv = fn($k) => isset($errors[$k]) ? ' is-invalid' : '';
$err = fn($k) => isset($errors[$k]) ? '<div class="invalid-feedback">' . e($errors[$k]) . '</div>' : '';
$mapUrl = setting('map_url');
$mapOk = (bool)preg_match('#^https://(www\.google\.com/maps|maps\.google\.com|www\.openstreetmap\.org)/#', $mapUrl);
$socials = q_all('SELECT * FROM social_links WHERE is_active = 1 ORDER BY sort_order, id');

$pageTitle = 'Kontak';
$metaDesc  = 'Hubungi ' . setting('school_name') . ': alamat, telepon, email, peta lokasi, dan formulir pesan.';
require __DIR__ . '/includes/header.php';
page_banner('Kontak', [], 'Kami siap membantu Anda');
?>
<div class="container py-5">
    <div class="row g-4 mb-5 justify-content-center">
        <?php foreach ([['fa-location-dot', 'Alamat', setting('address'), ''], ['fa-phone', 'Telepon', setting('phone'), 'tel:' . preg_replace('/[^0-9+]/', '', setting('phone'))], ['fa-envelope', 'Email', setting('email'), 'mailto:' . setting('email')], ['fa-globe', 'Website Resmi', setting('website'), preg_match('#^https?://#', setting('website')) ? setting('website') : 'https://' . setting('website')], ['fa-clock', 'Jam Layanan', setting('service_hours'), '']] as $c): if ($c[2] === '') continue; ?>
        <div class="col-sm-6 col-lg-4 col-xl"><div class="contact-card"><div class="ic"><i class="fa-solid <?= $c[0] ?>"></i></div><h3 class="h6 fw-bold"><?= $c[1] ?></h3>
            <?php if ($c[3]): ?><a href="<?= e($c[3]) ?>" <?= strpos($c[3], 'http') === 0 ? 'target="_blank" rel="noopener noreferrer"' : '' ?> class="small text-break"><?= e($c[2]) ?></a><?php else: ?><span class="small"><?= e($c[2]) ?></span><?php endif; ?></div></div>
        <?php endforeach; ?>
    </div>
    <div class="row g-5">
        <div class="col-lg-6">
            <?= section_title('Lokasi Sekolah', '', false) ?>
            <?php if ($mapOk): ?><iframe class="map-frame" src="<?= e($mapUrl) ?>" title="Peta lokasi <?= e(setting('school_name')) ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
            <?php else: echo empty_state('Peta belum diatur.'); endif; ?>
            <p class="small mt-2"><a target="_blank" rel="noopener noreferrer" href="https://www.google.com/maps/search/?api=1&query=<?= urlencode(setting('address')) ?>"><i class="fa-solid fa-diamond-turn-right me-1"></i>Buka di Google Maps</a></p>
            <?php if ($socials): ?><h3 class="h6 fw-bold mt-4">Media Sosial</h3><div class="d-flex gap-2"><?php foreach ($socials as $s): ?><a class="social-btn" style="background:var(--blue)" href="<?= e($s['url']) ?>" target="_blank" rel="noopener noreferrer" aria-label="<?= e($s['platform']) ?>"><i class="<?= e($s['icon']) ?>"></i></a><?php endforeach; ?></div><?php endif; ?>
        </div>
        <div class="col-lg-6" id="form-pesan">
            <?= section_title('Kirim Pesan', '', false) ?>
            <?= flash_render() ?>
            <div class="form-card"><form method="post" action="<?= url('kontak.php#form-pesan') ?>" novalidate data-once>
                <?= csrf_field() ?><div class="hp-field" aria-hidden="true"><label>Jangan diisi<input type="text" name="website_url" tabindex="-1" autocomplete="off"></label></div>
                <div class="mb-3"><label class="form-label" for="name">Nama <span class="req">*</span></label><input class="form-control<?= $inv('name') ?>" id="name" name="name" maxlength="120" value="<?= e($old['name'] ?? '') ?>" required><?= $err('name') ?></div>
                <div class="mb-3"><label class="form-label" for="email">Email <span class="req">*</span></label><input type="email" class="form-control<?= $inv('email') ?>" id="email" name="email" maxlength="120" value="<?= e($old['email'] ?? '') ?>" required><?= $err('email') ?></div>
                <div class="mb-3"><label class="form-label" for="subject">Subjek <span class="req">*</span></label><input class="form-control<?= $inv('subject') ?>" id="subject" name="subject" maxlength="200" value="<?= e($old['subject'] ?? '') ?>" required><?= $err('subject') ?></div>
                <div class="mb-3"><label class="form-label" for="message">Isi Pesan <span class="req">*</span></label><textarea class="form-control<?= $inv('message') ?>" id="message" name="message" rows="5" maxlength="3000" required><?= e($old['message'] ?? '') ?></textarea><?= $err('message') ?></div>
                <button class="btn btn-blue w-100" type="submit"><i class="fa-solid fa-paper-plane me-2"></i>Kirim Pesan</button>
            </form></div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
