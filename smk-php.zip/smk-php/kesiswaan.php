<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/components.php';

$tabs = ['beranda' => 'Beranda Kesiswaan', 'osis' => 'OSIS', 'ekskul' => 'Ekstrakurikuler', 'prestasi' => 'Prestasi Siswa', 'kegiatan' => 'Kegiatan Siswa', 'tata-tertib' => 'Tata Tertib'];
$s = get_str('s','beranda');
if (!isset($tabs[$s])) show_404();
$pageTitle = $tabs[$s];
$metaDesc  = 'Kesiswaan ' . setting('school_name') . ': ' . $tabs[$s] . '.';
require __DIR__ . '/includes/header.php';
page_banner($tabs[$s], $s === 'beranda' ? [] : ['Kesiswaan' => 'kesiswaan.php?s=beranda']);
echo sub_nav($tabs, $s, 'kesiswaan.php');
?>
<div class="container py-5">
<?php
$levels = ['sekolah' => 'Sekolah', 'kecamatan' => 'Kecamatan', 'kota' => 'Kota', 'provinsi' => 'Provinsi', 'nasional' => 'Nasional', 'internasional' => 'Internasional'];
switch ($s) {
    case 'beranda':
        $rows = q_all('SELECT * FROM student_affairs WHERE is_published = 1 ORDER BY sort_order, id');
        render_blocks($rows, [
            'informasi' => ['label' => 'Informasi Umum Kesiswaan', 'icon' => 'fa-circle-info'],
            'pembinaan' => ['label' => 'Program Pembinaan Siswa', 'icon' => 'fa-seedling', 'style' => 'cards'],
            'dokumentasi' => ['label' => 'Dokumentasi Kegiatan', 'icon' => 'fa-camera', 'style' => 'gallery'],
        ]);
        break;

    case 'osis':
        $rows = q_all('SELECT * FROM student_organizations WHERE is_published = 1 ORDER BY sort_order, id');
        $struktur = array_values(array_filter($rows, fn($r) => $r['section'] === 'struktur'));
        $rest = array_filter($rows, fn($r) => $r['section'] !== 'struktur');
        $rows2 = array_map(fn($r) => $r + ['company' => $r['subtitle']], $rest);
        render_blocks(array_filter($rows2, fn($r) => $r['section'] === 'informasi'), ['informasi' => ['label' => 'Informasi OSIS', 'icon' => 'fa-circle-info']]);
        echo '<section class="block-section"><h3 class="block-title"><i class="fa-solid fa-sitemap"></i> Struktur Organisasi OSIS</h3>';
        if (!$struktur) echo empty_state('Struktur OSIS belum diisi.');
        else { echo '<div class="org-level">'; foreach ($struktur as $o) echo '<div class="org-box"><span class="org-pos">' . e($o['title']) . '</span>' . ($o['subtitle'] ? '<strong>' . e($o['subtitle']) . '</strong>' : '') . ($o['content'] ? '<small>' . e($o['content']) . '</small>' : '') . '</div>'; echo '</div>'; }
        echo '</section>';
        $prog = array_filter($rows2, fn($r) => $r['section'] === 'program');
        if ($prog) render_blocks($prog, ['program' => ['label' => 'Program Kerja OSIS', 'icon' => 'fa-list-check']]);
        $dok = array_filter($rows2, fn($r) => $r['section'] === 'dokumentasi');
        if ($dok) render_blocks($dok, ['dokumentasi' => ['label' => 'Dokumentasi Kegiatan OSIS', 'icon' => 'fa-camera', 'style' => 'gallery']]);
        break;

    case 'ekskul':
        $rows = q_all('SELECT * FROM extracurriculars WHERE is_published = 1 ORDER BY sort_order, id');
        if (!$rows) { echo empty_state('Data ekstrakurikuler belum tersedia.'); break; }
        echo '<div class="row g-4 justify-content-center">';
        foreach ($rows as $r) {
            echo '<div class="col-md-6 col-lg-4"><div class="card-x h-100"><div class="card-img-wrap"><img src="' . e(img_url($r['image'])) . '" alt="' . e($r['name']) . '" loading="lazy"></div><div class="card-body-x"><h3>' . e($r['name']) . '</h3><p>' . e($r['description']) . '</p><ul class="list-unstyled small mt-auto mb-0">'
               . ($r['schedule'] ? '<li><i class="fa-regular fa-clock text-primary me-2"></i>' . e($r['schedule']) . '</li>' : '')
               . ($r['mentor'] ? '<li><i class="fa-solid fa-user-tie text-primary me-2"></i>Pembina: ' . e($r['mentor']) . '</li>' : '') . '</ul></div></div></div>';
        }
        echo '</div>';
        break;

    case 'prestasi':
        $lvl = isset($levels[get_str('level','')]) ? get_str('level') : '';
        $sql = 'SELECT * FROM student_achievements WHERE is_published = 1'; $par = [];
        if ($lvl) { $sql .= ' AND level = ?'; $par[] = $lvl; }
        $rows = q_all($sql . ' ORDER BY achievement_date DESC, id DESC', $par);
        echo '<div class="filter-pills"><a href="?s=prestasi" class="' . ($lvl ? '' : 'active') . '">Semua</a>';
        foreach ($levels as $k => $l) echo '<a href="?s=prestasi&level=' . $k . '" class="' . ($lvl === $k ? 'active' : '') . '">' . e($l) . '</a>';
        echo '</div>';
        if (!$rows) { echo empty_state('Belum ada data prestasi.'); break; }
        echo '<div class="row g-4">';
        foreach ($rows as $r) {
            echo '<div class="col-md-6 col-lg-4"><div class="card-x h-100"><div class="card-img-wrap"><img src="' . e(img_url($r['image'])) . '" alt="' . e($r['title']) . '" loading="lazy"><span class="cat-badge">' . e($levels[$r['level']]) . '</span></div><div class="card-body-x"><div class="meta"><i class="fa-regular fa-calendar"></i> ' . e(tgl_indo($r['achievement_date'])) . '</div><h3>' . e($r['title']) . '</h3><p class="mb-1"><strong><i class="fa-solid fa-medal text-warning me-1"></i>' . e($r['student_name']) . '</strong></p><p>' . e($r['description']) . '</p></div></div></div>';
        }
        echo '</div>';
        break;

    case 'kegiatan':
        $rows = q_all('SELECT * FROM student_activities WHERE is_published = 1 ORDER BY activity_date DESC, id DESC');
        if (!$rows) { echo empty_state('Belum ada kegiatan siswa.'); break; }
        echo '<div class="row g-4">';
        foreach ($rows as $r) {
            echo '<div class="col-md-6 col-lg-4"><div class="card-x h-100"><a class="card-img-wrap" href="' . e(img_url($r['image'])) . '" data-lightbox data-title="' . e($r['title']) . '" data-caption="' . e($r['description']) . '"><img src="' . e(img_url($r['image'])) . '" alt="' . e($r['title']) . '" loading="lazy"></a><div class="card-body-x"><div class="meta"><i class="fa-regular fa-calendar"></i> ' . e(tgl_indo($r['activity_date'])) . '</div><h3>' . e($r['title']) . '</h3><p>' . e($r['description']) . '</p></div></div></div>';
        }
        echo '</div>';
        break;

    case 'tata-tertib':
        $rows = q_all('SELECT * FROM school_rules WHERE is_published = 1 ORDER BY category, sort_order, id');
        if (!$rows) { echo empty_state('Tata tertib belum diisi.'); break; }
        $by = []; foreach ($rows as $r) $by[$r['category']][] = $r;
        echo '<div class="row justify-content-center"><div class="col-lg-9">';
        foreach ($by as $cat => $list) {
            echo '<section class="block-section"><h3 class="block-title"><i class="fa-solid fa-scale-balanced"></i> ' . e($cat) . '</h3><div class="accordion">';
            foreach ($list as $i => $r) {
                $id = 'r' . $r['id'];
                echo '<div class="accordion-item"><h4 class="accordion-header"><button class="accordion-button ' . ($i ? 'collapsed' : '') . '" type="button" data-bs-toggle="collapse" data-bs-target="#' . $id . '">' . e($r['title']) . '</button></h4><div id="' . $id . '" class="accordion-collapse collapse ' . ($i ? '' : 'show') . '"><div class="accordion-body">' . format_text($r['content']) . '</div></div></div>';
            }
            echo '</div></section>';
        }
        echo '</div></div>';
        break;
}
?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
